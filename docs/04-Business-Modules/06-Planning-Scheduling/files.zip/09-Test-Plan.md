# 09 — Test Plan

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-TP-009 |
| Version | R0 |
| Related | 02-Functional-Specification.md; 07-RBAC-Matrix.md; DCOS-PLN-AM-001 §18 |
| Status | For development |

---

## 1. Test strategy

### 1.1 The central problem

Most defects in a scheduling engine are **silent**. A wrong float figure does not throw an exception, does not break a screen, and does not appear in a log. It produces a number that looks entirely plausible and is wrong — and the error only surfaces months later when a client's delay analyst disputes the programme.

The test strategy therefore rests on **oracle testing**: a set of hand-calculated reference networks whose correct answers are known independently of the implementation. Every CPM change is validated against these before anything else runs.

### 1.2 Test levels

| Level | Scope | Owner | Automation |
|---|---|---|---|
| Unit | Business rules, date arithmetic, float formulae | Developer | 100% |
| Oracle | Reference networks with known answers | Developer | 100% |
| Integration | Cross-module events and roll-up | Developer | 100% |
| API contract | Endpoints, payloads, error envelopes, status codes | Developer | 100% |
| Security | RLS, permission matrix, scope isolation | Security | 100% — build fails on breach |
| Performance | Render, recalculation, bulk, export | Performance | 100% |
| Interchange | P6 XER / MSPDI round trip | QA | Partial |
| UI / interaction | Gantt behaviour, undo, mode switching | QA | Partial |
| Mobile / offline | Capture, queue, sync, conflict | QA | Partial |
| UAT | Real project, real planner, real programme | Head of Planning | Manual |

### 1.3 Entry and exit criteria

| Gate | Entry | Exit |
|---|---|---|
| Unit | Code complete for the component | 100% business rules covered, all pass |
| Oracle | CPM engine buildable | All 12 reference networks match expected to the day |
| Integration | Dependent modules deployed to test | All IT cases pass; no orphan events |
| Security | Feature complete | Zero cross-tenant leaks; full permission matrix passes |
| Performance | Feature complete, seeded data loaded | All NFR targets met at P95 |
| UAT | All above passed | Planner produces and baselines a real programme unaided |

---

## 2. Oracle test networks

Hand-calculated networks with independently known answers. These are the highest-value tests in the module.

| Ref | Network | Tests | Expected |
|---|---|---|---|
| ON-01 | 5 activities, FS chain, single calendar | Basic forward/backward pass | ES/EF/LS/LF exact; TF = 0 throughout |
| ON-02 | Diamond: A → (B, C) → D, B=5d C=8d | Float on the shorter branch | B: TF = 3, FF = 3; C and D critical |
| ON-03 | SS with lag 5 | Start-to-start semantics | Successor ES = predecessor ES + 5 |
| ON-04 | FF with lag 3 | Finish-to-finish semantics | Successor EF = predecessor EF + 3 |
| ON-05 | SF relationship | Rarely used, frequently wrong | Successor EF drives predecessor ES |
| ON-06 | Negative lag (lead) of −2 on FS | Lead handling | Successor starts 2 working days before predecessor finishes |
| ON-07 | Two calendars: 6-day and 7-day, equal durations, same start | **Multi-calendar arithmetic** | Different finish dates; both correct on own calendar |
| ON-08 | Multi-calendar float across a 5-day/7-day boundary | **Multi-calendar float** | TF computed on the activity's own calendar, not the project's |
| ON-09 | FNLT constraint producing negative float | Constraint and negative float | TF = −4; negative float path identified correctly |
| ON-10 | Out-of-sequence: successor progressed, predecessor open | Retained logic vs progress override | Two expected result sets, one per project setting |
| ON-11 | LOE spanning 4 activities | Derived dates, never critical | LOE dates = span; `is_critical` = false always |
| ON-12 | 3-way merge with equal float, mixed calendars | Longest path vs float-based criticality | Longest path flag differs from `is_critical`; both correct |

**Rule:** a change to the CPM engine that fails any oracle network cannot be merged, regardless of what else passes.

---

## 3. Unit tests — business rules

Every rule in DCOS-PLN-AM-001 §18 has at least one positive and one negative test.

| Ref | Rule | Negative test | Expected |
|---|---|---|---|
| UT-01 | BR-AM-001 | Create activity with no WBS node | Rejected, rule cited |
| UT-02 | BR-AM-002 | Duplicate `activity_id` in one project | Second rejected |
| UT-03 | BR-AM-003 | Milestone with duration 5 | Rejected |
| UT-04 | BR-AM-003 | Task-dependent activity with duration 0 | Rejected |
| UT-05 | BR-AM-004 | Create with no calendar | Project default applied silently |
| UT-06 | BR-AM-006 | Three-activity relationship loop | Rejected, cycle path named |
| UT-07 | BR-AM-007 | Actual start after the data date | Rejected |
| UT-08 | BR-AM-008 | Actual finish before actual start | Rejected |
| UT-09 | BR-AM-009 | Actual finish with no actual start | Rejected |
| UT-10 | BR-AM-010 | Complete with remaining duration > 0 | Rejected |
| UT-11 | BR-AM-011 | 100% with no actual finish | Rejected |
| UT-12 | BR-AM-012 | Progress on a Draft activity | Rejected |
| UT-13 | BR-AM-013 | Reduce percent complete with no reason | Rejected; with reason → High audit |
| UT-14 | BR-AM-014 | Change progress method post-baseline | Rejected without revision |
| UT-15 | BR-AM-015 | Write `total_float` via API | Rejected as read-only |
| UT-16 | BR-AM-016 | Hard constraint, 8-character justification | Rejected (min 20) |
| UT-17 | BR-AM-017 | Planner applies MANS | Routed to approval, not applied |
| UT-18 | BR-AM-018 | Duration change post-baseline | Revision record auto-created |
| UT-19 | BR-AM-019 | Delete activity with linked field tasks | Rejected, tasks named |
| UT-20 | BR-AM-021 | Set duration on an LOE activity | Rejected |
| UT-21 | BR-AM-022 | Progress on a hammock | Rejected |
| UT-22 | BR-AM-023 | Resource on a milestone | Rejected |
| UT-23 | BR-AM-025 | BOQ over-allocation across activities | Rejected |
| UT-24 | BR-AM-026 | Out-of-sequence progress | Permitted and flagged |
| UT-25 | BR-AM-027 | Recalculation yields negative float | Critical notification dispatched |
| UT-26 | BR-AM-028 | Close activity with open NCR | Rejected |
| UT-27 | BR-AM-030 | Cancel activity with progress, no VO reference | Rejected |
| UT-28 | BR-AM-033 | Bulk 500 rows, one invalid | Whole batch rolled back, row identified |
| UT-29 | BR-AM-035 | Progress-only user edits logic | Denied |
| UT-30 | BR-AM-036 | Calendar change | Recalculation queued automatically |

### 3.1 Calendar arithmetic

| Ref | Test | Expected |
|---|---|---|
| UT-40 | Add 10 working days from a Friday, 6-day week | Lands on the correct Wednesday |
| UT-41 | Add 10 working days spanning Khmer New Year | Holiday excluded |
| UT-42 | Count working days across a month boundary | Matches manual count |
| UT-43 | Working day count on a 7-day continuous calendar | No exclusions |
| UT-44 | Calendar exception making a Sunday working | Included in the count |
| UT-45 | Partial-hours exception day | Hours honoured in resource calculation |
| UT-46 | Duration of 0.5 working days | Correctly handled or rejected per setting |
| UT-47 | Leap-year February on a 6-day calendar | Correct count |

---

## 4. Integration tests

| Ref | Scenario | Expected | Requirement |
|---|---|---|---|
| IT-01 | Close a field task with 120 m² installed | Parent activity `installed_quantity` and percent update within 5 s | I-04 |
| IT-02 | Close two tasks against one activity | Quantities sum; no double-count on replay | I-04 |
| IT-03 | Move a WBS node | Activity path updates; roll-up recalculates; logic unaffected | I-01 |
| IT-04 | Add a holiday to a calendar in use | Affected projects queue recalculation; dates shift correctly | I-03 |
| IT-05 | Approve a baseline | Document Control receives revision; EVM receives planned value curve | I-15, I-12 |
| IT-06 | CPM produces negative float | Notification to Planner, PM, Director within 30 s | I-21 |
| IT-07 | Close an NCR blocking an activity | Activity becomes eligible for Closed | I-06 |
| IT-08 | Revise a BOQ item quantity | Activity budget value recalculates; allocation variance flagged | I-10 |
| IT-09 | Recalculate schedule | Procurement receives updated required-on-site dates | I-08 |
| IT-10 | Issue drawing IFC | Related design constraint in make-ready log auto-clears | I-16 |
| IT-11 | Replay a duplicate progress event | Single history row; no double-count | Idempotency |
| IT-12 | Inject a cross-tenant event | Rejected; security audit event raised | NFR-PLN-10 |
| IT-13 | CPM engine offline during an edit | Edit accepted; stale banner shown; recalculation on recovery | §9 resilience |
| IT-14 | Calendar Engine offline | Date-arithmetic writes rejected with clear message; no silent default | §9 resilience |
| IT-15 | Notification Engine offline | Events queued and retried; schedule operations unblocked | §9 resilience |

---

## 5. Security tests

**Build-failing.** Any failure here blocks the pipeline.

| Ref | Test | Expected |
|---|---|---|
| ST-01 | Every table in the module has RLS enabled | Pass, or build fails |
| ST-02 | Tenant A queries tenant B activity by direct UUID | 404, zero rows, security audit event |
| ST-03 | Tenant A injects `tenant_id` in the request body | Ignored; token value used |
| ST-04 | Subcontractor requests an activity outside their WBS branch | 404, not 403 |
| ST-05 | Site Supervisor attempts a relationship edit | 403 |
| ST-06 | Discipline Manager (STR) edits an MEP duration | 403 on discipline scope |
| ST-07 | Planner approves their own baseline submission | 403 on segregation of duties |
| ST-08 | Client requests the live working schedule | 403; issued revisions only |
| ST-09 | Any role writes to `activity_schedule_results` | Rejected |
| ST-10 | Attempt to UPDATE `activity_progress_history` | Rejected at database level |
| ST-11 | Attempt to DELETE an approved baseline snapshot | Rejected at database level |
| ST-12 | Expired session token | 401 |
| ST-13 | Token with project scope not covering the target | 404 |
| ST-14 | SQL injection via filter parameters | Parameterised; no execution |
| ST-15 | Bulk endpoint used to exceed rate limits | 429 with `Retry-After` |
| ST-16 | Export of 50,000 activities by a Viewer | Permitted but rate-limited and audited |

---

## 6. Performance tests

Measured at P95 on the reference environment, with seeded data.

| Ref | Operation | Dataset | Target |
|---|---|---|---|
| PT-01 | Activity table initial render | 5,000 activities | < 2 s |
| PT-02 | Gantt scroll and zoom | 5,000 activities | 60 fps sustained |
| PT-03 | Single duration edit → repainted result | 5,000 activities | < 1.5 s |
| PT-04 | Full CPM recalculation | 5,000 act / 12,000 rel | < 3 s server-side |
| PT-05 | Full CPM recalculation | 50,000 act / 120,000 rel | < 45 s async |
| PT-06 | Bulk update, transactional | 500 activities | < 5 s |
| PT-07 | Look-ahead generation | 6-week window | < 10 s |
| PT-08 | Progress session commit | 300 lines | < 8 s |
| PT-09 | A1 PDF programme export | 12-month schedule | < 20 s async |
| PT-10 | P6 XER export | 3,000 activities | < 30 s |
| PT-11 | Mobile sync after 72 h offline | 200 queued records | < 30 s |
| PT-12 | 20 concurrent planners, one project | Mixed read/write | No lost updates; conflicts detected |
| PT-13 | Baseline snapshot capture | 5,000 activities | < 10 s |
| PT-14 | Variance report against baseline | 5,000 activities | < 3 s |

### 6.1 Load profile

| Profile | Concurrent users | Duration | Pass |
|---|---|---|---|
| Normal | 50 across 10 projects | 1 hour | All targets met |
| Peak (month-end) | 200, 80% in progress sessions | 2 hours | Degradation < 25% |
| Stress | 500 | 30 min | Graceful degradation; no data loss |
| Soak | 50 | 24 hours | No memory growth; no connection leak |

---

## 7. Interchange tests

| Ref | Test | Expected |
|---|---|---|
| XT-01 | Export to XER, reimport to DCOS | No loss of ID, name, duration, calendar, constraint, codes, logic, progress |
| XT-02 | Export to XER, open in Primavera P6 | Opens without error; dates match to the day |
| XT-03 | Import a P6 XER produced by a consultant | Mapping report lists unmatched calendars and WBS nodes |
| XT-04 | Import with an activity ID exceeding 20 characters | Rejected with a clear message; no silent truncation |
| XT-05 | Import containing circular logic | Rejected before commit; cycle named |
| XT-06 | Import with duplicate activity IDs | Rejected before commit |
| XT-07 | MSPDI round trip | Structural fidelity; documented differences reported |
| XT-08 | CSV import, 3,000 rows, 5 invalid | Validation report identifies all 5; nothing written until commit |
| XT-09 | Export to Excel with filters applied | Only filtered rows, all displayed columns |
| XT-10 | Multi-calendar schedule exported to XER | Calendars preserved and correctly assigned |

---

## 8. UI and interaction tests

| Ref | Test | Expected |
|---|---|---|
| UI-01 | Drag a bar body | Prompt appears offering SNET or cancel; never silent |
| UI-02 | Cancel the drag prompt | No constraint applied; bar returns |
| UI-03 | Drag a bar edge | Duration changes; no prompt |
| UI-04 | Drag from bar end to another bar | FS lag 0 created; inline editor opens |
| UI-05 | 50 sequential edits then 50 undos | All reverted correctly, in order |
| UI-06 | Undo after a committed recalculation | Reverts the edit and re-queues recalculation |
| UI-07 | Switch to progress entry mode | Logic controls visibly disabled; drag inert |
| UI-08 | Two activities, different calendars, same start, equal duration | Different finish dates; per-row shading differs |
| UI-09 | Horizontal scroll | Data date line remains visible and correctly positioned |
| UI-10 | Greyscale print | Critical activities distinguishable by outline |
| UI-11 | Keyboard-only session: create, edit, link, progress | Fully achievable without a mouse |
| UI-12 | Group by trade package | Summary rows regenerate correctly |
| UI-13 | Stale results after an edit | Banner shown with last calculation time; not presented as current |
| UI-14 | Print A1, 12-month schedule | Title block, legend, sheet index, correct overlap band |

---

## 9. Mobile and offline tests

| Ref | Test | Expected |
|---|---|---|
| MT-01 | Capture progress with no signal | Written locally; sync indicator shows pending |
| MT-02 | Reconnect after 72 hours | Queue uploads; all records applied with device timestamps |
| MT-03 | Same activity edited on server and device while offline | Field data resolved by device timestamp; conflict logged and surfaced |
| MT-04 | Access revoked while device offline | Queued records **accepted** and flagged `REQUIRES_REVIEW`; never discarded |
| MT-05 | Photo capture on cellular | Compressed upload; full resolution deferred to WiFi |
| MT-06 | Activity outside user's WBS scope | Not visible in the mobile list |
| MT-07 | Attempt an approval action offline | Blocked; assurance level cannot be established |
| MT-08 | Low-end Android, 3G | List loads < 5 s; progress submitted in 3 taps |
| MT-09 | App killed mid-entry | Draft preserved on relaunch |
| MT-10 | Device clock incorrect by 2 days | Server flags implausible timestamp for review |

---

## 10. Acceptance criteria

Each maps to a business rule or requirement and forms the release regression suite.

| Ref | Scenario | Expected | Trace |
|---|---|---|---|
| AC-01 | Create activity without a WBS node | Rejected, rule named | BR-AM-001 |
| AC-02 | Duplicate activity ID | Rejected | BR-AM-002 |
| AC-03 | Milestone with a duration | Rejected | BR-AM-003 |
| AC-04 | Create without calendar | Project default applied | BR-AM-004 |
| AC-05 | Relationship loop | Rejected, cycle named | BR-AM-006 |
| AC-06 | Actual start after data date | Rejected | BR-AM-007 |
| AC-07 | 100% without actual finish | Rejected | BR-AM-011 |
| AC-08 | Write total float via API | Rejected as read-only | BR-AM-015 |
| AC-09 | Planner applies mandatory constraint | Routed to approval | BR-AM-017 |
| AC-10 | Duration change post-baseline | Revision auto-created | BR-AM-018 |
| AC-11 | Delete activity with linked tasks | Rejected, tasks named | BR-AM-019 |
| AC-12 | BOQ over-allocation | Rejected | BR-AM-025 |
| AC-13 | Progress with incomplete predecessor | Permitted and flagged | BR-AM-026 |
| AC-14 | Negative float produced | Critical notification dispatched | BR-AM-027 |
| AC-15 | Close activity with open NCR | Rejected | BR-AM-028 |
| AC-16 | Bulk 500 with one invalid row | Full rollback, row identified | BR-AM-033 |
| AC-17 | Site engineer edits logic | Denied; progress still available | BR-AM-035 |
| AC-18 | Cross-tenant activity request | 404 + security audit | NFR-PLN-10 |
| AC-19 | Equal durations, different calendars | Different finishes, both correct | FR-PLN-066 |
| AC-20 | Offline progress synced | Recorded with device timestamp and correct data date | NFR-PLN-16 |
| AC-21 | Baseline submitted with blocking findings | Rejected, findings listed | FR-PLN-233 |
| AC-22 | Approved baseline modification attempt | Rejected at database level | FR-PLN-119 |
| AC-23 | Scenario edited | Live schedule results unchanged | FR-PLN-211 |
| AC-24 | Fragnet inserted and calculated | Net impact reported in working days | FR-PLN-215 |
| AC-25 | Progress session preview | Forecast shown; nothing written until commit | FR-PLN-145 |
| AC-26 | Session commit fails on one row | Whole session rolled back | FR-PLN-146 |
| AC-27 | Look-ahead generated | Produced in < 10 s, exportable | FR-PLN-170 |
| AC-28 | Health check with negative float | Blocking finding; baseline blocked | VC-07 |
| AC-29 | Manpower histogram produced | Average and peak by period and trade | FR-PLN-195 |
| AC-30 | XER round trip, 3,000 activities | No data loss | NFR-PLN-17 |

---

## 11. Test data

| Set | Content | Use |
|---|---|---|
| TD-01 | 12 oracle networks, 5–20 activities each, hand-calculated | CPM validation |
| TD-02 | 10-storey building, 142 activities, 4 calendars, real dates | Functional and UAT |
| TD-03 | 5,000 activities, 12,000 relationships, 6 calendars | Performance |
| TD-04 | 50,000 activities, 120,000 relationships | Scale ceiling |
| TD-05 | Two tenants with identical structures | Isolation testing |
| TD-06 | 18 users across all roles, mixed discipline and WBS scopes | Permission matrix |
| TD-07 | Consultant-produced P6 XER with unmatched calendars | Import mapping |
| TD-08 | Progressed schedule with 4 out-of-sequence activities | Retained logic vs override |
| TD-09 | Schedule with a delay event and prepared fragnet | TIA validation |
| TD-10 | 200 queued mobile records from a 72-hour offline period | Sync testing |

---

## 12. Defect severity

| Severity | Definition | Examples | Response |
|---|---|---|---|
| **S1 Critical** | Wrong schedule output, or data loss | Incorrect float; wrong critical path; lost progress; cross-tenant leak; baseline corrupted | Stop release. Fix immediately. |
| **S2 Major** | Core workflow blocked | Cannot commit a session; recalculation fails; baseline cannot be approved | Fix before release |
| **S3 Moderate** | Workaround exists | Filter incorrect; export column missing; slow but functional | Fix in the release if capacity allows |
| **S4 Minor** | Cosmetic | Label wording, spacing, icon alignment | Backlog |

**S1 is deliberately broad.** In a scheduling engine, a plausible wrong number is more dangerous than a crash, because a crash gets reported and a wrong float figure gets believed and acted upon.

---

## 13. Regression suite

| Trigger | Suite run |
|---|---|
| Any commit | Unit + oracle networks |
| Any CPM engine change | Full oracle + all integration + performance PT-04 |
| Any calendar change | Oracle ON-07, ON-08 + all UT-40 series |
| Any RBAC change | Full security suite |
| Any schema change | RLS verification + migration test |
| Pre-release | Full suite, all levels |
| Post-deployment | Smoke suite within 30 minutes |

---

## 14. UAT

### 14.1 Approach

A qualified planning engineer builds and baselines a real programme in DCOS **without assistance**, in parallel with their existing tool, and the two are compared.

### 14.2 UAT scenarios

| Ref | Scenario | Success |
|---|---|---|
| UAT-01 | Configure calendars for a live project | Complete in < 30 min, matching the Basis of Schedule |
| UAT-02 | Build a 500-activity Level 3 programme | Complete without support tickets |
| UAT-03 | Run health check and clear blocking findings | All findings understood and resolvable |
| UAT-04 | Baseline through approval workflow | Completed with the correct approvers |
| UAT-05 | Run one full monthly update cycle | Programme issued within 5 working days of data date |
| UAT-06 | Site supervisor reports a week of progress on mobile | No training required beyond a 15-minute briefing |
| UAT-07 | Produce a look-ahead and issue to subcontractors | Accepted as usable by site |
| UAT-08 | Produce an A1 PDF programme submission | Accepted by the client or consultant |
| UAT-09 | Model a delay event as a TIA | Output accepted by the Contract Administrator |
| UAT-10 | Compare DCOS dates against the parallel P6 programme | Match to the day across all activities |

**UAT-10 is the decisive test.** If DCOS and P6 disagree on any date, the discrepancy must be explained and resolved before release — not documented as a known difference.

### 14.3 Sign-off

| Role | Confirms |
|---|---|
| Head of Planning | Schedule outputs are correct and defensible |
| Planning Engineer | Tool is usable for daily work |
| Construction Manager | Look-ahead and resource profile are usable on site |
| Quantity Surveyor | Progress reconciles with valuation |
| Contract Administrator | Delay records and TIA output are contractually adequate |
| Lead Developer | All S1 and S2 defects closed |
| Security | Zero isolation or permission failures |

---

*DCOS — Planning & Scheduling — Test Plan — Internal Controlled Document*
