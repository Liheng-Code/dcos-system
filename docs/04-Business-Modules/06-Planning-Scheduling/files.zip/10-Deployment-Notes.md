# 10 — Deployment Notes

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-DEP-010 |
| Version | R0 |
| Related | 04-Database-Schema.md; Gap Analysis R1 §5.5 (DR & Business Continuity) |
| Status | For development |

---

## 1. Deployment principles

| Principle | Application |
|---|---|
| Calendar engine first | Multi-calendar float cannot be retrofitted. The calendar engine deploys and is verified before the CPM engine is enabled. |
| Dormant columns from day one | BOQ link, cost account and earned value columns ship in the first migration even though the consuming modules arrive later. Adding them afterwards means migrating every historic activity and rebuilding every baseline snapshot. |
| Never break a baseline | No migration may alter, reformat or recompute an approved baseline snapshot. |
| Feature flags over branches | Sub-modules ship dark and are enabled per tenant. |
| Backwards-compatible schema changes | Expand, migrate, contract — never a breaking change in a single release. |
| Recalculation is idempotent | Any deployment may safely trigger a full recalculation without corrupting data. |

---

## 2. Environments

| Environment | Purpose | Data | Access |
|---|---|---|---|
| Local | Developer workstation | Seed set TD-01, TD-02 | Developer |
| CI | Automated pipeline | Generated per run, torn down | Pipeline only |
| Dev | Integration with other modules | Synthetic, refreshed weekly | Development team |
| Test / QA | Functional and security testing | Full seed sets TD-01 to TD-10 | QA, Security |
| Performance | Load and scale | TD-03, TD-04 (50,000 activities) | Performance team |
| Staging | Pre-production rehearsal | Anonymised production copy | Release team, UAT users |
| Production | Live | Live tenant data | Operations, on-call |

**Staging must mirror production** in database version, extension set, instance class and connection pool configuration. A CPM performance figure measured on a smaller staging instance is not evidence.

---

## 3. Infrastructure requirements

### 3.1 Database

| Item | Requirement |
|---|---|
| Engine | PostgreSQL 15 or later |
| Extensions | `uuid-ossp`, `pgcrypto`, `btree_gin`, `pg_stat_statements` |
| Connection pooling | PgBouncer, transaction mode |
| Instance sizing (production start) | 8 vCPU, 32 GB RAM, 500 GB SSD with autoscale |
| Read replica | One, for reporting and export workloads |
| `work_mem` | 64 MB — CPM queries sort large result sets |
| `statement_timeout` | 30 s general; CPM worker connections exempt |
| Backup | Hourly incremental, daily full, separate region |
| PITR | 30 days |

### 3.2 Application

| Item | Requirement |
|---|---|
| Runtime | Node.js 20 LTS |
| Framework | NestJS (scale path) / Supabase Edge Functions (MVP) |
| CPM worker | Dedicated process pool, minimum 2 workers, 4 GB memory each |
| Queue | BullMQ on Redis |
| Cache | Redis — calendar working-day sets, look-ahead read models |
| Object storage | S3 / R2 for PDF programme exports and import files |
| CDN | All export downloads via signed URLs, never direct bucket access |

### 3.3 CPM worker sizing

| Project size | Workers | Memory | Expected runtime |
|---|---|---|---|
| ≤ 1,000 activities | Shared pool | 512 MB | < 1 s |
| 1,000–5,000 | Shared pool | 2 GB | < 3 s |
| 5,000–20,000 | Dedicated | 4 GB | < 15 s |
| 20,000–50,000 | Dedicated, async only | 8 GB | < 45 s |

Recalculations above 5,000 activities run asynchronously with a completion notification, matching the < 30 s complex-report benchmark in the Gap Analysis.

---

## 4. Migration sequence

Migrations are numbered, forward-only, and each is independently reversible.

| # | Migration | Notes |
|---|---|---|
| PLN-001 | Calendar tables + RLS | Must deploy and verify before anything else |
| PLN-002 | Seed default calendars (6-day, 5-day office, 7-day continuous, authority) | Per tenant |
| PLN-003 | `activities` table, all 44 columns **including dormant BOQ/cost/EVM columns** | See §1 |
| PLN-004 | `activity_schedule_results` + indexes | Separate table — see 04-Database-Schema §4.2 |
| PLN-005 | `activity_progress_history` (append-only triggers) | Block UPDATE and DELETE at database level |
| PLN-006 | Activity coding tables + seed the 8 default code types | |
| PLN-007 | `activity_relationships` + cycle-check function | |
| PLN-008 | `calculation_runs` | |
| PLN-009 | Baseline tables + immutability triggers | Block UPDATE and DELETE on snapshots |
| PLN-010 | `schedule_revisions` (append-only) | |
| PLN-011 | Progress session tables | |
| PLN-012 | Health check tables + seed 30 check definitions | |
| PLN-013 | Look-ahead, constraint log, WWP, variance reasons | Phase 3 |
| PLN-014 | Norms library + resource assignment tables | Phase 3 |
| PLN-015 | `activity_boq_links` FK activation | Phase 2, once BOQ Engine deployed |
| PLN-016 | Scenario tables | Phase 4 |
| PLN-017 | Delay event tables | Phase 4 |
| PLN-018 | Materialised views for reporting read models | |

### 4.1 Append-only enforcement

```sql
CREATE OR REPLACE FUNCTION block_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'Table % is append-only (%). See DCOS-PLN-DB-004 §16.',
        TG_TABLE_NAME, TG_OP;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER no_update_progress_history
  BEFORE UPDATE OR DELETE ON activity_progress_history
  FOR EACH ROW EXECUTE FUNCTION block_mutation();

CREATE TRIGGER no_change_baseline_activities
  BEFORE UPDATE OR DELETE ON baseline_activities
  FOR EACH ROW EXECUTE FUNCTION block_mutation();

CREATE TRIGGER no_change_revisions
  BEFORE UPDATE OR DELETE ON schedule_revisions
  FOR EACH ROW EXECUTE FUNCTION block_mutation();
```

### 4.2 RLS verification gate

```sql
-- Fails the deployment if any module table lacks RLS
SELECT tablename FROM pg_tables
WHERE schemaname = 'public'
  AND tablename LIKE ANY (ARRAY['activit%','calendar%','baseline%','schedule_%','progress_%'])
  AND NOT rowsecurity;
-- Expected: zero rows
```

This check runs as a post-migration step. A non-empty result aborts the deployment (Gap Analysis §5.2).

---

## 5. Configuration

### 5.1 Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PLN_CPM_WORKER_COUNT` | 4 | Worker pool size |
| `PLN_CPM_TIMEOUT_MS` | 60000 | Abort threshold; previous results retained on abort |
| `PLN_CPM_ASYNC_THRESHOLD` | 5000 | Activity count above which recalculation is asynchronous |
| `PLN_CPM_MAX_ACTIVITIES` | 50000 | Hard ceiling per project |
| `PLN_RECALC_DEBOUNCE_MS` | 2000 | Coalesce rapid successive edits into one run |
| `PLN_DEFAULT_CRITICAL_FLOAT` | 0 | Project-overridable |
| `PLN_DEFAULT_OOS_MODE` | `retained_logic` | Out-of-sequence handling |
| `PLN_LOOKAHEAD_WEEKS` | 6 | Default look-ahead window |
| `PLN_UNDO_STACK_DEPTH` | 50 | Minimum per NFR-PLN-14 |
| `PLN_EXPORT_MAX_ROWS` | 50000 | Export guard |
| `PLN_MOBILE_SYNC_BATCH` | 200 | Records per sync request |
| `PLN_HEALTH_THRESHOLDS` | DCMA defaults | JSON override per tenant |

### 5.2 Feature flags

| Flag | Default | Enables |
|---|---|---|
| `pln.cpm_engine` | on | CPM calculation |
| `pln.multi_calendar` | on | Multiple calendars per project |
| `pln.baseline` | on | Baseline management |
| `pln.progress_session` | on | Session-based update |
| `pln.lookahead` | off (Phase 3) | Look-ahead and Last Planner |
| `pln.resource_loading` | off (Phase 3) | Resource, histogram, levelling |
| `pln.cost_loading` | off (Phase 2) | BOQ linkage, cost S-curve |
| `pln.scenarios` | off (Phase 4) | Scenarios and TIA |
| `pln.p6_interchange` | off | XER / MSPDI import and export |
| `pln.mobile_progress` | off (Phase 3) | Mobile capture |
| `pln.longest_path` | on | Longest path in addition to float-based criticality |

Flags are evaluated per tenant, allowing pilot enablement on one project before general release.

---

## 6. Rollout plan

| Stage | Scope | Duration | Exit criterion |
|---|---|---|---|
| 0 — Internal | Planning team, synthetic project | 2 weeks | Oracle networks verified in the deployed environment |
| 1 — Pilot | One live project, run in parallel with P6 | 6 weeks | UAT-10 passes: dates match P6 to the day |
| 2 — Early adopters | 3 projects, DCOS as master schedule | 8 weeks | Two full monthly update cycles completed on time |
| 3 — General | All new projects | Ongoing | — |
| 4 — Migration | Existing projects at a natural break (baseline revision) | Per project | Programme imported and reconciled |

**Never migrate a live project mid-cycle.** Migrate at a baseline revision point, when a new reference programme is being established anyway.

---

## 7. Deployment procedure

### 7.1 Pre-deployment

1. Confirm all S1 and S2 defects closed.
2. Confirm the full regression suite passed on staging.
3. Confirm oracle networks pass in the staging environment.
4. Take a manual database snapshot in addition to scheduled backups.
5. Confirm rollback scripts exist and have been tested on staging.
6. Notify tenants of the maintenance window (48 hours' notice minimum).
7. Confirm on-call cover for the following 24 hours.

### 7.2 Deployment

1. Enable maintenance mode for the module only; other modules remain live.
2. Drain the CPM worker queue; wait for in-flight runs to complete.
3. Apply migrations in sequence, verifying each.
4. Run the RLS verification gate — abort on any failure.
5. Deploy application containers with a rolling restart.
6. Restart CPM workers.
7. Run the post-deployment smoke suite.
8. Disable maintenance mode.
9. Trigger a background recalculation for all active projects.
10. Monitor for 60 minutes before declaring the deployment complete.

### 7.3 Smoke suite (must pass within 30 minutes)

| Ref | Check |
|---|---|
| SM-01 | Health endpoint responds |
| SM-02 | Oracle network ON-02 returns expected float values |
| SM-03 | Oracle network ON-07 returns expected multi-calendar dates |
| SM-04 | Create, read, update, delete an activity |
| SM-05 | CPM run completes on a 500-activity project |
| SM-06 | Progress session opens, previews and commits |
| SM-07 | Cross-tenant read returns zero rows |
| SM-08 | Baseline snapshot capture and variance report |
| SM-09 | Look-ahead generation |
| SM-10 | PDF programme export |

---

## 8. Rollback

| Scenario | Action |
|---|---|
| Migration failure | Automatic abort; transaction rolled back; previous version remains live |
| Smoke suite failure | Roll back application containers to the previous image; migrations remain (all are backwards compatible) |
| Wrong CPM results detected post-deployment | **Immediately disable `pln.cpm_engine` flag.** Schedule reads continue from the last known-good results with a stale banner. Investigate offline. |
| Performance degradation | Increase worker count and async threshold before rolling back |
| Data corruption | Restore from PITR to the point immediately before deployment; replay events from the dead-letter queue |

**Rollback constraint:** because baselines and progress history are append-only and immutable, a rollback never destroys them. Recovery restores the calculation layer, not the record layer.

| Metric | Target |
|---|---|
| RTO | 4 hours |
| RPO | 1 hour |
| Rollback decision window | 60 minutes post-deployment |

---

## 9. Monitoring and alerting

### 9.1 Application metrics

| Metric | Warning | Critical |
|---|---|---|
| CPM run duration, P95 | > 5 s | > 15 s |
| CPM run failure rate | > 1% | > 5% |
| CPM queue depth | > 20 | > 100 |
| Recalculation lag (edit → result) | > 5 s | > 30 s |
| Activity table render, P95 | > 3 s | > 8 s |
| Progress session commit failure rate | > 2% | > 10% |
| Mobile sync failure rate | > 5% | > 15% |
| Export job failure rate | > 5% | > 20% |
| API error rate (5xx) | > 0.5% | > 2% |

### 9.2 Business metrics

| Metric | Alert |
|---|---|
| Projects with data date older than 35 days | Warning to Head of Planning |
| Projects with data date older than 45 days | Critical — the programme is no longer a control document |
| Activities with negative float across the portfolio | Daily digest to Project Directors |
| Baselines pending approval > 7 days | Escalation |
| Health check blocking failures at baseline submission | Trend reported monthly |

### 9.3 Security monitoring

| Event | Action |
|---|---|
| Cross-tenant access attempt | Immediate alert to security; session logged |
| Attempted write to `activity_schedule_results` | Alert; indicates a code defect or an attack |
| Attempted mutation of an append-only table | Alert; database trigger fired |
| Bulk export exceeding 10,000 rows | Audit entry and notification to Company Admin |
| Repeated permission denials by one user | Alert to Company Admin |

### 9.4 Logging

| Level | Content |
|---|---|
| INFO | CPM run start/complete with run ID, activity count, duration |
| WARN | Stale results served; degraded dependency; slow query |
| ERROR | CPM failure with the network state that caused it |
| AUDIT | Separate stream to the Audit Trail Engine, never mixed with application logs |

Every log line carries `tenant_id`, `project_id`, `request_id` and `correlation_id`. **No log line may contain schedule data values** — activity names and dates are commercially sensitive.

---

## 10. Data seeding

| Seed | Content | Scope |
|---|---|---|
| Default calendars | 6-day site, 5-day office, 7-day continuous, authority | Per tenant on creation |
| Public holidays | Cambodian holidays for the current and next two years, flagged indicative for lunar dates | Per tenant, per year |
| Activity code types | Discipline, responsible party, trade package, area, phase, work type, cost account, claim period | Per tenant |
| Discipline values | ARC, STR, MEP, CIV, QA, HSE | Global |
| Health check definitions | 14 DCMA + 16 DCOS checks with default thresholds | Global |
| Variance reason codes | Design, material, labour, plant, permit, access, weather, predecessor, rework, other | Global |
| Productivity norms | Starter library, ~25 composite norms | Per tenant, editable |

**Holiday seeding is an annual operational task.** Lunar holidays move; the seed marks them `is_confirmed = false` until gazette confirmation, and a reminder is raised each November for the following year.

---

## 11. Operational runbook

| Situation | Action |
|---|---|
| CPM queue backing up | Scale worker count; raise async threshold; check for a single oversized project monopolising workers |
| One project fails recalculation repeatedly | Run cycle detection manually; check for an activity with no calendar; inspect the failing run record |
| Planner reports wrong float | Reproduce against an oracle network first. If oracle passes, the defect is project data, not the engine. |
| Planner reports missing activities | Check WBS scope and discipline scope on the user's project access before assuming a data problem |
| Mobile sync backlog after site connectivity loss | Monitor queue depth; sync is designed to catch up; do not clear the queue |
| Export job stuck | Cancel and re-queue; check object storage credentials |
| Baseline approval stuck | Check the Approval Workflow Engine instance, not this module |
| Holiday added mid-project | Expect a portfolio-wide recalculation; schedule it outside working hours |

---

## 12. Capacity planning

| Dimension | Year 1 | Year 3 |
|---|---|---|
| Tenants | 5 | 40 |
| Active projects | 25 | 250 |
| Activities per project (median) | 800 | 1,500 |
| Total activity rows | 20,000 | 375,000 |
| Progress history rows | 250,000 | 6,000,000 |
| Calculation runs per day | 300 | 4,000 |
| Peak concurrent planners | 20 | 120 |
| Storage — schedule data | 5 GB | 90 GB |
| Storage — exports and imports | 20 GB | 400 GB |

Progress history is the fastest-growing table. Partition by `data_date` year once it exceeds 10 million rows.

---

## 13. Pre-go-live checklist

| # | Item | Owner |
|---|---|---|
| 1 | Calendar engine deployed and oracle-verified | Lead Developer |
| 2 | All migrations applied; RLS gate returns zero rows | Lead Developer |
| 3 | Cross-tenant leak tests passing in CI | Security |
| 4 | Append-only triggers verified on all three tables | Lead Developer |
| 5 | Performance targets met on production-equivalent hardware | Performance |
| 6 | Backup and PITR verified by an actual restore test | Operations |
| 7 | Rollback tested on staging | Release Manager |
| 8 | Monitoring dashboards and alerts live | Operations |
| 9 | Feature flags set correctly for the rollout stage | Release Manager |
| 10 | Seed data loaded and verified per tenant | Operations |
| 11 | Holiday list gazette-confirmed for the current year | Head of Planning |
| 12 | UAT signed off by all roles in 09-Test-Plan §14.3 | Head of Planning |
| 13 | Training delivered per 12-Training-Guide.md | Head of Planning |
| 14 | SOPs issued per 11-SOP.md | Head of Planning |
| 15 | On-call rota confirmed for the first 72 hours | Operations |

---

*DCOS — Planning & Scheduling — Deployment Notes — Internal Controlled Document*
