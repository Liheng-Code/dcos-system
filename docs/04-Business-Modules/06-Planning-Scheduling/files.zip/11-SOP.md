# 11 — Standard Operating Procedures

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-SOP-011 |
| Version | R0 |
| Process owner | Head of Planning |
| Related | DCOS-SOP-PLN-001 Preparation of the Project Schedule; DCOS-GDL-PLN-002 Schedule Setup Decisions |
| Status | For issue |

---

## 1. Purpose and structure

This document defines the operating procedures for using the Planning & Scheduling module across the project lifecycle. It is the in-system counterpart to the two controlled process documents already issued:

| Document | Covers | Relationship to this SOP |
|---|---|---|
| **DCOS-SOP-PLN-001** | The end-to-end process from award to approved baseline, including the Readiness Gate | Referenced, not repeated. SOP-PLN-A below is the in-system execution of its Stage 4. |
| **DCOS-GDL-PLN-002** | The seven setup decisions and how to make them | Referenced. SOP-PLN-A step 1 requires the signed Setup Decision Record. |

Procedures below are numbered SOP-PLN-A to SOP-PLN-J.

| Ref | Procedure | Frequency |
|---|---|---|
| SOP-PLN-A | Project schedule setup in DCOS | Once per project |
| SOP-PLN-B | Building the schedule | Once per project, then rolling wave |
| SOP-PLN-C | Baseline submission and approval | Per baseline |
| SOP-PLN-D | Monthly progress update | Monthly |
| SOP-PLN-E | Weekly look-ahead and work plan | Weekly |
| SOP-PLN-F | Post-baseline change control | Per change |
| SOP-PLN-G | Delay event and time impact analysis | Per event |
| SOP-PLN-H | Resource loading and levelling | Per baseline, then monthly |
| SOP-PLN-I | Programme issue and distribution | Per revision |
| SOP-PLN-J | Annual calendar maintenance | Annually |

---

## 2. SOP-PLN-A — Project schedule setup in DCOS

**Trigger:** Readiness Gate passed under SOP-PLN-001 §9.
**Prerequisite:** Signed Setup Decision Record (GDL-PLN-002 Appendix A).

| Step | Action | Responsible |
|---|---|---|
| A1 | Confirm the signed Setup Decision Record is on file. Do not proceed without it. | Planning Engineer |
| A2 | Create the project schedule and set the project scheduling settings: critical float threshold, out-of-sequence mode, roll-up weighting basis | Planning Engineer |
| A3 | Create calendars per decision G4. Verify the holiday list against the official gazette for every year the programme spans | Planning Engineer |
| A4 | Set the project default calendar and the default calendar per WBS node | Planning Engineer |
| A5 | Configure activity code types per decision G3, marking mandatory codes | Planning Engineer |
| A6 | Configure the activity ID mask per decision G2 | Planning Engineer |
| A7 | Confirm WBS is built and available (WBS Engine) | Planning Engineer |
| A8 | Set the data date convention and reporting cycle per decision G7 | Planning Engineer |
| A9 | Verify calendar arithmetic: create a test activity of 10 days on each calendar and confirm the finish dates differ correctly | Planning Engineer |
| A10 | Delete the test activities | Planning Engineer |

**Control:** Step A9 is not optional. A calendar error found now costs minutes; found after baseline it invalidates every date in the programme.

---

## 3. SOP-PLN-B — Building the schedule

| Step | Action | Responsible |
|---|---|---|
| B1 | Create activities within WBS nodes, using templates for repeating sets such as a typical floor cycle | Planning Engineer |
| B2 | Assign activity type, calendar, discipline, responsible party and all mandatory codes | Planning Engineer |
| B3 | Enter durations. Record the basis of estimate in the notes field of every activity | Planning Engineer |
| B4 | Confirm durations for each discipline with the relevant Discipline Manager | Discipline Managers |
| B5 | Assign the progress measurement method per activity class per decision G6 | Planning Engineer, QS |
| B6 | Link activities to BOQ items and allocate quantity where cost loading applies | Quantity Surveyor |
| B7 | Build logic working sequence by sequence **with the Construction Manager present** | Planning Engineer, Construction Manager |
| B8 | Apply constraints only where contractually required, entering the justification | Planning Engineer |
| B9 | Run CPM and review the critical path against the intended construction method | Planning Engineer |
| B10 | Confirm the critical path with the Construction Manager. If it does not reflect how the job will be built, the logic is wrong | Construction Manager |
| B11 | Compare the calculated completion against the contract date and quantify terminal float | Planning Engineer, PM |
| B12 | Where completion is late, review method, sequence and resource. **Do not compress durations arbitrarily** | Construction Manager, PM |
| B13 | Run the schedule health check and clear all blocking findings | Planning Engineer |
| B14 | Where scope is not yet defined, hold it at summary level under rolling wave and record the horizon | Planning Engineer |

**Prohibited:** reducing a duration without a corresponding change to method or resource. This is falsification and is escalated to the Operations Director (SOP-PLN-001 §17).

---

## 4. SOP-PLN-C — Baseline submission and approval

| Step | Action | Responsible |
|---|---|---|
| C1 | Run the schedule health check; resolve every blocking finding | Planning Engineer |
| C2 | Submit the baseline with code, name, type and data date | Planning Engineer |
| C3 | System re-runs the health check and stores the result with the submission | System |
| C4 | Review critical path, methodology alignment and resource profile | Construction Manager |
| C5 | Review commercial alignment, cost loading and milestone payment dates | Quantity Surveyor |
| C6 | Review and endorse | Project Manager |
| C7 | Quality assure against SOP-PLN-001 and this procedure | Head of Planning |
| C8 | Approve | Project Director |
| C9 | System captures the immutable snapshot and locks activity IDs and progress methods | System |
| C10 | Set as current comparison baseline | Planning Engineer |
| C11 | Issue to the client through the transmittal gate (SOP-PLN-I) | Document Controller |

**Control:** the user who submits a baseline may not approve it. Enforced by RBAC segregation of duties.

---

## 5. SOP-PLN-D — Monthly progress update

**Timeline:** five working days from data date to issued revision. Slippage compounds; a programme issued on day fifteen describes a situation that no longer exists.

| Day | Step | Action | Responsible |
|---|---|---|---|
| 0 | D1 | Confirm the data date with the Project Manager. Close all field tasks for the period | Planning Engineer, Site Supervisors |
| 1 | D2 | Open the progress update session. The data date locks | Planning Engineer |
| 1 | D3 | Review pre-populated values from task roll-up, checking the source indicator on each | Planning Engineer |
| 1 | D4 | Confirm measured quantities with the Quantity Surveyor | QS |
| 2 | D5 | Confirm remaining durations with each Discipline Manager | Discipline Managers |
| 2 | D6 | Resolve every out-of-sequence flag and record the decision | Planning Engineer |
| 3 | D7 | Run preview. Review forecast completion, float change and critical path movement | Planning Engineer |
| 3 | D8 | Discuss the impact with the Project Manager before committing | Planning Engineer, PM |
| 3 | D9 | Commit the session | Planning Engineer |
| 3 | D10 | Review negative float and critical path changes; initiate mitigation if required | PM |
| 4 | D11 | Produce variance, critical path, S-curve and delay reports | Planning Engineer |
| 4 | D12 | Reconcile programme percentage against the QS measured valuation percentage | Planning Engineer, QS |
| 5 | D13 | Issue the programme revision (SOP-PLN-I) | Document Controller |

**Control at D12:** if programme and valuation differ by more than three percentage points, resolve before issue. Do not let the divergence carry into a second month — by the third it is entrenched and each side defends its own number.

---

## 6. SOP-PLN-E — Weekly look-ahead and work plan

| Day | Step | Action | Responsible |
|---|---|---|---|
| Thu | E1 | Generate the six-week look-ahead from the current schedule | Planning Engineer |
| Thu | E2 | Review activities entering the window; identify constraints | Planning Engineer, Site Manager |
| Thu | E3 | Log every constraint with category, owner and required-by date | Site Manager |
| Fri | E4 | Make-ready meeting: review open constraints and assign clearance actions | Site Manager, discipline leads |
| Fri | E5 | Issue the look-ahead to site team and subcontractors | Planning Engineer |
| Mon | E6 | Weekly planning meeting: last planners commit to the coming week's work | Site Manager, subcontractors |
| Mon | E7 | Record commitments in the weekly work plan | Site Supervisor |
| Fri | E8 | Close the previous week's plan; mark each commitment met or not met | Site Supervisor |
| Fri | E9 | Record a reason-for-variance code against every unmet commitment | Site Supervisor |
| Fri | E10 | Review PPC and the top three variance reasons | Site Manager |

**Rule:** only activities with all constraints cleared may be committed in a weekly work plan. Committing constrained work is the primary cause of low PPC.

---

## 7. SOP-PLN-F — Post-baseline change control

| Step | Action | Responsible |
|---|---|---|
| F1 | Record the trigger: variation, employer's instruction, delay event, acceleration or design change | Contract Administrator |
| F2 | Create a schedule scenario from the current live schedule | Planning Engineer |
| F3 | Apply the change **within the scenario only** | Planning Engineer |
| F4 | Run CPM on the scenario and quantify the completion impact | Planning Engineer |
| F5 | Produce the impact assessment with the commercial effect | Planning Engineer, QS |
| F6 | Review | Project Manager |
| F7 | Approve | Project Director |
| F8 | Merge the approved scenario into the live schedule, resolving any conflicts | Planning Engineer |
| F9 | Confirm schedule revision records created with reason and approval reference | Planning Engineer |
| F10 | Take a new baseline if the contract requires it (SOP-PLN-C) | Project Manager |
| F11 | Issue the revised programme with the supporting contractual notice | Contract Administrator |

**Never edit the live schedule directly for an assessed change.** The scenario is what makes the before-and-after position provable.

---

## 8. SOP-PLN-G — Delay event and time impact analysis

| Step | Action | Responsible |
|---|---|---|
| G1 | Record the delay event immediately: date, cause, category, evidence | Contract Administrator |
| G2 | Check the contractual notice period. Issue the notice within the time bar | Contract Administrator |
| G3 | Create a scenario from the last update **immediately preceding the event** | Planning Engineer |
| G4 | Construct the fragnet representing the delay | Planning Engineer |
| G5 | Insert the fragnet at the correct network position | Planning Engineer |
| G6 | Run CPM on the scenario | Planning Engineer |
| G7 | Compare scenario completion against source completion; record net impact | Planning Engineer |
| G8 | Where concurrent contractor delay exists, model it as a second fragnet and distinguish the two | Planning Engineer |
| G9 | Produce the TIA output: event, fragnet, affected activities, critical path before and after, net impact | Planning Engineer |
| G10 | Link supporting evidence: daily reports, photographs, correspondence, RFIs | Contract Administrator |
| G11 | Submit the claim | Contract Administrator |
| G12 | Retain the scenario permanently | System |

**Control at G2:** notice periods are time-barred. A valid entitlement lost to a missed notice is the most expensive failure in this procedure, and it is entirely avoidable.

---

## 9. SOP-PLN-H — Resource loading and levelling

| Step | Action | Responsible |
|---|---|---|
| H1 | Assign a norm code and quantity to each labour-bearing activity | Planning Engineer |
| H2 | Set site factor and efficiency factor per activity or activity group | Planning Engineer |
| H3 | Review calculated crew sizes against the Construction Manager's expectation | Construction Manager |
| H4 | Review activities flagged under-resourced; correct crew or duration | Planning Engineer |
| H5 | Generate the manpower histogram, total and by trade | Planning Engineer |
| H6 | Enter available headcount per period — what can genuinely be mobilised, accommodated, transported and supervised | Construction Manager |
| H7 | Review the levelling check for OVER CAPACITY and AT LIMIT periods | Planning Engineer, Construction Manager |
| H8 | Level in order of preference: re-sequence, extend non-critical durations, split by zone, subcontract, add shift, accept later completion | Planning Engineer |
| H9 | Review the trade histogram to confirm each subcontractor is being asked for a realistic and steady commitment | Construction Manager |
| H10 | Reconcile actual man-hours against planned monthly and report productivity | Planning Engineer |

**Prohibited:** solving a resource peak by reducing the productivity norm. That is not levelling; it is falsifying the labour content, and it surfaces later as an indefensible productivity claim.

---

## 10. SOP-PLN-I — Programme issue and distribution

| Step | Action | Responsible |
|---|---|---|
| I1 | Confirm the revision number and data date | Planning Engineer |
| I2 | Generate the paginated PDF at the contractually required paper size | Planning Engineer |
| I3 | Verify the title block: project, revision, data date, prepared / checked / approved | Planning Engineer |
| I4 | Attach the variance report and, where required, the health check report | Planning Engineer |
| I5 | Submit through the Document Control transmittal gate | Document Controller |
| I6 | Record the submission date and the contractual response period | Planning Engineer |
| I7 | Log client or consultant comments on receipt | Planning Engineer |
| I8 | Assess each comment for contractual and programme effect **before** accepting it | Planning Engineer, PM |
| I9 | Escalate any comment that would change the method or the completion date | Project Manager |
| I10 | Issue the response schedule recording what was accepted, what was rejected and why | Planning Engineer |
| I11 | Distribute internally to project team and subcontractors | Document Controller |

**Control at I8:** a client comment that changes logic or shortens a duration may transfer risk. Comments are assessed, never incorporated uncritically.

---

## 11. SOP-PLN-J — Annual calendar maintenance

**Trigger:** November each year, for the following calendar year.

| Step | Action | Responsible |
|---|---|---|
| J1 | Obtain the official public holiday gazette for the following year | HR |
| J2 | Compare against the seeded indicative dates, particularly lunar holidays | Planning Engineer |
| J3 | Update holiday exceptions on every affected calendar | Planning Engineer |
| J4 | Mark updated entries as gazette-confirmed | Planning Engineer |
| J5 | Notify Project Managers that a portfolio recalculation will run | Head of Planning |
| J6 | Schedule the recalculation outside working hours | Operations |
| J7 | Review affected projects for date movement and notify where completion shifts | Planning Engineer |

**Note:** Khmer New Year, Meak Bochea, Visak Bochea, Royal Ploughing, Pchum Ben and Water Festival are lunar and move each year. Assuming last year's dates is a recurring source of programme error.

---

## 12. Roles summary

| Role | Owns |
|---|---|
| Head of Planning | Process governance, quality assurance, standards, annual calendar |
| Planning Engineer | All schedule build, update, analysis and reporting activity |
| Project Manager | Endorsement, constraint approval, change review, mitigation decisions |
| Project Director | Baseline and change approval |
| Construction Manager | Methodology, sequence confirmation, resource availability, critical path validation |
| Discipline Manager | Duration and remaining duration confirmation for own scope |
| Site Supervisor | Field progress capture, weekly commitments, constraint identification |
| Quantity Surveyor | Measurement basis, cost loading, valuation reconciliation |
| Contract Administrator | Delay events, notices, claims, TIA submission |
| Document Controller | Programme issue, transmittal, distribution, archive |

---

## 13. Non-compliance

| Breach | Classification | Escalation |
|---|---|---|
| Building a schedule before the Readiness Gate is passed | Procedural | Head of Planning |
| Issuing a programme without a signed Basis of Schedule | Procedural | Head of Planning |
| Compressing durations without a method or resource change | **Serious** | Operations Director |
| Applying a hard constraint without written justification | Procedural | Project Manager |
| Editing the live schedule directly for an assessed change | **Serious** | Head of Planning |
| Missing a contractual notice period on a delay event | **Serious** | Commercial Director |
| Reducing a productivity norm to resolve a resource peak | **Serious** | Operations Director |
| Data date more than 45 days old | **Serious** | Project Director |

---

## 14. Records and retention

| Record | Owner | Retention |
|---|---|---|
| Setup Decision Record | Planning Engineer | Project + DLP + 5 years |
| Basis of Schedule (signed) | Planning Engineer | Project + DLP + 5 years |
| Schedule health check reports | Planning Engineer | All baseline submissions retained 5 years |
| Approved baselines | System | Permanent |
| Progress history | System | Project + DLP + 5 years |
| Schedule revisions | System | Permanent |
| Scenarios and TIA outputs | System | Permanent |
| Delay event register | Contract Administrator | Permanent |
| Issued programme revisions and transmittals | Document Controller | Project + DLP + 10 years |
| Weekly work plans and PPC records | Site Supervisor | Project + 2 years |

---

## 15. Key performance indicators

| KPI | Target |
|---|---|
| Programme revision issued within 5 working days of data date | ≥90% |
| Data date currency (days since last update) | ≤35 |
| Health check passed at baseline submission, first attempt | ≥60% |
| Programme vs QS measured percentage variance | ≤3 points |
| Progress captured from field tasks rather than retyped | ≥80% |
| Percent Plan Complete | ≥80% |
| Delay events with notice issued within the time bar | 100% |
| Delay events with contemporaneous schedule evidence | 100% |
| Open constraints cleared before commitment | ≥90% |
| Baselines with a signed Basis of Schedule | 100% |

---

*DCOS — Planning & Scheduling — Standard Operating Procedures — Internal Controlled Document*
