# 01 — Business Requirement

**Module:** Planning & Scheduling (Module 23 of the DCOS 50-module map)

| Field | Value |
|---|---|
| Document code | DCOS-PLN-BRD-001 |
| Module code | PLN |
| Version | R0 — Initial issue |
| Parent | DCOS System Architecture Module Design R0 |
| Related | DCOS Gap Analysis R1 §3.4 "Gantt without CPM engine" |
| Classification | Internal — Strategic Architecture |
| Status | For review |

---

## 1. Executive summary

The Planning & Scheduling module is the time-control engine of DCOS. It answers four questions that no other module can answer: **when will this project finish, what is driving that date, what happens if something slips, and can we prove it.**

The R0 architecture listed Gantt view, baseline vs actual, S-curve and look-ahead as features. Those are outputs. The Gap Analysis correctly identified that R0 described the display without describing the engine — there was no critical path method, no float calculation, no schedule impact propagation. A Gantt without a CPM engine is a drawing tool.

This module closes that gap. It is scored **Partial — add CPM engine** in the Gap Analysis revised module map (No. 23, Execution phase) and is a hard dependency of Earned Value Management, Claims & Disputes, and Contract Administration.

---

## 2. Business context

### 2.1 The problem in the current state

| Current practice | Consequence |
|---|---|
| Programme maintained in Primavera P6 or Microsoft Project on one planner's laptop | Single point of failure. No one else can see the current position. |
| Progress collected on paper or WhatsApp, retyped into the schedule | Two to three week lag between site reality and reported position |
| Site works to a printed bar chart that is weeks out of date | The programme becomes a wall decoration, not a control document |
| Delay events recorded after the fact, from memory | Extension of time claims fail for want of contemporaneous records |
| Programme percentage and QS valuation percentage differ | Every progress meeting is an argument about which number is right |
| Look-ahead produced manually in Excel each week | Six to eight hours of planner time per week producing a document that is stale on issue |
| No float visibility below the planner | Managers cannot tell which of their late activities actually matter |

### 2.2 Why construction scheduling is different from generic project scheduling

| Construction reality | Requirement it creates |
|---|---|
| Work happens in a **location**, and location drives sequence | Schedule must bind to the WBS location spine, not just a task list |
| A 6-day site week, a 5-day design office, and 7-day concrete curing coexist | Multi-calendar scheduling with correct multi-calendar float |
| Progress is **measured**, not estimated — the QS re-measures monthly | Units-complete progress tied to BOQ quantities |
| Delay is litigated years later | Immutable baselines, progress history, and schedule scenarios for time impact analysis |
| Site staff have phones, not laptops, and often no signal | Offline-capable progress capture from the field |
| Subcontractors commit weekly, not to a 3,000-line CPM | Two-tier planning: master CPM plus Last Planner weekly commitment |
| Clients demand contractual programme submissions | Formal revision control, transmittal issue, and P6 interchange |
| Out-of-sequence progress is universal | Retained logic / progress override handling as a project setting |

---

## 3. Business objectives

| Ref | Objective | Measure of success |
|---|---|---|
| BO-PLN-01 | Produce a contractually defensible programme | 100% of projects baselined with signed Basis of Schedule before Phase 2 work starts |
| BO-PLN-02 | Make the true completion date visible and current | Programme revision issued within 5 working days of every data date |
| BO-PLN-03 | Make delay demonstrable and recoverable | Every delay event linked to affected activities with contemporaneous evidence |
| BO-PLN-04 | Connect the programme to cost | ≥90% of cost-bearing activities linked to BOQ items |
| BO-PLN-05 | Connect the programme to the field | ≥80% of progress captured from field tasks rather than retyped |
| BO-PLN-06 | Reconcile programme and valuation | Programme % and QS measured % within 3 percentage points at every IPC |
| BO-PLN-07 | Reduce planner effort | Look-ahead generated in under 10 minutes, not 6 hours |
| BO-PLN-08 | Improve schedule reliability | Percent Plan Complete ≥80% within 6 months of go-live |
| BO-PLN-09 | Enable portfolio time control | Consistent activity coding permitting cross-project resource and progress reporting |
| BO-PLN-10 | Prevent schedule corruption | Zero unjustified hard constraints; DCMA health check passed at every baseline |

---

## 4. Stakeholders

| Stakeholder | Interest in this module | Primary need |
|---|---|---|
| Project Director | Portfolio completion dates, exposure to damages | Reliable forecast completion, early warning |
| Project Manager | Day-to-day control of time | Critical path, float, delay impact, look-ahead |
| Head of Planning | Process governance and quality | Health checks, standards compliance, planner productivity |
| Planning Engineer | Primary user | Efficient build, update and reporting; no double entry |
| Construction Manager | Buildability and sequence | Schedule reflects the intended method; resource profile achievable |
| Discipline Managers | Workload and deliverables | Filtered view of their scope, response deadlines |
| Site Supervisor | Weekly execution | Simple task list, mobile progress entry, no CPM exposure |
| Quantity Surveyor | Valuation and cost control | Measured progress that reconciles to the IPC |
| Procurement Manager | Required-on-site dates | Lead-time-driven order dates derived from the programme |
| Contract Administrator | Entitlement and notices | Time impact analysis, contemporaneous records, notice triggers |
| Subcontractor | Their scope and commitments | Their activities only, weekly work plan, constraint log |
| Client / Consultant | Programme review and acceptance | Issued revisions, progress reporting, variance against baseline |

---

## 5. Business capabilities required

| Ref | Capability | Business justification | Priority |
|---|---|---|---|
| BC-01 | Multi-calendar working time | Design, site, curing and authority activities have different working patterns; using one calendar understates the programme by weeks | Must |
| BC-02 | Activity definition and classification | The unit of schedule control; see DCOS-PLN-AM-001 | Must |
| BC-03 | Logic network with FS/SS/FF/SF and lag | The relationships that make a schedule a network rather than a list | Must |
| BC-04 | CPM forward and backward pass | Produces dates, float and critical path — the core of time control | Must |
| BC-05 | Multi-calendar float and longest path | Float across mixed calendars is otherwise wrong and invisibly so | Must |
| BC-06 | Constraint management with governance | Constraints are legitimate but are the main route to silent schedule corruption | Must |
| BC-07 | Baseline snapshot and variance | The reference against which all delay is measured | Must |
| BC-08 | Progress capture and update cycle | Turns a plan into a control document | Must |
| BC-09 | Progress measurement methods | Determines whether earned value is possible at all | Must |
| BC-10 | Look-ahead generation | The document site actually uses | Must |
| BC-11 | Last Planner weekly work plan and PPC | Best leading indicator of schedule reliability available | Should |
| BC-12 | Schedule health validation (DCMA 14) | Quality gate accepted by clients and delay analysts | Must |
| BC-13 | Resource loading and histogram | Labour planning, welfare sizing, subcontract commitment | Should |
| BC-14 | Cost loading and S-curve | Cash flow forecast and earned value denominator | Should |
| BC-15 | Schedule scenarios (what-if) | Time impact analysis, recovery planning, acceleration options | Must |
| BC-16 | Delay event register and TIA | Extension of time entitlement recovery | Should |
| BC-17 | Gantt visualisation | Primary planner interface and the contractual deliverable format | Must |
| BC-18 | Programme revision control and issue | Contractual submission and audit trail | Must |
| BC-19 | P6 / MSP interchange | Client and consultant contractual requirement | Should |
| BC-20 | Mobile offline progress capture | Site staff cannot carry laptops | Must |

---

## 6. Business rules (business level)

| Ref | Rule |
|---|---|
| BBR-01 | No project proceeds to Phase 2 execution without an approved baseline programme. |
| BBR-02 | The Basis of Schedule must be signed by the Construction Manager before schedule development begins. |
| BBR-03 | The programme data date must equal the interim payment certificate measurement cut-off. |
| BBR-04 | Durations must derive from measured quantity and a stated output rate wherever a quantity exists. |
| BBR-05 | Compressing a duration without a corresponding change to method or resource is prohibited. |
| BBR-06 | Hard constraints require written justification; mandatory constraints require Project Manager approval. |
| BBR-07 | Logic editing and progress entry are separate authorities and may be held by different people. |
| BBR-08 | Any post-baseline change to duration, logic, calendar or constraint creates a schedule revision record. |
| BBR-09 | Baselines are immutable. A superseded baseline is retained, never overwritten. |
| BBR-10 | Delay analysis is performed on a schedule scenario, never on the live schedule. |
| BBR-11 | The schedule health check must pass before a baseline is submitted for approval. |
| BBR-12 | Programme revisions are issued to external parties only through the document transmittal gate. |

---

## 7. Scope

### 7.1 In scope

- Calendar definition and working-time arithmetic
- Activity management (per DCOS-PLN-AM-001)
- Schedule logic and network validation
- CPM calculation, float and critical path
- Constraints and constraint governance
- Baseline management and variance
- Progress update cycle and progress history
- Look-ahead, weekly work plan and PPC
- Resource and cost loading, histogram and S-curve
- Schedule scenarios, time impact analysis, recovery planning
- Schedule health validation
- Gantt, table and dashboard visualisation
- Programme revision control and issue
- Import/export including P6 XER and MSPDI
- Mobile progress capture

### 7.2 Out of scope

| Excluded | Owning module |
|---|---|
| WBS node definition and hierarchy | WBS Engine |
| BOQ item structure and measurement | BOQ Engine |
| Earned value formulae and reporting | EVM Module |
| Field task assignment and daily instruction | Construction Management |
| Resource pool, rates and payroll | HR Module |
| Contract notices and entitlement register | Contract Administration |
| Document register, revision and transmittal mechanics | Document Control |
| Approval workflow, notification, audit engines | Platform Core |
| Cost accounting and payment | Account / Finance |

### 7.3 Assumptions

| Ref | Assumption | Risk if wrong |
|---|---|---|
| AS-01 | WBS Engine and Calendar Engine are delivered before this module | Module cannot function; dates and roll-up impossible |
| AS-02 | BOQ Engine delivered in Phase 2 as per Gap Analysis | Units-complete progress and cost loading deferred |
| AS-03 | Projects operate a monthly update cycle aligned to the IPC | Reporting and valuation diverge |
| AS-04 | Typical project ≤5,000 activities; largest ≤50,000 | Architecture and performance targets need revision |
| AS-05 | Clients accept a DCOS-produced programme, or accept XER export | P6 becomes the master and DCOS becomes a mirror — different module |

### 7.4 Constraints

- Multi-tenant row-level security applies to every table.
- Modular monolith architecture; no separate scheduling microservice at MVP.
- Supabase/PostgreSQL at MVP, NestJS at scale.
- CPM calculation must run server-side; browser-side calculation is not viable at scale.
- Mobile must operate offline with local-first write.

---

## 8. Success criteria

| Ref | Criterion | Target |
|---|---|---|
| SC-01 | Baseline programme produced within the contractual submission period | 100% of projects |
| SC-02 | Programme revision issued within 5 working days of data date | ≥90% of update cycles |
| SC-03 | CPM recalculation, 5,000 activities | < 3 seconds |
| SC-04 | Schedule health check passed at baseline | 100% of baselines |
| SC-05 | Progress captured from field tasks rather than retyped | ≥80% |
| SC-06 | Programme % vs QS measured % variance | ≤3 percentage points |
| SC-07 | Planner time to produce weekly look-ahead | < 10 minutes |
| SC-08 | Percent Plan Complete after 6 months | ≥80% |
| SC-09 | Delay events with contemporaneous schedule evidence | 100% |
| SC-10 | Planner adoption — projects using DCOS as master schedule | ≥80% within 12 months |

---

## 9. Benefits

| Benefit | Basis |
|---|---|
| Recovery of extension-of-time entitlement | Contemporaneous activity-level records and TIA capability; a single successful EOT claim typically exceeds the module's build cost |
| Avoidance of liquidated damages | Earlier visibility of critical path slippage permits mitigation while mitigation is still cheap |
| Reduced planner cost per project | Automated look-ahead, health check and reporting removes an estimated 30–40% of planner effort |
| Faster, cleaner valuation | Programme and IPC reconcile from the same measured quantities |
| Better subcontractor performance | Realistic, steady labour commitments from the resource histogram; weekly commitment tracking via PPC |
| Institutional productivity data | Actual output rates accumulate as a norms library, improving future tender pricing |

---

## 10. Dependencies and phasing

| Phase | Scope | Gap Analysis reference |
|---|---|---|
| Phase 1 | Calendar Engine, Activity Management, Schedule Logic, CPM Engine, Baseline, basic Gantt, progress update | Prerequisite for all time control |
| Phase 2 | BOQ linkage, cost loading, S-curve, look-ahead, health check, revision control | Concurrent with BOQ Engine |
| Phase 3 | Resource loading and histogram, mobile progress capture, Last Planner and PPC, P6 interchange | Planning & Scheduling + CPM listed Phase 3 |
| Phase 4 | Schedule scenarios, time impact analysis, EVM integration, delay register | EVM listed Phase 4 |
| Phase 5 | Resource levelling, Monte Carlo risk analysis, 4D BIM linkage, duration prediction | Intelligence layer |

---

## 11. Open items

| Ref | Item | Owner | Required by |
|---|---|---|---|
| OI-01 | Is DCOS the master schedule, or a mirror of an externally maintained P6 programme? | Project Director | Before build |
| OI-02 | Retained logic vs progress override default | Head of Planning | Before CPM build |
| OI-03 | WBS progress roll-up weighting basis | Quantity Surveyor | Before build |
| OI-04 | Critical float threshold (zero assumed) | Contract Administrator | Before baseline |
| OI-05 | Gantt component: build in house or license | Lead Developer | Before build |
| OI-06 | Calendar set at first release, including wet season treatment | Head of Planning | Before calendar build |
| OI-07 | Activity-to-field-task contract signed with Construction module owner | System Architect | Before Phase 3 |

---

*DCOS — Planning & Scheduling — Business Requirement — Internal Controlled Document*
