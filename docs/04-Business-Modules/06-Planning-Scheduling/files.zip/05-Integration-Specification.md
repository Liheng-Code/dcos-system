# 05 — Integration Specification

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-INT-005 |
| Version | R0 |
| Related | Gap Analysis R1 §4.14 Integration Layer Design |
| Status | For development |

---

## 1. Integration principles

| Principle | Application |
|---|---|
| Events, not polling | State changes publish domain events; consumers subscribe. No module polls the schedule. |
| One direction per fact | Progress flows task → activity → WBS. Never the reverse. |
| Read models, not shared tables | Consumers read via API or projection, never by querying `activities` directly. |
| Idempotent consumption | Every event carries an `event_id`; consumers must tolerate redelivery. |
| Tenant context on every message | `tenant_id` and `project_id` in the envelope; never inferred. |
| Calculated data is read-only outbound | Dates, float and criticality leave the module; nothing writes them from outside. |

---

## 2. Internal integration matrix

| # | Module | Direction | Data | Trigger | Sync/Async |
|---|---|---|---|---|---|
| I-01 | WBS Engine | In | `wbs_node_id`, node path, default calendar | Activity create / WBS move | Sync |
| I-02 | WBS Engine | Out | Activity progress and budget value for roll-up | Progress commit, CPM complete | Async |
| I-03 | Calendar Engine | In | Calendar definition, working-day set | Every date calculation | Sync |
| I-04 | Construction Management | In | Field task actual dates, installed quantity | Task closure | Async |
| I-05 | Construction Management | Out | Activity window, responsible party, WBS context | Look-ahead generation | Sync |
| I-06 | QA/QC | In | Inspection result, open NCR status | Activity closure attempt | Sync |
| I-07 | QA/QC | Out | Activity reference for inspection request | Inspection raised | Async |
| I-08 | Procurement | Out | Activity early start → required-on-site date | Schedule recalculation | Async |
| I-09 | Procurement | In | Confirmed delivery date | Delivery confirmed | Async |
| I-10 | BOQ Engine | In | BOQ item, quantity, unit rate | Activity–BOQ linkage | Sync |
| I-11 | BOQ Engine | Out | Measured quantity by period | IPC preparation | Async |
| I-12 | EVM Module | Out | Budget value, % complete, planned value curve | Period end | Async |
| I-13 | Contract Administration | Out | Delay event impact, TIA output, critical path change | TIA complete | Async |
| I-14 | Contract Administration | In | Employer's instruction, variation order reference | Instruction issued | Async |
| I-15 | Document Control | Out | Programme revision for transmittal | Revision issued | Sync |
| I-16 | Document Control | In | Drawing IFC status | Drawing issued | Async |
| I-17 | HR Module | Out | Labour demand by trade and period | Histogram recalculated | Async |
| I-18 | HR Module | In | Available headcount by trade | Resource plan updated | Async |
| I-19 | Equipment Module | Out | Plant demand by period | Resource loading | Async |
| I-20 | Approval Workflow Engine | Out | Baseline, constraint, revision approvals | Submission | Sync |
| I-21 | Notification Engine | Out | All schedule events per §6 | Event occurrence | Async |
| I-22 | Audit Trail Engine | Out | Every schedule-affecting change | Every write | Async |
| I-23 | Reporting Engine | Out | Activity dataset for S-curve, look-ahead, delay reports | Report generation | Sync |
| I-24 | Mobile Field App | Both | Assigned activities, progress capture, offline queue | Sync cycle | Async |
| I-25 | RBAC Engine | In | Effective permission set | Every request | Sync |

---

## 3. Domain events published

Envelope common to all events:

```json
{
  "event_id": "evt_01HZX...",
  "event_type": "schedule.activity.progress_recorded",
  "event_version": "1.0",
  "tenant_id": "cmp_01HZX...",
  "project_id": "prj_001",
  "occurred_at": "2027-09-25T09:15:22Z",
  "actor": { "user_id": "usr_...", "role": "PLANNER", "channel": "WEB" },
  "correlation_id": "cor_01HZX...",
  "payload": { }
}
```

| Event type | Published when | Key payload | Primary consumers |
|---|---|---|---|
| `schedule.activity.created` | Activity saved | activity_id, wbs_node_id, duration, calendar | WBS, Audit |
| `schedule.activity.updated` | Attribute change | changed_fields, before, after | Audit, EVM |
| `schedule.activity.deleted` | Soft delete | activity_id, reason | Construction, Audit |
| `schedule.activity.progress_recorded` | Progress written | percent, remaining_duration, installed_qty, data_date | WBS, BOQ, EVM, Reporting |
| `schedule.activity.status_changed` | Lifecycle transition | from, to, reason | Construction, QA/QC |
| `schedule.logic.changed` | Relationship added/edited/removed | predecessor, successor, type, lag | Audit |
| `schedule.calculation.completed` | CPM run finishes | run_id, project_finish, critical_count, negative_float_count | Procurement, Reporting, Notification |
| `schedule.criticalpath.changed` | Critical path membership changes | added[], removed[] | Notification, Contract Admin |
| `schedule.float.negative` | Negative float detected | activities[], driving_cause | Notification, Contract Admin |
| `schedule.constraint.applied` | Constraint set | activity_id, type, date, justification | Audit, Notification |
| `schedule.baseline.approved` | Baseline approved | baseline_id, data_date, project_finish | Document Control, EVM, Reporting |
| `schedule.revision.created` | Post-baseline change | revision_no, change_type, trigger_reference | Contract Admin, Audit |
| `schedule.lookahead.generated` | Look-ahead produced | window_start, window_end, activity_count | Construction, Notification |
| `schedule.commitment.recorded` | Weekly work plan committed | wwp_id, commitments[] | Construction |
| `schedule.ppc.calculated` | PPC computed for a week | week, ppc_percent, top_variance_reasons | Reporting |
| `schedule.delay.assessed` | TIA completed | delay_event_id, net_impact_days, scenario_id | Contract Admin |
| `schedule.resource.demand_changed` | Histogram recalculated | period, trade, average_men, peak_men | HR, Equipment |

---

## 4. Events consumed

| Event | Source | Action taken |
|---|---|---|
| `construction.task.closed` | Construction | Roll installed quantity and actual dates up to the parent activity |
| `construction.task.progress_updated` | Construction | Update pre-populated progress for the next session |
| `wbs.node.moved` | WBS Engine | Update activity WBS path; refresh roll-up |
| `wbs.node.archived` | WBS Engine | Block new activity creation under the node |
| `calendar.exception.changed` | Calendar Engine | Queue CPM recalculation for affected projects |
| `boq.item.revised` | BOQ Engine | Recalculate activity budget value; flag allocation variance |
| `qaqc.ncr.closed` | QA/QC | Permit activity transition to Closed |
| `qaqc.inspection.failed` | QA/QC | Block activity closure; flag on the Gantt |
| `procurement.delivery.confirmed` | Procurement | Clear the related make-ready constraint |
| `contract.instruction.issued` | Contract Admin | Create a change trigger for schedule revision |
| `document.drawing.issued_for_construction` | Document Control | Clear the related design constraint in the make-ready log |
| `hr.availability.updated` | HR | Refresh the resource levelling check |

---

## 5. Representative payloads

### 5.1 Progress recorded (outbound)

```json
{
  "event_type": "schedule.activity.progress_recorded",
  "payload": {
    "activity_id": "act_01HZX...",
    "activity_code": "5000-STR-0120",
    "wbs_node_id": "wbs_01HZX...",
    "data_date": "2027-09-25",
    "progress_method": "UNIT",
    "total_quantity": 900,
    "installed_quantity": 340,
    "percent_complete": 37.8,
    "remaining_duration": 6,
    "actual_start": "2027-09-01",
    "actual_finish": null,
    "source_channel": "TASK_ROLLUP",
    "budget_value": 148500.00,
    "earned_value": 56133.00
  }
}
```

### 5.2 Required-on-site date (outbound to Procurement)

```json
{
  "event_type": "schedule.calculation.completed",
  "payload": {
    "run_id": "run_01HZX...",
    "project_finish": "2028-03-09",
    "required_on_site": [
      {
        "activity_id": "act_...",
        "activity_code": "7060-MEP-0210",
        "activity_name": "Lift car and machinery installation",
        "early_start": "2027-10-04",
        "late_start": "2027-10-18",
        "total_float": 12,
        "is_critical": false,
        "boq_items": ["boq_lift_pkg_01"]
      }
    ]
  }
}
```

### 5.3 Field task roll-up (inbound from Construction)

```json
{
  "event_type": "construction.task.closed",
  "payload": {
    "task_id": "tsk_01HZX...",
    "activity_id": "act_01HZX...",
    "actual_start": "2027-09-03",
    "actual_finish": "2027-09-05",
    "installed_quantity": 120,
    "unit_of_measure": "m2",
    "gang_id": "gng_003",
    "inspection_request_id": "ir_2214"
  }
}
```

**Roll-up rule applied on receipt:** where the parent activity's `progress_method = UNIT`, activity `installed_quantity` becomes the sum of linked task quantities and `percent_complete` is derived and read-only. Where the method is `PHYS` or `STEP`, the task data is advisory and does not overwrite the entered value.

---

## 6. Notification triggers

Consumed from the shared Notification Engine. No notification logic is implemented in this module.

| Trigger | Recipients | Priority | Channels |
|---|---|---|---|
| Activity assigned | Responsible user, discipline manager | Normal | In-app, Telegram |
| Activity not started by late start | Responsible, planner, PM | High | In-app, email, Telegram |
| Critical activity not started by early start | Responsible, planner, PM | High | In-app, email, Telegram |
| Total float becomes negative | Planner, PM, Project Director | **Critical** | In-app, email, Telegram |
| Critical path changed | Planner, PM | High | In-app, email |
| Hard constraint applied | PM | High | In-app, email |
| Mandatory constraint requested | PM (for approval) | Critical | In-app, email |
| Out-of-sequence progress detected | Planner | Normal | In-app |
| Progress not reported by cut-off | Responsible, discipline manager | High | In-app, email |
| Health check blocking failure | Planner | High | In-app |
| Baseline submitted | PM, Project Director | High | In-app, email |
| Baseline approved | Project team | Normal | In-app, email |
| Programme revision issued | Project team, client if external | High | In-app, email |
| Look-ahead published | Site team, subcontractors | Normal | In-app, Telegram |
| Weekly commitment missed | Last planner, site manager | Normal | In-app |
| Delay event assessed | Contract Administrator, PM, Project Director | Critical | In-app, email |
| Resource over-capacity in a period | Planner, Construction Manager | High | In-app, email |

---

## 7. External integration

### 7.1 Primavera P6 (XER)

| Aspect | Specification |
|---|---|
| Direction | Import and export |
| Format | XER (tab-delimited), P6 version 15.2 and later |
| Mapped entities | PROJECT, PROJWBS, TASK, TASKPRED, CALENDAR, PROJECT calendars, UDF, ACTVTYPE, ACTVCODE, TASKACTV, TASKRSRC |
| Preserved on round trip | Activity ID, name, type, duration, calendar, constraint type and date, codes, logic type and lag, % complete, actual dates |
| Not preserved | DCOS-specific fields (progress method, BOQ links, WBS scope) — exported as UDFs |
| Identifier limit | Activity ID truncated at 20 characters; import rejects any truncation that would create a duplicate |
| Calendar mapping | Matched by name; unmatched calendars listed in the mapping report and require manual assignment |
| Validation | Cycle detection and duplicate ID check run before commit |

### 7.2 Microsoft Project (MSPDI)

| Aspect | Specification |
|---|---|
| Direction | Import and export |
| Format | MSPDI XML (`.xml`), Project 2010 and later |
| Limitation | MSP has no direct equivalent of retained logic/progress override; the setting is exported as a project note |
| Limitation | MSP calendars do not support hours-per-day variation by weekday in the same way; differences are reported |

### 7.3 CSV / Excel

| Aspect | Specification |
|---|---|
| Direction | Import and export |
| Template | Published column template with header validation |
| Validation report | Produced before commit, listing row, column, rule reference and message |
| Behaviour | All-or-nothing commit; a single invalid row rejects the batch (BR-AM-033) |

### 7.4 Future external targets

| Target | Purpose | Priority | Phase |
|---|---|---|---|
| ERP / accounting | Cost actuals for earned value | High | 5 |
| BIM (Navisworks / Revit) | 4D sequence linkage of activities to model elements | Medium | 5 |
| Telegram Bot | Look-ahead push, progress prompt, overdue alert | High | 3 |
| Weather API | Actual weather record against daily reports for claims evidence | Low | 5 |
| IoT sensors | Concrete maturity to release curing activities automatically | Low | 5 |

---

## 8. API contract for consumers

| Consumer need | Endpoint | Notes |
|---|---|---|
| Current activity dates | `GET /api/activities/:id` | Includes latest schedule results |
| Activities in a window | `GET /api/projects/:id/look-ahead?weeks=6` | Read model, cached |
| Required-on-site dates | `GET /api/projects/:id/required-on-site` | Derived from early start less lead time |
| Progress for a period | `GET /api/projects/:id/progress?from=&to=` | For IPC measurement |
| Baseline comparison | `GET /api/projects/:id/variance?baseline=` | For client reporting |
| Resource demand | `GET /api/projects/:id/resource-demand?by=trade` | For HR and Equipment |

Full definitions in **08-API-Reference.md**.

---

## 9. Error handling and resilience

| Scenario | Behaviour |
|---|---|
| Calendar Engine unavailable | Schedule reads succeed from cache; all writes that require date arithmetic are rejected with a clear message. No silent fallback to a default calendar. |
| CPM engine unavailable | Edits are accepted and queued; the schedule displays a stale-results banner with the last calculation timestamp. |
| BOQ Engine unavailable | Activity–BOQ linkage is disabled; existing links and budget values continue to display from the last snapshot. |
| Construction module unavailable | Progress sessions open without pre-population; manual entry remains available. |
| Notification Engine unavailable | Events are queued and retried; schedule operations are never blocked. |
| Event consumer failure | Dead-letter queue with alert to platform admin; events retained 30 days for replay. |
| Duplicate event delivery | Consumers deduplicate on `event_id`; all handlers are idempotent. |

---

## 10. Integration testing requirements

| Ref | Test | Expected |
|---|---|---|
| IT-01 | Close a field task with quantity | Parent activity `installed_quantity` and `percent_complete` update within 5 s |
| IT-02 | Move a WBS node | Activity WBS path updates; roll-up recalculates; logic unaffected |
| IT-03 | Change a calendar holiday | Affected projects queue recalculation; dates shift correctly |
| IT-04 | Approve a baseline | Document Control receives the revision; EVM receives the planned value curve |
| IT-05 | CPM produces negative float | Notification dispatched to Planner, PM and Project Director within 30 s |
| IT-06 | Close an NCR on a blocked activity | Activity becomes eligible for Closed status |
| IT-07 | P6 XER round trip, 3,000 activities | No loss of ID, duration, calendar, constraint, code or logic |
| IT-08 | Replay a duplicate progress event | No double-counting; single history row |
| IT-09 | Cross-tenant event injection | Rejected; security audit event raised |
| IT-10 | CPM engine offline during an edit | Edit accepted, stale banner shown, recalculation runs on recovery |

---

*DCOS — Planning & Scheduling — Integration Specification — Internal Controlled Document*
