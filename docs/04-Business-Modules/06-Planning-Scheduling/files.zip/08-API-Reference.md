# 08 — API Reference

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-API-008 |
| Version | R0 |
| Base path | `/api/v1` |
| Auth | Bearer DCOS session token (see DCOS-MOD-03-01) |
| Status | For development |

---

## 1. Conventions

| Aspect | Rule |
|---|---|
| Authentication | `Authorization: Bearer <DCOS access token>`. Tenant (`tid`) and project scope (`prj`) resolved from the token, **never** from the request body. |
| Content type | `application/json; charset=utf-8` |
| Identifiers | UUID in paths. Human-readable `activity_id` (e.g. `5000-STR-0120`) is a payload field, not a path key. |
| Dates | ISO 8601 date `YYYY-MM-DD`. Timestamps are RFC 3339 UTC. |
| Durations | Working days on the activity calendar, `numeric(8,2)`. |
| Pagination | `?page=1&page_size=100`, max 500. Response carries `meta.total`, `meta.page`, `meta.page_size`. |
| Sorting | `?sort=activity_id,-early_start` |
| Filtering | `?filter[wbs_node_id]=`, `?filter[is_critical]=true`, `?filter[code.TRADE]=CONCRETE` |
| Idempotency | `Idempotency-Key` header on POST; replay returns the original response. |
| Concurrency | `If-Match: <etag>` on PATCH; mismatch returns `409`. |
| Read-only fields | Early/late dates, float, critical flag, longest path. Writing them returns `422` citing BR-AM-015. |

### 1.1 Standard error envelope

```json
{
  "error": {
    "status": 422,
    "code": "VALIDATION_FAILED",
    "message": "One or more rules were not satisfied",
    "request_id": "req_01HZX...",
    "errors": [
      {
        "rule": "BR-AM-010",
        "field": "remaining_duration",
        "message": "Remaining duration must be zero when the activity is complete"
      }
    ]
  }
}
```

Every validation failure **names the business rule**, so the client can render a meaningful message and the rule remains traceable to DCOS-PLN-AM-001 §18.

### 1.2 Status codes

| Code | Meaning |
|---|---|
| 200 | Success |
| 201 | Created |
| 202 | Accepted — asynchronous work queued (recalculation, export) |
| 204 | Deleted |
| 400 | Malformed request |
| 401 | Missing or invalid token |
| 403 | Authenticated but not permitted |
| 404 | Not found, or outside the caller's tenant/WBS scope |
| 409 | Concurrency conflict, or state conflict (e.g. baseline already approved) |
| 422 | Business rule violation |
| 429 | Rate limited |
| 503 | Dependent engine unavailable (CPM, Calendar) |

**Scope note:** a resource outside the caller's tenant or WBS scope returns `404`, never `403`. Distinguishing them leaks existence.

---

## 2. Calendars

| Method | Endpoint | Permission |
|---|---|---|
| GET | `/projects/:projectId/calendars` | `schedule.view` |
| POST | `/projects/:projectId/calendars` | `schedule.config.calendar` |
| GET | `/calendars/:id` | `schedule.view` |
| PATCH | `/calendars/:id` | `schedule.config.calendar` |
| DELETE | `/calendars/:id` | `schedule.config.calendar` |
| PUT | `/calendars/:id/workweek` | `schedule.config.calendar` |
| GET | `/calendars/:id/exceptions` | `schedule.view` |
| POST | `/calendars/:id/exceptions` | `schedule.config.calendar` |
| DELETE | `/calendars/:id/exceptions/:date` | `schedule.config.calendar` |
| GET | `/calendars/:id/working-days?from=&to=` | `schedule.view` |
| POST | `/calendars/:id/add-days` | `schedule.view` |

```http
POST /api/v1/projects/8f2a.../calendars
{
  "calendar_code": "SITE-6D",
  "calendar_name": "Site 6-day",
  "calendar_type": "project",
  "is_default": true,
  "hours_per_day": 8,
  "workweek": [
    {"day_of_week":1,"is_working":true},  {"day_of_week":2,"is_working":true},
    {"day_of_week":3,"is_working":true},  {"day_of_week":4,"is_working":true},
    {"day_of_week":5,"is_working":true},  {"day_of_week":6,"is_working":true},
    {"day_of_week":7,"is_working":false}
  ]
}
```

`DELETE` returns `409` if the calendar is assigned to any activity or resource (FR-PLN-011).

---

## 3. Activities

| Method | Endpoint | Permission |
|---|---|---|
| GET | `/projects/:projectId/activities` | `schedule.view` |
| POST | `/projects/:projectId/activities` | `schedule.create` |
| GET | `/activities/:id` | `schedule.view` |
| PATCH | `/activities/:id` | `schedule.edit.*` |
| DELETE | `/activities/:id` | `schedule.delete` |
| POST | `/activities/bulk` | `schedule.bulk` |
| POST | `/activities/:id/copy` | `schedule.create` |
| POST | `/projects/:projectId/activities/from-template` | `schedule.template` |
| PUT | `/activities/:id/codes` | `schedule.edit.attributes` |
| PUT | `/activities/:id/constraint` | `schedule.constrain.*` |
| DELETE | `/activities/:id/constraint` | `schedule.constrain.*` |
| PUT | `/activities/:id/boq-links` | `schedule.cost.link` |
| GET | `/activities/:id/history` | `schedule.view` |
| PATCH | `/activities/:id/status` | `schedule.progress` |

### 3.1 Create

```http
POST /api/v1/projects/8f2a.../activities
{
  "wbs_node_id": "b41c...",
  "activity_id": "5000-STR-0120",
  "activity_name": "Level 5 slab - columns, walls and slab",
  "activity_type": "TD",
  "calendar_id": "cal-6day",
  "original_duration": 10,
  "progress_method": "UNIT",
  "total_quantity": 900,
  "unit_of_measure": "m2",
  "responsible_party_id": "sub-main",
  "discipline_code": "STR",
  "codes": { "TRADE": "CONCRETE", "AREA": "TOWER-L1-L5", "PHASE": "CONSTRUCTION" },
  "notes": "Basis: 900 m2 at 8.5 mh/m3 composite"
}
```

**201**

```json
{
  "id": "act_01HZX...",
  "activity_id": "5000-STR-0120",
  "lifecycle_status": "draft",
  "recalculation_id": "run_01HZX...",
  "recalculation_status": "queued"
}
```

### 3.2 Read

```http
GET /api/v1/activities/act_01HZX...
```

```json
{
  "id": "act_01HZX...",
  "activity_id": "5000-STR-0120",
  "activity_name": "Level 5 slab - columns, walls and slab",
  "activity_type": "TD",
  "wbs_node_id": "b41c...",
  "wbs_path": "Tower A / Superstructure / Level 05",
  "calendar": { "id": "cal-6day", "code": "SITE-6D", "hours_per_day": 8 },
  "duration": {
    "original": 10, "remaining": 6, "actual": 4, "at_completion": 10
  },
  "progress": {
    "method": "UNIT",
    "percent_complete": 37.8,
    "total_quantity": 900,
    "installed_quantity": 340,
    "unit_of_measure": "m2",
    "actual_start": "2027-09-01",
    "actual_finish": null
  },
  "constraint": null,
  "lifecycle_status": "in_progress",
  "codes": { "TRADE": "CONCRETE", "AREA": "TOWER-L1-L5" },
  "schedule_results": {
    "calculation_run_id": "run_01HZX...",
    "data_date": "2027-09-25",
    "early_start": "2027-09-01",
    "early_finish": "2027-10-04",
    "late_start": "2027-09-09",
    "late_finish": "2027-10-14",
    "total_float": 6,
    "free_float": 2,
    "is_critical": false,
    "is_longest_path": false,
    "is_out_of_sequence": false,
    "calculated_at": "2027-09-25T09:14:02Z"
  },
  "baseline_variance": {
    "baseline_code": "B1",
    "start_variance": 2, "finish_variance": 4, "duration_variance": 0
  },
  "_etag": "W/\"a71f3\""
}
```

### 3.3 Bulk

```http
POST /api/v1/activities/bulk
{
  "operation": "update",
  "activities": [
    { "id": "act_1", "original_duration": 12 },
    { "id": "act_2", "original_duration": 8, "calendar_id": "cal-office" }
  ]
}
```

Transactional: a failure on any row rolls back the whole batch (BR-AM-033). **422** lists failures by index.

### 3.4 Constraint

```http
PUT /api/v1/activities/act_01HZX.../constraint
{
  "constraint_type": "FNLT",
  "constraint_date": "2027-12-15",
  "justification": "Sectional completion date for the podium retail units per contract clause 14.2"
}
```

- Soft constraint → `200`, applied.
- Hard (`MSO`, `MFO`) → justification of ≥20 characters mandatory (BR-AM-016).
- Restricted (`MANS`, `MANF`) → `202 Accepted`, routed to PM approval, **not applied**.

---

## 4. Logic

| Method | Endpoint | Permission |
|---|---|---|
| GET | `/activities/:id/relationships` | `schedule.view` |
| POST | `/projects/:projectId/relationships` | `schedule.edit.logic` |
| PATCH | `/relationships/:id` | `schedule.edit.logic` |
| DELETE | `/relationships/:id` | `schedule.edit.logic` |
| POST | `/relationships/bulk-link` | `schedule.edit.logic` |
| GET | `/projects/:projectId/open-ended` | `schedule.view` |

```http
POST /api/v1/projects/8f2a.../relationships
{
  "predecessor_id": "act_formwork",
  "successor_id": "act_rebar",
  "relationship_type": "FS",
  "lag": 0
}
```

**422** on cycle detection:

```json
{ "error": { "status": 422, "code": "CIRCULAR_LOGIC",
  "errors": [{ "rule": "BR-AM-006",
    "message": "Cycle detected: 5000-STR-0120 → 5000-STR-0130 → 5000-STR-0140 → 5000-STR-0120" }] } }
```

---

## 5. Calculation

| Method | Endpoint | Permission |
|---|---|---|
| POST | `/projects/:projectId/calculate` | `schedule.view` |
| GET | `/calculation-runs/:id` | `schedule.view` |
| GET | `/projects/:projectId/calculation-runs` | `schedule.view` |
| GET | `/projects/:projectId/critical-path` | `schedule.view` |
| GET | `/projects/:projectId/negative-float` | `schedule.view` |

```http
POST /api/v1/projects/8f2a.../calculate
{ "data_date": "2027-09-25", "scenario_id": null }
```

**202**

```json
{
  "run_id": "run_01HZX...",
  "status": "queued",
  "activity_count": 4312,
  "relationship_count": 9847,
  "poll_url": "/api/v1/calculation-runs/run_01HZX..."
}
```

**Completed run**

```json
{
  "run_id": "run_01HZX...",
  "status": "complete",
  "data_date": "2027-09-25",
  "project_finish_date": "2028-03-09",
  "critical_count": 38,
  "negative_float_count": 0,
  "out_of_sequence_count": 4,
  "open_ended_count": 2,
  "duration_ms": 2140,
  "completed_at": "2027-09-25T09:14:02Z"
}
```

---

## 6. Progress

| Method | Endpoint | Permission |
|---|---|---|
| PATCH | `/activities/:id/progress` | `schedule.progress` |
| POST | `/projects/:projectId/progress-sessions` | `schedule.progress.session` |
| GET | `/progress-sessions/:id` | `schedule.progress.session` |
| PATCH | `/progress-sessions/:id/lines` | `schedule.progress.session` |
| POST | `/progress-sessions/:id/preview` | `schedule.progress.session` |
| POST | `/progress-sessions/:id/commit` | `schedule.progress.session` |
| DELETE | `/progress-sessions/:id` | `schedule.progress.session` |
| GET | `/projects/:projectId/out-of-sequence` | `schedule.view` |
| POST | `/mobile/progress/sync` | `schedule.progress` |

### 6.1 Single activity progress

```http
PATCH /api/v1/activities/act_01HZX.../progress
{
  "data_date": "2027-09-25",
  "actual_start": "2027-09-01",
  "installed_quantity": 340,
  "remaining_duration": 6,
  "comment": "Bays 1 and 2 poured, bay 3 formwork in progress"
}
```

Note the absence of dates, float and critical status — those are engine outputs, not inputs.

**202**

```json
{
  "activity_id": "5000-STR-0120",
  "percent_complete": 37.8,
  "recalculation_id": "run_91be...",
  "recalculation_status": "queued"
}
```

### 6.2 Session preview

```http
POST /api/v1/progress-sessions/ses_01HZX.../preview
```

```json
{
  "session_id": "ses_01HZX...",
  "current_project_finish": "2028-03-09",
  "preview_project_finish": "2028-03-16",
  "impact_days": 5,
  "critical_path_entering": ["7110-MEP-0410", "8040-ARC-0220"],
  "critical_path_leaving": ["6040-ARC-0180"],
  "negative_float_activities": [],
  "out_of_sequence_unresolved": 2
}
```

`commit` returns `409` while any out-of-sequence line lacks a decision.

### 6.3 Mobile sync

```http
POST /api/v1/mobile/progress/sync
{
  "device_id": "dev_01HZX...",
  "records": [
    {
      "local_id": "loc_882",
      "activity_id": "act_01HZX...",
      "installed_quantity": 120,
      "comment": "Bay 3 complete",
      "device_timestamp": "2027-09-24T15:42:11+07:00",
      "photos": ["att_01HZX...", "att_01HZY..."]
    }
  ]
}
```

```json
{
  "accepted": [{ "local_id": "loc_882", "server_id": "prg_01HZX...", "status": "applied" }],
  "conflicts": [],
  "flagged": []
}
```

Records for activities that have left the user's scope are accepted and returned in `flagged` with `REQUIRES_REVIEW`. **Never discarded** — site work is a fact.

---

## 7. Baselines and revisions

| Method | Endpoint | Permission |
|---|---|---|
| GET | `/projects/:projectId/baselines` | `schedule.view.baseline` |
| POST | `/projects/:projectId/baselines` | `schedule.baseline.submit` |
| GET | `/baselines/:id` | `schedule.view.baseline` |
| POST | `/baselines/:id/approve` | `schedule.baseline.approve` |
| POST | `/baselines/:id/reject` | `schedule.baseline.approve` |
| PATCH | `/baselines/:id/set-current` | `schedule.baseline.set_current` |
| GET | `/projects/:projectId/variance?baseline=` | `schedule.view.baseline` |
| GET | `/baselines/compare?from=&to=` | `schedule.view.baseline` |
| GET | `/projects/:projectId/revisions` | `schedule.view.audit` |

```http
POST /api/v1/projects/8f2a.../baselines
{
  "baseline_code": "B0",
  "baseline_name": "Contract baseline",
  "baseline_type": "contract",
  "data_date": "2026-09-01"
}
```

**422** where blocking health findings exist:

```json
{ "error": { "status": 422, "code": "HEALTH_CHECK_BLOCKING",
  "errors": [
    { "rule": "VC-07", "message": "3 activities have negative float" },
    { "rule": "VC-21", "message": "1 activity has no calendar assigned" }
  ] } }
```

---

## 8. Health check

| Method | Endpoint | Permission |
|---|---|---|
| POST | `/projects/:projectId/health-check` | `schedule.health.run` |
| GET | `/health-check-runs/:id` | `schedule.view` |
| GET | `/health-check-runs/:id/export?format=pdf` | `schedule.export` |

```json
{
  "run_id": "hc_01HZX...",
  "overall": "fail",
  "blocking_count": 2,
  "warning_count": 3,
  "findings": [
    { "check_code": "VC-07", "name": "Negative float", "severity": "blocking",
      "result": "fail", "measured_value": 3, "threshold_value": 0,
      "affected_activity_ids": ["act_1","act_2","act_3"] },
    { "check_code": "VC-05", "name": "Hard constraints", "severity": "warning",
      "result": "fail", "measured_value": 7.2, "threshold_value": 5.0 }
  ]
}
```

---

## 9. Look-ahead and Last Planner

| Method | Endpoint | Permission |
|---|---|---|
| GET | `/projects/:projectId/look-ahead?weeks=6&group_by=trade` | `schedule.view` |
| POST | `/projects/:projectId/look-ahead/export` | `schedule.export` |
| GET | `/projects/:projectId/constraint-log` | `schedule.view` |
| POST | `/projects/:projectId/constraint-log` | `schedule.progress` |
| PATCH | `/constraint-log/:id` | `schedule.progress` |
| GET | `/projects/:projectId/weekly-work-plans` | `schedule.view` |
| POST | `/projects/:projectId/weekly-work-plans` | `schedule.progress` |
| PATCH | `/weekly-work-plans/:id/commitments` | `schedule.progress` |
| POST | `/weekly-work-plans/:id/close` | `schedule.progress` |
| GET | `/projects/:projectId/ppc?from=&to=` | `schedule.view` |

```json
{
  "week_start": "2027-09-20",
  "ppc_percent": 78.6,
  "commitments_made": 28,
  "commitments_met": 22,
  "top_variance_reasons": [
    { "code": "MAT", "description": "Material not available", "count": 3 },
    { "code": "PRE", "description": "Predecessor incomplete", "count": 2 }
  ]
}
```

---

## 10. Resource and cost

| Method | Endpoint | Permission |
|---|---|---|
| GET | `/norms` | `schedule.view.resource` |
| POST | `/norms` | `schedule.norms.manage` |
| PUT | `/activities/:id/resources` | `schedule.resource.assign` |
| GET | `/projects/:projectId/resource-demand?by=trade&period=month` | `schedule.view.resource` |
| PUT | `/projects/:projectId/resource-availability` | `schedule.resource.availability` |
| GET | `/projects/:projectId/levelling-check` | `schedule.view.resource` |
| GET | `/projects/:projectId/s-curve?type=labour\|cost` | `schedule.view.cost` |

```json
{
  "period": "month",
  "series": [
    { "period_start": "2027-08-01", "working_days": 26,
      "man_days": 3210, "average_men": 123, "peak_men": 148,
      "by_trade": { "Concrete": 25, "Masonry": 30, "MEP": 35, "Finishes": 24, "Facade": 10 } }
  ]
}
```

---

## 11. Scenarios and delay

| Method | Endpoint | Permission |
|---|---|---|
| GET | `/projects/:projectId/scenarios` | `schedule.view.scenario` |
| POST | `/projects/:projectId/scenarios` | `schedule.scenario.create` |
| GET | `/scenarios/:id` | `schedule.view.scenario` |
| POST | `/scenarios/:id/calculate` | `schedule.scenario.create` |
| POST | `/scenarios/:id/fragnet` | `schedule.tia` |
| GET | `/scenarios/:id/impact` | `schedule.view.scenario` |
| POST | `/scenarios/:id/merge` | `schedule.scenario.merge` |
| GET | `/projects/:projectId/delay-events` | `schedule.view` |
| POST | `/projects/:projectId/delay-events` | `schedule.delay.record` |
| GET | `/delay-events/:id/tia` | `schedule.tia` |

```json
{
  "scenario_id": "scn_01HZX...",
  "purpose": "tia",
  "source_data_date": "2027-07-25",
  "completion_date_source": "2028-03-09",
  "completion_date_scenario": "2028-04-06",
  "net_impact_days": 24,
  "critical_path_changed": true,
  "affected_activities": [
    { "activity_id": "7060-MEP-0210", "delay_days": 24, "was_critical": false, "now_critical": true }
  ]
}
```

---

## 12. Interchange

| Method | Endpoint | Permission |
|---|---|---|
| POST | `/projects/:projectId/import` | `schedule.import` |
| GET | `/import-jobs/:id` | `schedule.import` |
| POST | `/import-jobs/:id/commit` | `schedule.import` |
| GET | `/projects/:projectId/export?format=xlsx\|csv\|xer\|mspdi` | `schedule.export` |
| POST | `/projects/:projectId/print` | `schedule.print` |
| GET | `/projects/:projectId/required-on-site` | `schedule.view` |

Import is two-phase: upload returns a validation report; nothing is written until `commit`.

```json
{
  "import_job_id": "imp_01HZX...",
  "status": "validated",
  "rows_total": 3184,
  "rows_valid": 3179,
  "rows_invalid": 5,
  "unmatched_calendars": ["7-DAY-CURE"],
  "unmatched_wbs_nodes": [],
  "errors": [
    { "row": 412, "field": "activity_id", "rule": "BR-AM-002",
      "message": "Duplicate activity identifier 5000-STR-0120" }
  ]
}
```

---

## 13. Webhooks

```http
POST /api/v1/webhooks
{
  "url": "https://client.example.com/hooks/dcos",
  "events": ["schedule.baseline.approved", "schedule.float.negative"],
  "secret": "whsec_..."
}
```

Delivery carries `X-DCOS-Signature` (HMAC-SHA256 of the raw body). Retry with exponential backoff for 24 hours, then dead-letter with an admin alert. Consumers must deduplicate on `event_id`. Event catalogue in **05-Integration-Specification.md §3**.

---

## 14. Rate limits

| Endpoint class | Limit |
|---|---|
| Read | 600 req/min/tenant |
| Write | 120 req/min/tenant |
| Bulk | 10 req/min/tenant |
| Calculation trigger | 30 req/min/project |
| Import | 5 req/hour/project |
| Export / print | 20 req/hour/tenant |
| Mobile sync | 60 req/min/device |

`429` returns `Retry-After` in seconds.

---

## 15. Versioning

- Path-versioned: `/api/v1`.
- Additive changes (new optional fields, new endpoints) are non-breaking and ship within `v1`.
- Breaking changes require `v2`; `v1` is supported for 12 months from the `v2` GA date.
- Event payloads carry `event_version` independently of the API version.
- Deprecated endpoints return `Deprecation` and `Sunset` headers for at least 6 months before removal.

---

*DCOS — Planning & Scheduling — API Reference — Internal Controlled Document*
