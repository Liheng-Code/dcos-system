# 06 — UI / UX Design

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-UX-006 |
| Version | R0 |
| Related | 02-Functional-Specification.md §13 (PLN-12 Visualisation) |
| Status | For development |

---

## 1. Design principles

| Principle | Application |
|---|---|
| The planner lives here all day | Keyboard-first, dense, no wasted vertical space, no modal interruptions for routine actions |
| Site staff must never see CPM | Two entirely different interfaces on the same data: planner Gantt, field task list |
| Never change logic silently | Any action that would apply a constraint or break the network prompts explicitly |
| Make the mode obvious | Logic edit and progress entry are visually distinct states, not hidden permissions |
| Colour is never the only signal | Critical status carries an outline and icon as well as red fill |
| Show the data date always | Every schedule view states its data date; a programme without one is meaningless |
| Degrade honestly | Stale results are labelled stale, never displayed as current |

---

## 2. Screen inventory

| Ref | Screen | Primary user | Priority |
|---|---|---|---|
| SC-01 | Schedule Workspace (Gantt + table) | Planning Engineer | Must |
| SC-02 | Activity Detail Panel | Planning Engineer | Must |
| SC-03 | Logic Editor | Planning Engineer | Must |
| SC-04 | Progress Update Session | Planning Engineer | Must |
| SC-05 | Look-ahead View | Planning Engineer, Site | Must |
| SC-06 | Weekly Work Plan / PPC | Site Supervisor | Should |
| SC-07 | Constraint (Make-ready) Log | Site Manager | Should |
| SC-08 | Baseline Manager | Planning Engineer | Must |
| SC-09 | Schedule Health Check | Planning Engineer | Must |
| SC-10 | Constraint Register | Project Manager | Must |
| SC-11 | Resource Loading & Histogram | Planning Engineer | Should |
| SC-12 | Levelling Check | Planning Engineer | Should |
| SC-13 | S-Curve & Progress Dashboard | Project Manager | Must |
| SC-14 | Scenario Manager | Planning Engineer | Should |
| SC-15 | Time Impact Analysis | Planning Engineer | Should |
| SC-16 | Delay Event Register | Contract Administrator | Should |
| SC-17 | Calendar Configuration | Planning Engineer | Must |
| SC-18 | Activity Code Configuration | Admin | Must |
| SC-19 | Import / Export | Planning Engineer | Should |
| SC-20 | Programme Print / PDF Setup | Planning Engineer | Must |
| SC-21 | Mobile — My Activities | Site Supervisor | Must |
| SC-22 | Mobile — Progress Capture | Site Supervisor | Must |
| SC-23 | Executive Schedule Dashboard | Project Director | Must |

---

## 3. SC-01 Schedule Workspace

### 3.1 Layout

```
┌──────────────────────────────────────────────────────────────────────────┐
│ Project ▾  │ Baseline: B1 ▾ │ Data date: 25-Sep-27 │ ◉ LOGIC EDIT MODE   │  toolbar
│ [Filter ▾] [Group ▾] [Zoom ▾] [Columns ▾] [Recalc] [Health] [Print]      │
├───────────────────────────────┬──────────────────────────────────────────┤
│ ACTIVITY TABLE                │ TIMELINE                                 │
│ (virtualised, resizable)      │ (canvas, virtualised rows)               │
│                               │                                          │
│ ID │ Name │ Dur │ ES │ TF │ % │  ▓▓▓▓░░  bars, links, float, baseline    │
│                               │         ┊ data date                      │
├───────────────────────────────┴──────────────────────────────────────────┤
│ HISTOGRAM PANE (collapsible) — manpower / cost, shares timescale         │
├──────────────────────────────────────────────────────────────────────────┤
│ 4,312 activities │ 38 critical │ 0 negative float │ Calculated 09:14     │  status bar
└──────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Rendering architecture

| Zone | Technology | Reason |
|---|---|---|
| Activity table | Virtualised HTML table (`@tanstack/virtual`) | Accessible, editable, sortable |
| Timeline | Single `<canvas>`, virtualised rows | DOM/SVG per bar fails above ~3,000 elements |
| Overlays | Absolutely positioned DOM | Tooltips, drag ghost, context menu only |
| Hit testing | Interval tree keyed by row index and pixel range | O(log n) lookup on mouse move |
| Redraw | On scroll, zoom or data change only | Never per animation frame |

**Row height is fixed** — 28 px comfortable, 22 px compact. Virtualisation depends on it; variable-height rows are not permitted.

### 3.3 Bar taxonomy

| Type | Rendering |
|---|---|
| Activity | Solid fill; progress as a darker bar inset 3 px, not stacked |
| Summary / WBS | Thin bracket with downturned end caps; computed, never editable |
| Milestone | Diamond — hollow when incomplete, filled when actualised |
| Critical | Red fill **plus** 1 px darker outline (greyscale and accessibility) |
| Total float | Dashed line from early finish to late finish with an end tick |
| Baseline | Thin grey bar offset below the current bar |
| Level of effort | Hatched fill spanning its dependent activities |
| Hammock | Outline only, no fill |
| Constraint marker | Small triangle glyph at the constrained end |
| In-progress split | Actual portion left of the data date, remaining right of it |

### 3.4 Two mandatory lines

- **Data date** — vertical line, locked to canvas during horizontal scroll, labelled. The single most important element on a construction programme.
- **Progress line** — jagged connector from the data date to each bar's progress point. Expected in P6-style contractual submissions.

### 3.5 Calendar shading

Non-working shading is **per row**, not global. A 7-day curing activity shows no weekend shading while the row above it does. This is correct behaviour and must be visible so it does not read as a rendering error.

### 3.6 Timescale

Seven zoom levels, two- or three-tier headers:

| Level | Upper tier | Lower tier |
|---|---|---|
| 1 | Year | Quarter |
| 2 | Year | Month |
| 3 | Quarter | Month |
| 4 | Month | Week (ISO number) |
| 5 | Month | Week + date |
| 6 | Week | Day |
| 7 | Day | Shift |

Snap to level, not free zoom. `Ctrl + scroll` zooms, `Shift + scroll` pans. Buttons for *Fit to schedule* and *Scroll to data date*. **ISO week numbers are mandatory in the week tier** — construction meetings are conducted in week numbers.

### 3.7 Interaction rules

| Action | Behaviour |
|---|---|
| Drag bar body | **Prompts**: apply Start-on-or-after constraint, or cancel. Never silent. |
| Drag bar edge | Changes original duration. Safe, no prompt. |
| Drag progress handle | Sets percent complete, only if the progress method permits manual entry |
| Drag bar end → another bar | Creates relationship, defaults FS lag 0, opens inline type/lag editor |
| Double-click bar | Opens Activity Detail Panel |
| Right-click bar | Context menu: linked BOQ, documents, RFIs, open NCRs, field tasks |
| Any change | Queues recalculation; visible *recalculating* state; repaint on completion |
| `Ctrl+Z` / `Ctrl+Y` | Undo / redo, minimum 50 operations |

**Non-negotiable:** the undo stack. A planner who loses an hour of logic edits once will never trust the tool again.

### 3.8 Mode switch

A prominent toolbar control shows **LOGIC EDIT** or **PROGRESS ENTRY**. In progress entry mode, logic controls are visibly disabled, bar dragging is inert, and only progress fields are editable. Permission determines which modes are available; the indicator makes the active one unmistakable.

---

## 4. SC-02 Activity Detail Panel

Non-modal, docked right, resizable, does not obstruct the timeline.

| Tab | Content |
|---|---|
| General | ID, name, type, WBS node, discipline, responsible party, notes, basis of estimate |
| Schedule | Duration fields, calendar, constraint, calculated dates, total and free float, critical status |
| Logic | Predecessor and successor list with type and lag; inline add/edit; driving relationship highlighted |
| Progress | Method, percent, quantities, actual dates, full progress history |
| Resources | Assignments, norm code, crew, budgeted and remaining units |
| Commercial | Linked BOQ items, allocated quantity, budget value, earned value |
| Tasks | Linked field tasks with status, gang and installed quantity |
| Quality | Inspection requests, checklists, open NCRs |
| Documents | Drawings, specifications, method statements, RFIs |
| Activity log | Audit timeline with before/after values |

---

## 5. SC-04 Progress Update Session

```
┌──────────────────────────────────────────────────────────────────────────┐
│ Data date: 25-Sep-2027  [LOCKED]        Session opened 09:02 by A.Sok    │
│ Filter: Look-ahead window ▾   38 of 214 activities in scope             │
├──────────────────────────────────────────────────────────────────────────┤
│ ID │ Activity │ Method │ Src │ % │ Rem │ Qty │ Act Start │ Act Fin │ ⚠  │
│ ...│          │ UNIT   │ 🔗  │38 │  6  │ 340 │ 01-Sep    │         │     │
│ ...│          │ PHYS   │ ✎   │60 │  4  │  —  │ 08-Sep    │         │ OOS │
├──────────────────────────────────────────────────────────────────────────┤
│ [Preview impact]                        [Discard]  [Commit session]      │
└──────────────────────────────────────────────────────────────────────────┘
```

- **Source column** shows where each value came from: 🔗 task roll-up, 📱 mobile, ✎ manual. Never hide provenance.
- **Out-of-sequence rows** are flagged and require an explicit decision before commit.
- **Preview** runs CPM without committing and displays: forecast completion before → after, float change, activities entering/leaving the critical path.
- **Commit** is one transaction and one audit event group. A failure on any row rolls back the entire session.

---

## 6. SC-09 Schedule Health Check

Grouped by severity, blocking findings first. Each finding shows the check code, measured value, threshold, and a clickable count that filters the Gantt to the failing activities.

```
BLOCKING (2)
  VC-07  Negative float                     3 activities   [View]
  VC-21  Missing calendar assignment        1 activity     [View]

WARNING (3)
  VC-05  Hard constraints            7.2%   (threshold 5%)  [View]
  VC-08  Duration > 44 days          6.1%   (threshold 5%)  [View]
  VC-26  Out-of-sequence progress    4 activities           [View]

INFORMATION (1)
  VC-29  Calendar differs from WBS default  12 activities   [View]
```

Baseline submission is blocked while any blocking finding is unresolved. The report exports to PDF for client submission.

---

## 7. SC-11 / SC-12 Resource Loading and Levelling

Histogram pane shares the timeline timescale so bars align with the schedule above. Stacked by trade with a total outline; availability shown as a horizontal threshold line; periods exceeding availability shaded red.

Levelling check table: period, average required, peak required, available (input), variance, utilisation %, status. Status thresholds: **OVER CAPACITY** where variance is negative, **AT LIMIT** above 90% utilisation.

Levelling options are presented in order of preference — re-sequence, extend non-critical durations, split by zone, subcontract, add shift, accept later completion.

---

## 8. SC-21 / SC-22 Mobile

Design constraints: one-handed operation, gloved fingers, direct sunlight, 3G or no signal, low-end Android.

| Requirement | Specification |
|---|---|
| Activity list | Filtered to the user's WBS branch and current look-ahead window only. No CPM concepts exposed. |
| Touch targets | Minimum 48 dp |
| Contrast | AA minimum in direct sunlight; high-contrast theme available |
| Progress entry | Quantity or percent, comment, photograph — three taps maximum from list to submitted |
| Offline | Local-first write; every screen shows the sync status indicator and queue depth |
| Photographs | Compressed on cellular, full resolution deferred to unmetered connection |
| Drawings | Latest issued drawing for the activity, cached for offline viewing |
| No approvals | Approval actions are unavailable offline; assurance level cannot be established |

Sync indicator states: **Synced** (green), **Pending — n records** (amber), **Offline — oldest record n hours** (grey), **Conflict — review required** (red).

---

## 9. SC-23 Executive Schedule Dashboard

| Widget | Content |
|---|---|
| Completion forecast | Contract date vs current forecast, with variance in working days |
| Terminal float | Days between last critical activity and contract completion |
| Progress S-curve | Planned, earned and actual |
| Critical path summary | Count, longest chain, activities entering/leaving this period |
| Negative float | Count and worst value, with drill-through |
| Milestone tracker | Key milestones: baseline, forecast, variance, status |
| Schedule health score | Latest DCMA result summary |
| PPC trend | Percent plan complete by week, with top three variance reasons |
| Update currency | Days since last data date; amber above 35, red above 45 |

---

## 10. Visual system

| Element | Specification |
|---|---|
| Type | Inter / system sans; table 12 px, headers 11 px semibold, labels 10 px |
| Density | Comfortable 28 px rows, compact 22 px; user preference persisted |
| Critical | `#E24B4A` fill + `#A32D2D` 1 px outline |
| Normal activity | `#378ADD` fill; progress `#185FA5` |
| Milestone | `#7F77DD` diamond |
| Summary | `#5F5E5A` bracket |
| Baseline | `#888780` thin bar |
| Float | `#888780` dashed |
| Non-working shading | `#888780` at 13% opacity |
| Phase colours (grouping) | Preliminaries `#D9D9D9`, Design `#BDD7EE`, Procurement `#FFE699`, Construction `#C6E0B4`, Handover `#F4B183` |
| Status semantics | Blocking `#C00000`, warning `#BF8700`, pass `#2E7D32` |

Dark mode: invert surfaces, retain hue identity for critical/normal/milestone, raise fill luminance by ~15%.

---

## 11. Keyboard reference

| Key | Action |
|---|---|
| `↑ ↓` | Move row |
| `Tab / Shift+Tab` | Move cell |
| `F2` / `Enter` | Edit cell |
| `Esc` | Cancel edit |
| `Ctrl+Click`, `Shift+Click` | Multi-select |
| `Ins` | Insert activity below |
| `Ctrl+D` | Copy value down over selection |
| `Ctrl+L` | Link selected activities in sequence |
| `Ctrl+Z` / `Ctrl+Y` | Undo / redo |
| `Ctrl+F` | Find activity |
| `Ctrl+G` | Go to activity ID |
| `Alt+←/→` | Zoom timescale out / in |
| `Home` | Scroll to data date |
| `F5` | Recalculate |
| `F9` | Run health check |

---

## 12. Accessibility

- All actions reachable by keyboard; visible focus indicator throughout.
- Critical, negative float and constrained states carry an icon or outline in addition to colour.
- Canvas timeline exposes an accessible parallel table view for screen readers, with activity, dates, float and status.
- Minimum contrast 4.5:1 for text, 3:1 for graphical state indicators.
- Respect `prefers-reduced-motion`; no essential information conveyed by animation.

---

## 13. Print and PDF (SC-20)

| Setting | Options |
|---|---|
| Paper | A0, A1, A2, A3, A4 |
| Orientation | Landscape default |
| Pagination | Timescale-driven with configurable overlap band |
| Repeated elements | Activity table repeated on every sheet |
| Title block | Project, programme title, revision, data date, prepared / checked / approved, date, sheet n of m |
| Legend | Bar types, colour key, critical definition, float threshold |
| Sheet index | Auto-generated for multi-sheet outputs |
| Rendering | Server-side from the same layout engine — never browser print CSS |

A monthly programme submission is a signed, dated A1 or A0 PDF. If DCOS cannot produce one, planners will keep using P6 regardless of what is built.

---

*DCOS — Planning & Scheduling — UI/UX Design — Internal Controlled Document*
