# 02 — Functional Specification

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-FS-002 |
| Version | R0 |
| Parent | 01-Business-Requirement.md |
| Related | DCOS-PLN-AM-001 Activity Management Module Specification |
| Status | For development |

---

## 1. Sub-module decomposition

| Code | Sub-module | Owns |
|---|---|---|
| PLN-01 | Calendar Engine | Working patterns, holidays, working-day arithmetic |
| PLN-02 | Activity Management | The activity object (full spec: DCOS-PLN-AM-001) |
| PLN-03 | Schedule Logic | Relationships, lag, network validation |
| PLN-04 | CPM Calculation Engine | Forward/backward pass, float, critical path, longest path |
| PLN-05 | Constraint Management | Constraint application, governance, register |
| PLN-06 | Baseline Management | Snapshots, variance, revision control |
| PLN-07 | Progress Update | Update sessions, progress history, out-of-sequence handling |
| PLN-08 | Look-ahead & Last Planner | Look-ahead, constraint log, weekly work plan, PPC |
| PLN-09 | Resource & Cost Loading | Assignments, histogram, S-curve |
| PLN-10 | Schedule Scenarios | What-if copies, TIA, recovery planning |
| PLN-11 | Schedule Health | DCMA 14-point and DCOS validation |
| PLN-12 | Visualisation | Gantt, table, dashboards |
| PLN-13 | Interchange | Import/export, P6 XER, MSPDI, CSV |

**Requirement ID convention:** `FR-PLN-nnn`. Priority: Must / Should / Could.

---

## 2. PLN-01 Calendar Engine

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-001 | The system shall support definition of multiple calendars per project, each with a working-day pattern by day of week. | Must |
| FR-PLN-002 | The system shall support working hours per day per calendar, including differing hours per weekday. | Must |
| FR-PLN-003 | The system shall support holiday exception lists per calendar, maintainable per year. | Must |
| FR-PLN-004 | The system shall support calendar exceptions that make a normally non-working day working, and vice versa. | Must |
| FR-PLN-005 | The system shall provide global, project and resource calendar scopes, with project overriding global. | Must |
| FR-PLN-006 | The system shall provide working-day arithmetic services: add N working days to a date, count working days between two dates, and test whether a date is a working day. | Must |
| FR-PLN-007 | The system shall support a continuous (7-day, no-holiday) calendar for curing, shipping and contractual notice periods. | Must |
| FR-PLN-008 | The system shall support a reduced-availability calendar pattern for wet-season working. | Should |
| FR-PLN-009 | The system shall set a default calendar per WBS node, inherited by activities created within it. | Should |
| FR-PLN-010 | The system shall warn where an activity's calendar differs from its WBS node default. | Could |
| FR-PLN-011 | The system shall prevent deletion of a calendar assigned to any activity or resource. | Must |
| FR-PLN-012 | The system shall display, for any activity, the calendar assigned and the resulting calendar-day span alongside the working-day duration. | Must |

---

## 3. PLN-02 Activity Management

Fully specified in **DCOS-PLN-AM-001**, which defines FR-AM-001 to FR-AM-048 and business rules BR-AM-001 to BR-AM-036. Summarised capability set:

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-020 | The system shall support activity types: task dependent, resource dependent, level of effort, hammock, start milestone, finish milestone. | Must |
| FR-PLN-021 | The system shall store original, remaining, actual and at-completion duration per activity. | Must |
| FR-PLN-022 | The system shall support progress measurement methods: physical %, duration %, units complete, weighted steps, 0/100, 50/50, LOE, milestone. | Must |
| FR-PLN-023 | The system shall support user-defined activity code types and values, configurable without code change. | Must |
| FR-PLN-024 | The system shall support activity templates for repeating sets such as a typical floor cycle. | Must |
| FR-PLN-025 | The system shall support transactional bulk edit across a selected activity set. | Must |
| FR-PLN-026 | The system shall link activities to BOQ items with quantity allocation, rejecting over-allocation. | Should |
| FR-PLN-027 | The system shall link activities to Construction module field tasks and roll task progress up to the activity. | Must |

---

## 4. PLN-03 Schedule Logic

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-040 | The system shall support relationship types finish-to-start, start-to-start, finish-to-finish and start-to-finish. | Must |
| FR-PLN-041 | The system shall support positive and negative lag on any relationship, expressed in working days. | Must |
| FR-PLN-042 | The system shall specify which calendar governs lag: predecessor, successor or project calendar, as a project setting. | Must |
| FR-PLN-043 | The system shall detect and reject circular logic, naming the activities forming the cycle. | Must |
| FR-PLN-044 | The system shall prevent duplicate relationships between the same predecessor–successor pair of the same type. | Must |
| FR-PLN-045 | The system shall identify open-ended activities (no predecessor or no successor) and report them. | Must |
| FR-PLN-046 | The system shall identify the driving relationship for each activity's early start. | Should |
| FR-PLN-047 | The system shall support creating a relationship by dragging between bars on the Gantt, defaulting to FS with zero lag. | Must |
| FR-PLN-048 | The system shall support bulk linking of a selected set of activities in sequence with a chosen type and lag. | Should |
| FR-PLN-049 | The system shall permit relationships across WBS branches and across disciplines without restriction. | Must |
| FR-PLN-050 | The system shall prevent logic on hammock activities. | Must |

---

## 5. PLN-04 CPM Calculation Engine

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-060 | The system shall perform a forward pass computing early start and early finish for every activity from the data date. | Must |
| FR-PLN-061 | The system shall perform a backward pass computing late start and late finish from the project finish or an imposed finish constraint. | Must |
| FR-PLN-062 | The system shall calculate total float as late start minus early start, in working days on the activity calendar. | Must |
| FR-PLN-063 | The system shall calculate free float as the delay possible before the earliest successor's early start is affected. | Must |
| FR-PLN-064 | The system shall flag activities as critical where total float is at or below the project critical float threshold. | Must |
| FR-PLN-065 | The system shall calculate and flag the longest path, for use where multiple calendars distort float-based criticality. | Must |
| FR-PLN-066 | The system shall perform all date arithmetic on the activity's assigned calendar, correctly handling activities on differing calendars within one network. | Must |
| FR-PLN-067 | The system shall support retained logic and progress override as a project-level setting for out-of-sequence progress. | Must |
| FR-PLN-068 | The system shall never schedule remaining work before the data date. | Must |
| FR-PLN-069 | The system shall derive level-of-effort activity dates from the span of their predecessors and successors, and exclude them from critical path reporting. | Must |
| FR-PLN-070 | The system shall derive hammock dates from the earliest start and latest finish of the activities spanned. | Should |
| FR-PLN-071 | The system shall write calculated results to a results store separate from the activity record, never overwriting planner-owned data. | Must |
| FR-PLN-072 | The system shall record each calculation run with an identifier, data date, trigger, duration and result summary. | Must |
| FR-PLN-073 | The system shall queue recalculation on any change to duration, logic, calendar, constraint or actual dates, and display a recalculating state until results return. | Must |
| FR-PLN-074 | The system shall support calculation of a schedule scenario in isolation without affecting live schedule results. | Must |
| FR-PLN-075 | The system shall report negative float and identify the constraint or actual date producing it. | Must |
| FR-PLN-076 | The system shall complete a full recalculation of 5,000 activities and 12,000 relationships in under 3 seconds server-side. | Must |

### 5.1 Calculation semantics

```
Forward pass, per activity in topological order:
  ES = max over predecessors of:
       FS : EF(pred) + 1 + lag
       SS : ES(pred) + lag
       FF : EF(pred) + lag - duration + 1
       SF : ES(pred) + lag - duration + 1
  ES = max(ES, data_date, start_constraint)
  EF = ES + duration - 1                         (working days, activity calendar)

Backward pass, reverse topological order:
  LF = min over successors of:
       FS : LS(succ) - 1 - lag
       SS : LS(succ) - lag + duration - 1
       FF : LF(succ) - lag
       SF : LF(succ) - lag + duration - 1
  LF = min(LF, project_finish, finish_constraint)
  LS = LF - duration + 1

Float:
  total_float = LS - ES
  free_float  = min(ES(succ)) - EF - 1     over all successors
  critical    = total_float <= critical_threshold
```

---

## 6. PLN-05 Constraint Management

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-090 | The system shall support constraint types SNET, SNLT, FNET, FNLT, MSO, MFO, MANS, MANF, ALAP and expected finish. | Must |
| FR-PLN-091 | The system shall classify constraints as soft, hard or restricted and apply the corresponding governance. | Must |
| FR-PLN-092 | The system shall require a justification of at least 20 characters for any hard constraint. | Must |
| FR-PLN-093 | The system shall route mandatory start and mandatory finish constraints to Project Manager approval before application. | Must |
| FR-PLN-094 | The system shall provide a constraint register listing every constrained activity with type, date, justification, applying user and current float effect. | Must |
| FR-PLN-095 | The system shall prompt for confirmation when a Gantt bar drag would apply a constraint, and never apply one silently. | Must |
| FR-PLN-096 | The system shall create a schedule revision record when a constraint is applied, changed or removed after baseline approval. | Must |
| FR-PLN-097 | The system shall report constraint density as a percentage of incomplete activities in the health check. | Must |

---

## 7. PLN-06 Baseline Management

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-110 | The system shall capture an immutable baseline snapshot of all activities, relationships, calendars, constraints and loading at approval. | Must |
| FR-PLN-111 | The system shall support multiple retained baselines per project, each identified, dated and typed (contract, revised, recovery, as-built). | Must |
| FR-PLN-112 | The system shall designate one baseline as the current comparison baseline, changeable by the Project Manager. | Must |
| FR-PLN-113 | The system shall preserve activity identifier stability across baselines so that comparison is possible. | Must |
| FR-PLN-114 | The system shall calculate start, finish, duration and float variance for every activity against any selected baseline. | Must |
| FR-PLN-115 | The system shall provide a baseline comparison report identifying added, deleted, re-sequenced and re-timed activities between two baselines. | Should |
| FR-PLN-116 | The system shall prevent baseline approval where any blocking health check finding is unresolved. | Must |
| FR-PLN-117 | The system shall lock activity identifiers and progress measurement methods on baseline approval. | Must |
| FR-PLN-118 | The system shall route baseline approval through the shared Approval Workflow Engine. | Must |
| FR-PLN-119 | The system shall never permit deletion or modification of an approved baseline snapshot. | Must |
| FR-PLN-120 | The system shall maintain a schedule revision register recording every post-baseline change with reason, approver and date. | Must |

---

## 8. PLN-07 Progress Update

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-140 | The system shall support a progress update session bound to a single data date, locked for the session duration. | Must |
| FR-PLN-141 | The system shall pre-populate activity progress from linked field task roll-up, showing the source of each value. | Must |
| FR-PLN-142 | The system shall record actual start, actual finish, percent complete, installed quantity and remaining duration against the data date. | Must |
| FR-PLN-143 | The system shall retain immutable progress history per activity showing every reported value, reporting user, channel and timestamp. | Must |
| FR-PLN-144 | The system shall flag out-of-sequence progress and require a planner decision before commit. | Must |
| FR-PLN-145 | The system shall provide a preview showing the recalculated completion date and float change before the session is committed. | Must |
| FR-PLN-146 | The system shall treat the update session as one transaction and one audit event group; a failure rolls back the whole session. | Must |
| FR-PLN-147 | The system shall support activity suspension and resumption with mandatory reason capture. | Should |
| FR-PLN-148 | The system shall roll activity progress up to the parent WBS node using the project-configured weighting basis. | Must |
| FR-PLN-149 | The system shall prevent percent complete from decreasing without a documented reason and a high-severity audit entry. | Must |
| FR-PLN-150 | The system shall support mobile progress capture with offline storage and later synchronisation. | Must |
| FR-PLN-151 | The system shall reject an actual start later than the data date and an actual finish earlier than the actual start. | Must |

---

## 9. PLN-08 Look-ahead & Last Planner

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-170 | The system shall generate a look-ahead schedule for a configurable forward window from the data date. | Must |
| FR-PLN-171 | The system shall permit the look-ahead to be filtered and grouped by area, trade package or responsible party. | Must |
| FR-PLN-172 | The system shall export the look-ahead to PDF and Excel for site distribution. | Must |
| FR-PLN-173 | The system shall provide a constraint (make-ready) log recording obstacles to activities entering the look-ahead window. | Should |
| FR-PLN-174 | The system shall classify constraints by type: design, material, labour, plant, permit, access, predecessor, information. | Should |
| FR-PLN-175 | The system shall support a weekly work plan of commitments derived from look-ahead activities. | Should |
| FR-PLN-176 | The system shall calculate Percent Plan Complete as commitments met divided by commitments made, per week and per responsible party. | Should |
| FR-PLN-177 | The system shall record a reason-for-variance code against every unmet commitment. | Should |
| FR-PLN-178 | The system shall report PPC trend and top reasons for variance over time. | Should |
| FR-PLN-179 | The system shall never permit the look-ahead to be maintained as a separate schedule with independent logic. | Must |

---

## 10. PLN-09 Resource & Cost Loading

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-190 | The system shall support assignment of labour, plant and material resources to activities with budgeted units and units per time. | Should |
| FR-PLN-191 | The system shall maintain a productivity norm library of man-hours per unit by work type, editable per tenant. | Should |
| FR-PLN-192 | The system shall calculate required crew size as adjusted man-hours divided by duration multiplied by hours per day. | Should |
| FR-PLN-193 | The system shall support site factor and efficiency factor adjustments to base man-hours. | Should |
| FR-PLN-194 | The system shall calculate the duration a rounded crew actually delivers, and flag activities that are under-resourced. | Should |
| FR-PLN-195 | The system shall produce a manpower histogram of average and peak manpower per period, in total and by trade. | Should |
| FR-PLN-196 | The system shall compare required manpower against a per-period availability input and flag over-capacity periods. | Should |
| FR-PLN-197 | The system shall produce a labour S-curve of cumulative planned versus actual man-hours. | Should |
| FR-PLN-198 | The system shall derive activity budget value from linked BOQ item quantity and rate. | Should |
| FR-PLN-199 | The system shall produce a cost-loaded S-curve for cash flow forecasting. | Should |
| FR-PLN-200 | The system shall support automatic resource levelling against availability with configurable priority rules. | Could |

---

## 11. PLN-10 Schedule Scenarios

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-210 | The system shall create a schedule scenario as an isolated copy of the live schedule at a stated data date. | Must |
| FR-PLN-211 | The system shall permit full editing within a scenario without any effect on the live schedule. | Must |
| FR-PLN-212 | The system shall run CPM calculation on a scenario independently. | Must |
| FR-PLN-213 | The system shall quantify the completion date impact of a scenario against its source schedule. | Must |
| FR-PLN-214 | The system shall support insertion of a delay fragnet into a scenario for time impact analysis. | Should |
| FR-PLN-215 | The system shall produce a time impact analysis output identifying the delay event, fragnet, affected activities and net completion impact. | Should |
| FR-PLN-216 | The system shall support merging an approved scenario into the live schedule, creating a schedule revision record. | Must |
| FR-PLN-217 | The system shall support recovery and acceleration scenarios with comparison of options. | Should |
| FR-PLN-218 | The system shall maintain a delay event register linking events to affected activities and supporting evidence. | Should |
| FR-PLN-219 | The system shall retain scenarios permanently as claim evidence, never purging them automatically. | Must |

---

## 12. PLN-11 Schedule Health

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-230 | The system shall run the DCMA 14-point schedule assessment on demand and return pass/fail per check with the failing activities listed. | Must |
| FR-PLN-231 | The system shall run additional DCOS checks: missing WBS node, missing calendar, missing progress method, missing responsible party, cost-loaded activity on duration percent, BOQ over-allocation, in-progress with zero remaining duration. | Must |
| FR-PLN-232 | The system shall classify findings as blocking, warning or information. | Must |
| FR-PLN-233 | The system shall prevent baseline submission while any blocking finding is unresolved. | Must |
| FR-PLN-234 | The system shall run the health check automatically before baseline submission and store the result as a record. | Must |
| FR-PLN-235 | The system shall permit configuration of check thresholds per tenant, retaining DCMA defaults. | Should |
| FR-PLN-236 | The system shall export the health check report to PDF for client submission. | Should |

### 12.1 Check thresholds

| Ref | Check | Threshold |
|---|---|---|
| VC-01 | Missing logic (no predecessor or successor) | ≤5% |
| VC-02 | Leads (negative lag) | 0 |
| VC-03 | Lags (positive lag) | ≤5% |
| VC-04 | Finish-to-start relationships | ≥90% |
| VC-05 | Hard constraints | ≤5% |
| VC-06 | High float (>44 working days) | ≤5% |
| VC-07 | Negative float | 0 |
| VC-08 | High duration (>44 working days) | ≤5% |
| VC-09 | Invalid dates | 0 |
| VC-10 | Resources assigned (where loading in use) | 0 missing |
| VC-11 | Missed activities vs baseline | ≤5% |
| VC-12 | Critical path test | Pass |
| VC-13 | Critical path length index | 0.95–1.05 |
| VC-14 | Baseline execution index | ≥0.95 |

---

## 13. PLN-12 Visualisation

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-250 | The system shall render a Gantt chart with a resizable split between activity table and timeline. | Must |
| FR-PLN-251 | The system shall render activity bars, summary bars, milestones, critical activities, total float, baseline bars, LOE and constraint markers as distinct visual types. | Must |
| FR-PLN-252 | The system shall render a data date line locked to the canvas during horizontal scroll. | Must |
| FR-PLN-253 | The system shall render a progress line connecting the data date to each bar's progress point. | Should |
| FR-PLN-254 | The system shall shade non-working periods per row according to that activity's calendar. | Must |
| FR-PLN-255 | The system shall provide at least seven timescale zoom levels with multi-tier headers including ISO week numbers. | Must |
| FR-PLN-256 | The system shall render 5,000 activities in under 2 seconds and maintain 60 fps on scroll and zoom. | Must |
| FR-PLN-257 | The system shall convey critical status by outline or icon in addition to colour. | Must |
| FR-PLN-258 | The system shall support grouping by WBS, any activity code, phase, responsible party or calendar with summary roll-up rows. | Must |
| FR-PLN-259 | The system shall support saved filters shared at project level. | Must |
| FR-PLN-260 | The system shall provide configurable bar labels left, right and inside. | Should |
| FR-PLN-261 | The system shall provide a curtain overlay marking a look-ahead window or claim period. | Could |
| FR-PLN-262 | The system shall provide a resource and cost histogram pane sharing the timeline timescale, with S-curve overlay. | Should |
| FR-PLN-263 | The system shall provide an undo/redo stack of at least 50 operations per editing session. | Must |
| FR-PLN-264 | The system shall provide a visible mode indicator distinguishing logic edit mode from progress entry mode. | Must |
| FR-PLN-265 | The system shall produce a paginated PDF programme at A0–A3 with title block, legend, sheet index and configurable overlap band, rendered server-side. | Must |

---

## 14. PLN-13 Interchange

| Ref | Requirement | Priority |
|---|---|---|
| FR-PLN-280 | The system shall import activities from CSV and Excel with a validation report produced before commit. | Must |
| FR-PLN-281 | The system shall import and export Primavera P6 XER preserving activity ID, name, duration, calendar, constraint, codes, logic and progress. | Should |
| FR-PLN-282 | The system shall import and export Microsoft Project MSPDI. | Should |
| FR-PLN-283 | The system shall produce a mapping report on import identifying unmatched calendars, codes and WBS nodes. | Should |
| FR-PLN-284 | The system shall reject an import that would create circular logic or duplicate activity identifiers. | Must |
| FR-PLN-285 | The system shall export the current schedule to Excel with all displayed columns and applied filters. | Must |
| FR-PLN-286 | The system shall expose activity early start and late finish to the Procurement module for required-on-site date derivation. | Should |
| FR-PLN-287 | The system shall publish schedule events to the Integration Layer for consumption by other modules. | Must |

---

## 15. Non-functional requirements

| Ref | Category | Requirement | Target |
|---|---|---|---|
| NFR-PLN-01 | Performance | Activity table initial render | 5,000 activities < 2 s |
| NFR-PLN-02 | Performance | Gantt scroll and zoom | 60 fps sustained |
| NFR-PLN-03 | Performance | Single edit to repainted CPM result | < 1.5 s |
| NFR-PLN-04 | Performance | Full CPM recalculation | 5,000 activities / 12,000 relationships < 3 s |
| NFR-PLN-05 | Performance | Bulk update of 500 activities | < 5 s, transactional |
| NFR-PLN-06 | Performance | Look-ahead generation | < 10 s |
| NFR-PLN-07 | Performance | A1 PDF programme export | < 20 s, async with notification |
| NFR-PLN-08 | Scalability | Activities per project | 50,000 without architectural change |
| NFR-PLN-09 | Scalability | Concurrent planners per project | 20, with optimistic concurrency and conflict detection |
| NFR-PLN-10 | Security | Tenant isolation | PostgreSQL RLS on tenant_id, verified by automated cross-tenant tests in CI |
| NFR-PLN-11 | Security | Authorisation scope | Tenant and project validated from token, never request body |
| NFR-PLN-12 | Auditability | Change evidence | Before/after values, user, role snapshot, timestamp, source channel on every schedule-affecting change |
| NFR-PLN-13 | Retention | Schedule and progress history | Project duration + DLP + 5 years |
| NFR-PLN-14 | Retention | Baselines and scenarios | Permanent within project archive |
| NFR-PLN-15 | Usability | Keyboard operation | Full grid navigation, inline edit, multi-select without mouse |
| NFR-PLN-16 | Offline | Mobile progress capture | Local-first write; server timestamp wins for approvals, device timestamp for field data |
| NFR-PLN-17 | Interoperability | P6 XER round trip | No loss of ID, duration, calendar, constraint, code or logic data |
| NFR-PLN-18 | Localisation | Language and date format | English and Khmer at first release; date format and first day of week per tenant |
| NFR-PLN-19 | Accessibility | Colour independence | Critical status conveyed by outline or icon as well as colour |
| NFR-PLN-20 | Availability | Module availability | 99.5%, aligned to platform SLA |

---

## 16. Traceability summary

| Business capability | Functional requirements |
|---|---|
| BC-01 Multi-calendar | FR-PLN-001 to 012 |
| BC-02 Activity definition | FR-PLN-020 to 027, DCOS-PLN-AM-001 |
| BC-03 Logic network | FR-PLN-040 to 050 |
| BC-04 / BC-05 CPM and float | FR-PLN-060 to 076 |
| BC-06 Constraints | FR-PLN-090 to 097 |
| BC-07 Baseline | FR-PLN-110 to 120 |
| BC-08 / BC-09 Progress | FR-PLN-140 to 151 |
| BC-10 / BC-11 Look-ahead, Last Planner | FR-PLN-170 to 179 |
| BC-12 Health validation | FR-PLN-230 to 236 |
| BC-13 / BC-14 Resource and cost | FR-PLN-190 to 200 |
| BC-15 / BC-16 Scenarios, TIA | FR-PLN-210 to 219 |
| BC-17 Gantt | FR-PLN-250 to 265 |
| BC-18 Revision control | FR-PLN-120, FR-PLN-265 |
| BC-19 P6 interchange | FR-PLN-280 to 287 |
| BC-20 Mobile offline | FR-PLN-150, NFR-PLN-16 |

---

*DCOS — Planning & Scheduling — Functional Specification — Internal Controlled Document*
