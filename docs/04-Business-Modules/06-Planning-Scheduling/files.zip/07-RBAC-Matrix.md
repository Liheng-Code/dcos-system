# 07 — RBAC Matrix

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-RBAC-007 |
| Version | R0 |
| Related | DCOS-MOD-03-02 RBAC Engine; DCOS-MOD-03-01 Authentication |
| Status | For development |

---

## 1. The governing principle

> **Editing logic and editing progress are different permissions on the same screen.**

This is the single most important access control decision in the module. A site engineer must be able to report progress without being able to change the contractual logic. A discipline manager must be able to adjust durations in their own scope without touching another discipline's. The interface must make the active mode unmistakable (see 06-UI-UX-Design §3.8).

A schedule where anyone with write access can change logic is a schedule that cannot be defended in a dispute, because nobody can prove who changed what or whether they were entitled to.

---

## 2. Effective permission model

```
Effective permission =
      Role permission
  ∩   Project assignment
  ∩   Discipline scope
  ∩   WBS branch scope
  ∩   Lifecycle state gate
```

Every condition must pass. A Discipline Manager holding `schedule.edit.duration` with a structural discipline scope **cannot** edit MEP activity durations, even though the role grants the permission. A Planner holding `schedule.edit.logic` cannot change logic on a baselined activity without a schedule revision, because the lifecycle gate blocks it.

Tenant and project scope are resolved from the session token (`tid`, `prj` claims), never from the request body.

---

## 3. Permission catalogue

### 3.1 View

| Permission | Grants |
|---|---|
| `schedule.view` | Read activities, dates, float, critical status within scope |
| `schedule.view.all_projects` | Read across all projects in the tenant |
| `schedule.view.baseline` | Read baseline snapshots and variance |
| `schedule.view.cost` | See budget value, earned value and cost loading |
| `schedule.view.resource` | See resource assignments and histogram |
| `schedule.view.audit` | Read the schedule audit trail and revision register |
| `schedule.view.scenario` | Read schedule scenarios and TIA outputs |

### 3.2 Structure and logic

| Permission | Grants |
|---|---|
| `schedule.create` | Create activities |
| `schedule.edit.attributes` | Edit name, codes, responsible party, notes |
| `schedule.edit.duration` | Edit original and remaining duration |
| `schedule.edit.logic` | Create, edit and delete relationships |
| `schedule.edit.calendar` | Assign a calendar to an activity |
| `schedule.delete` | Soft-delete activities |
| `schedule.bulk` | Perform transactional bulk operations |
| `schedule.template` | Create and apply activity templates |

### 3.3 Constraints

| Permission | Grants |
|---|---|
| `schedule.constrain.soft` | Apply SNET, SNLT, FNET, FNLT, ALAP, EXP |
| `schedule.constrain.hard` | Apply MSO, MFO — requires justification |
| `schedule.constrain.mandatory` | **Request** MANS, MANF — always routed to approval |
| `schedule.constrain.approve` | Approve restricted constraint requests |

### 3.4 Progress

| Permission | Grants |
|---|---|
| `schedule.progress` | Record progress on activities within scope |
| `schedule.progress.session` | Open, preview and commit a progress update session |
| `schedule.progress.reverse` | Decrease percent complete (requires reason) |
| `schedule.progress.reopen` | Reopen a completed activity (requires approval) |
| `schedule.status.close` | Transition an activity to Closed |

### 3.5 Baseline and revision

| Permission | Grants |
|---|---|
| `schedule.baseline.submit` | Submit a baseline for approval |
| `schedule.baseline.approve` | Approve a baseline |
| `schedule.baseline.set_current` | Change the current comparison baseline |
| `schedule.revision.create` | Create a post-baseline schedule revision |
| `schedule.revision.approve` | Approve a schedule revision |

### 3.6 Analysis

| Permission | Grants |
|---|---|
| `schedule.scenario.create` | Create schedule scenarios |
| `schedule.scenario.merge` | Merge an approved scenario into the live schedule |
| `schedule.delay.record` | Record delay events |
| `schedule.tia` | Produce time impact analysis output |
| `schedule.health.run` | Run the schedule health check |

### 3.7 Resource and cost

| Permission | Grants |
|---|---|
| `schedule.resource.assign` | Assign resources and norms to activities |
| `schedule.resource.availability` | Set period availability for levelling |
| `schedule.cost.link` | Link activities to BOQ items and allocate quantity |
| `schedule.norms.manage` | Maintain the productivity norms library |

### 3.8 Output and interchange

| Permission | Grants |
|---|---|
| `schedule.export` | Export to Excel, PDF, CSV |
| `schedule.export.p6` | Export to P6 XER / MSPDI |
| `schedule.import` | Import activities from any format |
| `schedule.issue` | Issue a programme revision through the transmittal gate |
| `schedule.print` | Generate paginated programme PDFs |

### 3.9 Configuration

| Permission | Grants |
|---|---|
| `schedule.config.calendar` | Create and edit calendars and holiday lists |
| `schedule.config.codes` | Define activity code types and values |
| `schedule.config.settings` | Set project scheduling settings (float threshold, retained logic, roll-up weighting) |

---

## 4. Role matrix — core operations

| Role | View | Create | Edit logic | Edit duration | Progress | Constrain | Baseline | Delete |
|---|---|---|---|---|---|---|---|---|
| Super Admin | All | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Company Admin | All company | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Project Director | All project | — | — | — | — | — | Approve | — |
| Project Manager | Assigned project | ✓ | ✓ | ✓ | ✓ | Approve | Approve | ✓ |
| Head of Planning | All project | ✓ | ✓ | ✓ | ✓ | ✓ | Submit | ✓ |
| Planning Engineer | Assigned project | ✓ | ✓ | ✓ | ✓ | Soft + hard | Submit | ✓ |
| Construction Manager | Assigned project | — | — | Own scope | ✓ | — | — | — |
| Discipline Manager | Own discipline | ✓ | Own scope | Own scope | ✓ | — | — | — |
| Site Supervisor | Assigned WBS | — | — | — | ✓ | — | — | — |
| Engineer | Assigned WBS | — | — | — | ✓ | — | — | — |
| QA/QC Inspector | Assigned WBS | — | — | — | Close only | — | — | — |
| QS / Cost Engineer | All project | — | — | — | — | — | — | — |
| Procurement Officer | All project | — | — | — | — | — | — | — |
| Contract Administrator | All project | — | — | — | — | — | — | — |
| HSE Officer | Assigned WBS | — | — | — | — | — | — | — |
| Subcontractor User | Own scope | — | — | — | Own scope | — | — | — |
| Client / Consultant | Issued revisions | — | — | — | — | — | — | — |
| Viewer | Assigned project | — | — | — | — | — | — | — |

---

## 5. Role matrix — analysis and output

| Role | Health check | Scenario | Merge scenario | Delay / TIA | Resource | Cost link | Export | Import | Issue |
|---|---|---|---|---|---|---|---|---|---|
| Super Admin | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Company Admin | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Project Director | View | View | — | View | View | View | ✓ | — | Approve |
| Project Manager | ✓ | ✓ | Approve | ✓ | ✓ | — | ✓ | — | ✓ |
| Head of Planning | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ | ✓ |
| Planning Engineer | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ | ✓ |
| Construction Manager | View | ✓ | — | — | ✓ | — | ✓ | — | — |
| Discipline Manager | View | — | — | — | Own scope | — | ✓ | — | — |
| QS / Cost Engineer | View | View | — | View | View | ✓ | ✓ | — | — |
| Contract Administrator | View | ✓ | — | ✓ | — | — | ✓ | — | — |
| Procurement Officer | — | — | — | — | — | — | ✓ | — | — |
| Site Supervisor | — | — | — | — | — | — | Look-ahead only | — | — |
| Subcontractor User | — | — | — | — | — | — | Own scope only | — | — |
| Client / Consultant | View issued | — | — | — | — | — | ✓ | — | — |
| Viewer | — | — | — | — | — | — | ✓ | — | — |

---

## 6. Scope rules

### 6.1 Discipline scope

Applies to Discipline Managers and Engineers. `discipline_scope` is an array on `user_project_access`.

```
Discipline Manager (STR) editing activity 7020-MEP-0340
  → role grants schedule.edit.duration
  → project assignment passes
  → discipline scope ['STR'] does not include 'MEP'
  → DENIED
```

A user with `discipline_scope = ['ALL']` passes for any discipline.

### 6.2 WBS branch scope

Applies to Site Supervisors, Engineers and Subcontractor Users. `wbs_scope` on `user_project_access` restricts visibility and write access to a WBS subtree.

```
Drywall subcontractor, wbs_scope = [Tower/L3 … Tower/L7, Zone B]
  → sees only activities under those nodes
  → may record progress only on those activities
  → cannot see, filter or export anything outside the branch
```

This is the construction-specific control that makes external party access safe. Without it, a subcontractor with schedule access sees the whole programme.

### 6.3 Responsible-party scope

Subcontractor Users may record progress only on activities where `responsible_party_id` matches their stakeholder record, **in addition** to the WBS branch test.

### 6.4 Client and consultant scope

Client and Consultant roles see **issued revisions only**, never the live working schedule. Access is granted through the Document Control transmittal gate, not through direct schedule permission. This prevents a client seeing a draft position the contractor has not yet committed to.

---

## 7. Lifecycle state gates

Permission alone is insufficient; the activity's lifecycle state gates the operation.

| Operation | Draft | Planned | Baselined | In Progress | Complete | Closed | Cancelled |
|---|---|---|---|---|---|---|---|
| Edit attributes | ✓ | ✓ | ✓ | ✓ | Reason | — | — |
| Edit duration | ✓ | ✓ | Revision | Revision | — | — | — |
| Edit logic | ✓ | ✓ | Revision | Revision | — | — | — |
| Change calendar | ✓ | ✓ | Revision | Revision | — | — | — |
| Change activity ID | ✓ | ✓ | **Never** | **Never** | **Never** | **Never** | **Never** |
| Change progress method | ✓ | ✓ | Revision | Revision | — | — | — |
| Apply constraint | ✓ | ✓ | Revision | Revision | — | — | — |
| Record progress | — | — | ✓ | ✓ | — | — | — |
| Delete | ✓ | ✓ | — | — | — | — | — |
| Cancel | ✓ | ✓ | Approval | Approval | Approval | — | — |
| Reopen | — | — | — | — | Approval | Approval | — |

*Revision* = permitted but automatically creates a schedule revision record (BR-AM-018).
*Approval* = routed through the Approval Workflow Engine.

---

## 8. Approval-gated actions

| Action | Requested by | Approved by | Rationale |
|---|---|---|---|
| Mandatory start / finish constraint | Planner | Project Manager | Breaks network integrity |
| Baseline submission | Planner | PM endorse → Project Director approve | Contractual reference point |
| Schedule revision (post-baseline) | Planner | Project Manager | Change control |
| Scenario merge into live schedule | Planner | Project Manager | Alters the working programme |
| Activity cancellation with progress | Planner | Project Manager | Scope removal with sunk cost |
| Activity reopen after completion | Planner | Project Manager | Reverses a recorded fact |
| Progress reversal (percent decrease) | Any progress holder | Recorded reason + High audit | Usually indicates an earlier error |
| Change of roll-up weighting basis | Planner | Head of Planning | Restates all historical progress |
| Change of critical float threshold | Planner | Project Manager | Alters what "critical" means contractually |

---

## 9. Segregation of duties

| Rule | Reason |
|---|---|
| The user who submits a baseline may not approve it | Independent verification of the contractual reference |
| The user who requests a mandatory constraint may not approve it | Prevents unilateral network breaking |
| The user who creates a scenario may merge it only with PM approval | Prevents unreviewed change entering the live schedule |
| Progress entry and logic editing may be held independently | Site reports facts; planners own the network |
| Audit trail is append-only for every role including Super Admin | Legal defensibility |
| No role may write to `activity_schedule_results` | Calculated data is engine-owned (BR-AM-015) |

---

## 10. Audit requirements by permission

| Permission exercised | Audit severity | Captured |
|---|---|---|
| `schedule.create` | Low | Activity, WBS node, creator |
| `schedule.edit.duration` | Medium | Before/after duration, reason if post-baseline |
| `schedule.edit.logic` | Medium | Relationship, type, lag, before/after |
| `schedule.progress` | Medium | All values, data date, source channel, device timestamp |
| `schedule.progress.reverse` | **High** | Before/after percent, mandatory reason |
| `schedule.constrain.hard` | **High** | Type, date, justification text |
| `schedule.constrain.mandatory` | **Critical** | Requester, approver, justification |
| `schedule.baseline.approve` | **Critical** | Baseline ID, health check result, approver |
| `schedule.revision.create` | **High** | Change type, before/after, trigger reference |
| `schedule.scenario.merge` | **High** | Scenario ID, conflicts resolved, approver |
| `schedule.delete` | **High** | Activity snapshot retained in audit |
| `schedule.import` | **High** | File name, row count, validation summary |
| `schedule.issue` | **High** | Revision, recipients, transmittal reference |
| `schedule.config.settings` | **Critical** | Setting, before/after value |

---

## 11. Permission test matrix

| Ref | Scenario | Expected |
|---|---|---|
| RB-01 | Site Supervisor attempts to edit a predecessor relationship | Denied; progress entry remains available |
| RB-02 | Discipline Manager (STR) edits an MEP activity duration | Denied on discipline scope |
| RB-03 | Subcontractor views an activity outside their WBS branch | Not found (not "forbidden") |
| RB-04 | Planner applies a mandatory finish constraint | Routed to PM approval; not applied immediately |
| RB-05 | Planner approves their own baseline submission | Denied on segregation of duties |
| RB-06 | Engineer changes an activity ID after baseline | Denied on lifecycle gate |
| RB-07 | Any role writes `total_float` via the API | Rejected as read-only |
| RB-08 | Tenant A user requests a tenant B activity | Not found; security audit event raised |
| RB-09 | Client requests the live working schedule | Denied; only issued revisions accessible |
| RB-10 | QS links an activity to a BOQ item | Permitted via `schedule.cost.link` |
| RB-11 | Site Supervisor exports the full programme | Denied; look-ahead export only |
| RB-12 | Project Director edits an activity duration | Denied; view and approve only |
| RB-13 | Contract Administrator creates a TIA scenario | Permitted |
| RB-14 | Planner reduces percent complete without a reason | Rejected; reason mandatory |
| RB-15 | Discipline Manager with scope `ALL` edits any discipline | Permitted |

---

*DCOS — Planning & Scheduling — RBAC Matrix — Internal Controlled Document*
