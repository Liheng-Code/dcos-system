# 12 — Training Guide

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-TRN-012 |
| Version | R0 |
| Owner | Head of Planning |
| Related | 11-SOP.md; DCOS-SOP-PLN-001; DCOS-GDL-PLN-002 |
| Status | For issue |

---

## 1. Training philosophy

Most software training fails because it teaches the interface. This curriculum teaches the **discipline**, using the interface as the vehicle. A planner who understands why float is calculated the way it is will use any tool correctly; a planner who has memorised which button to press will produce a plausible, wrong programme in any tool.

Three principles govern the design:

**Teach the consequence, not the click.** Every module explains what goes wrong when the step is skipped. "Drag the bar and it applies a constraint" is a fact. "Drag the bar, it silently applies a constraint, and six months later nobody can explain why this activity will not move" is a lesson.

**Role-appropriate depth.** A site supervisor never needs to hear the word float. Exposing CPM concepts to field users is the fastest way to lose them.

**Assess by production, not by quiz.** Competence is demonstrated by building a programme that passes the health check, not by answering questions about the health check.

---

## 2. Curriculum map

| Track | Audience | Duration | Delivery |
|---|---|---|---|
| **T1 Foundations** | All users | 1 hour | Online, self-paced |
| **T2 Planner Core** | Planning Engineers | 3 days | Instructor-led workshop |
| **T3 Planner Advanced** | Planning Engineers, Head of Planning | 2 days | Instructor-led, after 3 months of use |
| **T4 Field Progress** | Site Supervisors, Engineers | 30 minutes | On-site, hands-on |
| **T5 Manager Review** | PM, Project Director, Construction Manager | 2 hours | Instructor-led |
| **T6 Discipline Manager** | Discipline Managers | 1 hour | Instructor-led |
| **T7 Commercial** | QS, Contract Administrator | 3 hours | Instructor-led |
| **T8 Administrator** | Company Admin, IT | 2 hours | Instructor-led |

| Role | Required tracks |
|---|---|
| Planning Engineer | T1, T2, T3 |
| Head of Planning | T1, T2, T3, T8 |
| Project Manager | T1, T5 |
| Project Director | T1, T5 (§ dashboard only) |
| Construction Manager | T1, T5, T6 |
| Discipline Manager | T1, T6 |
| Site Supervisor / Engineer | T1 (§1 only), T4 |
| Quantity Surveyor | T1, T7 |
| Contract Administrator | T1, T7 |
| Subcontractor User | T4 |
| Company Admin / IT | T1, T8 |

---

## 3. T1 — Foundations (1 hour, all users)

| # | Topic | Content |
|---|---|---|
| 1.1 | Why one system | How the WBS spine connects schedule, cost, documents and site; what breaks when departments work in isolation |
| 1.2 | The three objects | WBS node = *where*. Activity = *what and when*. Field task = *who, this week*. Why they are separate |
| 1.3 | Reading a programme | Bars, milestones, the data date, the critical path, what float means in one sentence |
| 1.4 | The data date | Why every programme states it; why a programme without one is meaningless |
| 1.5 | Who does what | The roles in SOP §12 and where your work enters the schedule |
| 1.6 | Navigating DCOS | Finding your project, your activities, your notifications |

**Assessment:** locate your own assigned activities and state the project's current forecast completion date.

---

## 4. T2 — Planner Core (3 days)

### Day 1 — Foundations and setup

| # | Topic | Practical |
|---|---|---|
| 2.1 | The four questions a programme answers | — |
| 2.2 | Readiness: what you must have before you start (SOP-PLN-001 §6) | Complete an Information Register for a case study project |
| 2.3 | The seven setup decisions (GDL-PLN-002) | Complete a Setup Decision Record |
| 2.4 | **Calendars** — the most underestimated component | Build 4 calendars; verify a 10-day activity finishes differently on each |
| 2.5 | Why multi-calendar float cannot be retrofitted | Demonstration: same duration, two calendars, two finish dates |
| 2.6 | WBS structure and the four alignment tests | Review a WBS against the valuation test |
| 2.7 | Activity IDs: encode only what will never change | Design an ID convention; critique three bad ones |
| 2.8 | Activity codes and the report test | Configure 8 codes; generate 3 different views from one schedule |

### Day 2 — Building and calculating

| # | Topic | Practical |
|---|---|---|
| 2.9 | Creating activities; types and when to use each | Build 60 activities in a case study project |
| 2.10 | Durations from quantity and norm, not from opinion | Derive 10 durations from BOQ quantities |
| 2.11 | Progress measurement methods — the field that makes EVM possible | Assign methods across activity classes; justify each |
| 2.12 | Logic: FS, SS, FF, SF and lag | Build the logic network with a construction sequence brief |
| 2.13 | **The forward and backward pass** — worked by hand on paper first | Hand-calculate a 6-activity network; then verify in DCOS |
| 2.14 | Total float, free float, longest path | Interpret float on a diamond network |
| 2.15 | Constraints and why they corrupt schedules | Apply one soft and one hard constraint; observe the float effect |
| 2.16 | Reading the critical path against the intended method | Walk the critical path; identify one logic error deliberately seeded |

**Hand-calculation before software is deliberate.** A planner who has never computed a backward pass by hand cannot tell when the software is producing nonsense.

### Day 3 — Baseline, update and output

| # | Topic | Practical |
|---|---|---|
| 2.17 | Schedule health check and the DCMA 14 | Run health check; clear 6 seeded blocking findings |
| 2.18 | Baseline submission and approval | Submit a baseline through the workflow |
| 2.19 | What baselining locks and why | Attempt an ID change post-baseline; observe the block |
| 2.20 | The monthly update cycle (SOP-PLN-D) | Run a full progress session on a seeded month |
| 2.21 | Out-of-sequence progress: retained logic vs override | Resolve 4 flagged activities; compare both settings |
| 2.22 | Preview before commit | Preview an update; interpret the completion impact |
| 2.23 | Look-ahead generation and issue | Generate and export a 6-week look-ahead |
| 2.24 | Reports: variance, critical path, S-curve | Produce the monthly report pack |
| 2.25 | Programme issue and the transmittal gate | Produce an A1 PDF submission |

**Day 3 assessment (competence gate):** starting from a brief, build a 150-activity programme, pass the health check with zero blocking findings, baseline it, run one progress update, and issue an A1 PDF. Pass mark: completed unaided within the day.

---

## 5. T3 — Planner Advanced (2 days, after 3 months of use)

| # | Topic | Practical |
|---|---|---|
| 3.1 | Resource loading: quantity → norm → man-hours → crew | Load a 40-activity project |
| 3.2 | Site factor and efficiency — why 0.85, never 1.0 | Sensitivity exercise on the same project |
| 3.3 | Manpower histogram, average vs peak | Produce and interpret; identify the demobilisation trough |
| 3.4 | Levelling in order of preference | Level an over-capacity month without extending completion |
| 3.5 | Why you never level by reducing the norm | Case study of a failed productivity claim |
| 3.6 | Cost loading and the S-curve | Link BOQ items; produce a cost S-curve |
| 3.7 | **Schedule scenarios** — the what-if discipline | Create a scenario; edit; confirm the live schedule is untouched |
| 3.8 | Time impact analysis and fragnets | Model a delay event; produce a TIA output |
| 3.9 | Concurrent delay | Model two fragnets; distinguish employer and contractor risk |
| 3.10 | Recovery and acceleration options | Model three recovery options; compare cost and time |
| 3.11 | Post-baseline change control (SOP-PLN-F) | Merge an approved scenario; verify revision records |
| 3.12 | Baseline comparison and forensic reading | Compare two baselines; identify what changed and why |
| 3.13 | P6 interchange | Export XER; open in P6; reimport and reconcile |
| 3.14 | Rolling wave in practice | Detail a near-term window from a summarised branch |

**Assessment:** given a delay event and a progressed schedule, produce a TIA output that the Contract Administrator accepts as submission-ready.

---

## 6. T4 — Field Progress (30 minutes, on site)

Delivered on the user's own phone, at the site office, in the language of the site.

| # | Topic | Practical |
|---|---|---|
| 4.1 | What the app shows you: your activities only | Open the list |
| 4.2 | Reporting quantity installed | Report progress on a real activity |
| 4.3 | Taking and attaching photographs | Attach two photos |
| 4.4 | Working with no signal | Turn on flight mode; report progress; observe the queue |
| 4.5 | The sync indicator and what each state means | Reconnect; watch the queue clear |
| 4.6 | Why your report matters | One slide: your number becomes the payment application |
| 4.7 | Weekly commitments and what "met" means | Record one commitment |

**Never mentioned in T4:** float, critical path, CPM, logic, baseline. Field users do not need them and exposing them causes abandonment.

**Assessment:** report progress on three activities including one offline, in under three minutes total.

---

## 7. T5 — Manager Review (2 hours)

| # | Topic |
|---|---|
| 5.1 | Reading the executive dashboard: forecast, terminal float, S-curve, health score |
| 5.2 | What "critical" actually means, and why near-critical matters as much |
| 5.3 | Negative float: what it means, and what you must do within 48 hours |
| 5.4 | Interpreting the manpower histogram — spotting a profile nobody can staff |
| 5.5 | Reviewing a critical path against the construction method (Construction Manager focus) |
| 5.6 | What you are approving when you approve a baseline |
| 5.7 | What you are approving when you approve a constraint or a revision |
| 5.8 | Data date currency — why 45 days old means you have no control document |
| 5.9 | PPC as the leading indicator of reliability |
| 5.10 | Questions to ask your planner |

### The ten questions a manager should ask

1. What is the data date, and how old is it?
2. What is the forecast completion, and how much terminal float remains?
3. What is on the critical path, and does it match how we intend to build?
4. What is near-critical — within 10 days float?
5. Has anything entered or left the critical path this month?
6. Are there any negative float activities, and what is causing them?
7. Did the health check pass, and what failed?
8. Does the manpower histogram show a profile we can actually staff?
9. Does the programme percentage agree with the QS valuation?
10. What is our PPC, and what is the top reason for variance?

---

## 8. T6 — Discipline Manager (1 hour)

| # | Topic | Practical |
|---|---|---|
| 6.1 | Filtering the schedule to your discipline | Apply and save a discipline filter |
| 6.2 | Reviewing your durations before baseline | Review and comment on 15 durations |
| 6.3 | Confirming remaining duration at each update — and why it is not "percent left" | Complete a remaining-duration review |
| 6.4 | Your deliverables and response deadlines | Locate your open RFI and submittal activities |
| 6.5 | Reading float on your own scope | Identify your three least-flexible activities |
| 6.6 | What you may and may not edit | Attempt an out-of-scope edit; observe the denial |

---

## 9. T7 — Commercial (3 hours)

| # | Topic | Practical |
|---|---|---|
| 7.1 | Why the programme and the valuation must reconcile | — |
| 7.2 | Progress measurement methods and which the QS can accept | Review method assignment across a project |
| 7.3 | Linking activities to BOQ items and allocating quantity | Link 20 activities |
| 7.4 | Measuring progress for the IPC from schedule data | Produce a period measurement |
| 7.5 | Reconciling programme percentage with measured percentage | Investigate a seeded 6-point divergence |
| 7.6 | Cost loading and the cash flow S-curve | Produce a cost S-curve |
| 7.7 | Delay events: recording, notice periods and time bars | Record an event and check the notice deadline |
| 7.8 | Reading a TIA output and what makes it defensible | Critique two TIA outputs, one weak |
| 7.9 | Contemporaneous records: what the schedule gives you in a dispute | Produce a delay evidence pack |
| 7.10 | Variation orders and the revision register | Trace a variation through to the revised baseline |

---

## 10. T8 — Administrator (2 hours)

| # | Topic |
|---|---|
| 8.1 | Tenant scheduling settings and their consequences |
| 8.2 | Calendar administration and the annual holiday update (SOP-PLN-J) |
| 8.3 | Activity code type configuration |
| 8.4 | Health check threshold configuration |
| 8.5 | Productivity norms library maintenance |
| 8.6 | Permission assignment: discipline scope and WBS scope |
| 8.7 | Feature flag management per tenant |
| 8.8 | Monitoring: CPM queue depth, stale data dates, failed runs |
| 8.9 | Common support scenarios and the first question to ask |

### First-response triage

| Symptom | First question |
|---|---|
| "The float is wrong" | Do the oracle networks still pass? If yes, it is project data, not the engine |
| "My activities disappeared" | Check the user's discipline scope and WBS scope before assuming data loss |
| "The dates moved and nobody changed anything" | Was a calendar holiday added? Did another user commit an update? |
| "Recalculation is stuck" | Check queue depth and whether one oversized project is monopolising workers |
| "Mobile won't sync" | Check queue depth and record age; do not clear the queue |

---

## 11. Common misconceptions to correct explicitly

| Misconception | Correction |
|---|---|
| "Float belongs to us" | Float ownership is a contractual question, defined in the contract, not a system setting |
| "Percent complete is how much time has passed" | It is how much work is done, measured by the assigned method |
| "Remaining duration is duration minus elapsed" | It is how long the work will actually take from here, which is a judgement |
| "Dragging a bar moves the activity" | It applies a constraint, which suppresses CPM for that activity |
| "The critical path is the longest chain of work" | It is the chain with the least float, which on multi-calendar schedules is not the same thing |
| "More detail means a better schedule" | An unmaintainable schedule controls nothing. Detail to what you can update |
| "The look-ahead is a separate programme" | It is generated from the master. Two schedules always diverge |
| "We can add cost loading later" | The columns must exist from day one or every baseline must be rebuilt |
| "The client's comment must be accepted" | Comments are assessed for contractual effect before incorporation |
| "A 10-day activity always takes 14 calendar days" | It depends entirely on the assigned calendar |

---

## 12. Competency assessment

| Level | Requirement | Evidence |
|---|---|---|
| **Aware** | T1 complete | Completion record |
| **Capable — Field** | T4 complete | Three progress reports submitted correctly, one offline |
| **Capable — Planner** | T2 complete | Day 3 gate passed: 150-activity programme built, health check clear, baselined, updated, issued |
| **Proficient — Planner** | 3 months' use + T3 | Two full monthly cycles issued within 5 working days; one TIA accepted by Contract Administration |
| **Expert — Planner** | 12 months' use | Can train others; can defend a programme in a client review; can identify an engine defect from a wrong result |

Reassessment on any major version release affecting the CPM engine, calendar engine or progress measurement.

---

## 13. Delivery materials

| Material | Format | Owner |
|---|---|---|
| T1 e-learning | Online, 6 short videos | Head of Planning |
| T2/T3 workbooks | PDF with exercises and seeded case study | Head of Planning |
| Case study project | Seeded DCOS project, 10-storey building, 142 activities, 4 calendars | Operations |
| Oracle exercise sheets | Hand-calculation networks with answer key | Head of Planning |
| T4 field card | Laminated A5, one side, pictures not prose, local language | Head of Planning |
| Manager one-pager | The ten questions, single side | Head of Planning |
| Quick reference | Keyboard shortcuts, status lists, health check codes | Head of Planning |
| SOP pack | 11-SOP.md, SOP-PLN-001, GDL-PLN-002 | Head of Planning |

---

## 14. Training schedule for rollout

Aligned to the rollout stages in 10-Deployment-Notes §6.

| Stage | Training delivered | Timing |
|---|---|---|
| 0 — Internal | T2, T8 for the planning team | 2 weeks before pilot |
| 1 — Pilot | T2 for pilot planner; T5 for pilot PM; T4 for pilot site team | Week 1 of pilot |
| 2 — Early adopters | T2, T4, T5, T6, T7 for three project teams | 1 week before each project onboards |
| 3 — General | T1 for all users; role tracks as projects onboard | Rolling |
| Post-3 months | T3 for planners who have completed two update cycles | Quarterly cohort |

**Constraint:** no project goes live without its planner having passed the T2 Day 3 competence gate and its site team having completed T4. A project team that has not been trained will produce a programme nobody trusts, and recovering trust costs more than the training.

---

*DCOS — Planning & Scheduling — Training Guide — Internal Controlled Document*
