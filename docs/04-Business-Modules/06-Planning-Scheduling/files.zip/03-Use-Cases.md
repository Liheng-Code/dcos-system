# 03 — Use Cases

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-UC-003 |
| Version | R0 |
| Parent | 02-Functional-Specification.md |
| Status | For development |

---

## 1. Actors

| Actor | Type | Description |
|---|---|---|
| Planning Engineer | Primary | Builds, updates and reports the schedule. Heaviest user of the module. |
| Project Manager | Primary | Reviews, endorses, approves constraints and revisions. |
| Project Director | Primary | Approves baselines. Portfolio-level visibility. |
| Head of Planning | Primary | Governance, quality assurance, standards. |
| Construction Manager | Primary | Confirms methodology and sequence; reviews resource profile. |
| Discipline Manager | Primary | Confirms durations and remaining durations for own scope. |
| Site Supervisor | Primary | Captures field progress, usually on mobile. |
| Quantity Surveyor | Primary | Measurement basis, cost loading, IPC reconciliation. |
| Procurement Manager | Secondary | Consumes required-on-site dates. |
| Contract Administrator | Secondary | Delay events, time impact analysis, notices. |
| Subcontractor User | Secondary | Views own scope, reports own progress. |
| Client / Consultant | Secondary | Receives issued programme revisions. |
| CPM Engine | System | Calculates dates, float and critical path. |
| Notification Engine | System | Dispatches alerts. |
| Audit Trail Engine | System | Records all changes. |
| Construction Module | System | Supplies field task progress. |
| BOQ Engine | System | Supplies quantities and rates. |

---

## 2. Use case catalogue

| ID | Use case | Primary actor | Priority |
|---|---|---|---|
| UC-PLN-01 | Configure project calendars | Planning Engineer | Must |
| UC-PLN-02 | Create an activity | Planning Engineer | Must |
| UC-PLN-03 | Build the logic network | Planning Engineer | Must |
| UC-PLN-04 | Run CPM calculation | CPM Engine | Must |
| UC-PLN-05 | Apply a constraint | Planning Engineer | Must |
| UC-PLN-06 | Run schedule health check | Planning Engineer | Must |
| UC-PLN-07 | Submit and approve a baseline | Planning Engineer | Must |
| UC-PLN-08 | Perform a monthly progress update | Planning Engineer | Must |
| UC-PLN-09 | Capture progress from site on mobile | Site Supervisor | Must |
| UC-PLN-10 | Resolve out-of-sequence progress | Planning Engineer | Must |
| UC-PLN-11 | Generate and issue a look-ahead | Planning Engineer | Must |
| UC-PLN-12 | Record a weekly work plan and calculate PPC | Site Supervisor | Should |
| UC-PLN-13 | Load resources and produce a manpower histogram | Planning Engineer | Should |
| UC-PLN-14 | Level a resource over-capacity period | Planning Engineer | Should |
| UC-PLN-15 | Perform a time impact analysis | Planning Engineer | Should |
| UC-PLN-16 | Prepare a recovery schedule | Planning Engineer | Should |
| UC-PLN-17 | Change the schedule after baseline | Planning Engineer | Must |
| UC-PLN-18 | Compare two baselines | Planning Engineer | Should |
| UC-PLN-19 | Issue a programme revision to the client | Planning Engineer | Must |
| UC-PLN-20 | Import a programme from Primavera P6 | Planning Engineer | Should |
| UC-PLN-21 | View own scope as a discipline manager | Discipline Manager | Must |
| UC-PLN-22 | Derive required-on-site dates | Procurement Manager | Should |
| UC-PLN-23 | Reconcile programme progress with the IPC | Quantity Surveyor | Must |
| UC-PLN-24 | Respond to a negative float alert | Project Manager | Must |

---

## 3. Detailed use cases

### UC-PLN-02 — Create an activity

| Field | Detail |
|---|---|
| **Primary actor** | Planning Engineer |
| **Goal** | Add a schedule activity that is complete enough to be calculated and measured |
| **Preconditions** | Project exists; WBS built; at least one calendar defined; user holds `schedule.edit` |
| **Trigger** | Planner identifies a discrete element of work to be scheduled |
| **Requirements** | FR-PLN-020 to 027 |

**Main flow**

1. Planner selects the WBS node under which the work belongs.
2. Planner creates an activity inline in the grid or via the detail panel.
3. System generates the activity ID from the project mask; planner may override.
4. Planner enters the activity name describing the work and its location.
5. Planner selects activity type (default: task dependent).
6. System assigns the WBS node's default calendar; planner may change it.
7. Planner enters original duration and records the basis of estimate.
8. Planner assigns discipline, responsible party and mandatory activity codes.
9. Planner selects the progress measurement method.
10. Where BOQ items are linked, system defaults the method to units complete and requires total quantity.
11. System validates against BR-AM-001 to BR-AM-004 and saves.
12. System raises an audit event and queues a CPM recalculation.

**Alternate flows**

- **2a. Create from template.** Planner selects an activity template (e.g. typical floor cycle); system inserts the set with ID and description substitution, then returns to step 8.
- **2b. Copy existing.** Planner copies an activity, selecting whether to carry logic, resources and codes.
- **10a. Non-default method selected.** System requires a recorded reason before saving (BR-AM-024).

**Exception flows**

- **E1.** Duplicate activity ID within project → rejected, BR-AM-002 cited.
- **E2.** Zero duration on a non-milestone type → rejected, BR-AM-003.
- **E3.** Non-zero duration on a milestone type → rejected, BR-AM-003.
- **E4.** No WBS node selected → rejected, BR-AM-001.

**Postconditions** — Activity exists in status Draft; CPM recalculation queued; audit event recorded.

---

### UC-PLN-04 — Run CPM calculation

| Field | Detail |
|---|---|
| **Primary actor** | CPM Engine (system) |
| **Goal** | Produce current dates, float and critical path for the whole network |
| **Preconditions** | At least one activity; all activities have a calendar; data date set |
| **Trigger** | Change to duration, logic, calendar, constraint or actual dates; or manual request; or progress session commit |
| **Requirements** | FR-PLN-060 to 076 |

**Main flow**

1. System receives a recalculation request with project ID and trigger reference.
2. System creates a calculation run record and marks the project as recalculating.
3. System loads activities, relationships, calendars and constraints.
4. System performs cycle detection across the relationship graph.
5. System topologically orders the network.
6. System performs the forward pass, applying data date, start constraints and each activity's own calendar.
7. System derives level-of-effort and hammock dates from their spans.
8. System performs the backward pass, applying finish constraints and the project finish.
9. System calculates total float, free float, critical flag and longest path.
10. System flags out-of-sequence, open-ended and negative-float activities.
11. System writes results to `activity_schedule_results` against the run ID.
12. System refreshes WBS progress and cost roll-up.
13. System clears the recalculating state and notifies subscribed clients.
14. System dispatches notifications for negative float and critical path change.

**Alternate flows**

- **6a. Retained logic setting.** Out-of-sequence successors are scheduled after the incomplete predecessor's remaining work.
- **6b. Progress override setting.** Out-of-sequence successors are permitted to proceed from the data date.
- **11a. Scenario calculation.** Results are written to the scenario's own results store; live results untouched.

**Exception flows**

- **E1.** Circular logic detected → run aborted, cycle path named, previous results retained (BR-AM-006).
- **E2.** Activity without a calendar → run aborted, activity identified.
- **E3.** Calculation exceeds timeout → run marked failed, previous results retained, planner alerted.

**Postconditions** — Results stored against the run; critical path identified; notifications dispatched.

---

### UC-PLN-07 — Submit and approve a baseline

| Field | Detail |
|---|---|
| **Primary actor** | Planning Engineer |
| **Goal** | Freeze an approved reference programme against which all delay will be measured |
| **Preconditions** | Schedule complete; health check available; Basis of Schedule signed |
| **Requirements** | FR-PLN-110 to 120 |

**Main flow**

1. Planner runs the schedule health check (UC-PLN-06).
2. Planner resolves all blocking findings.
3. Planner submits the baseline with a name, type and effective data date.
4. System re-runs the health check and stores the result with the submission.
5. System routes the submission to the Project Manager via the Approval Workflow Engine.
6. Project Manager reviews critical path, methodology alignment and resource profile, and endorses.
7. Project Director approves.
8. System captures an immutable snapshot of activities, relationships, calendars, constraints and loading.
9. System locks activity identifiers and progress measurement methods.
10. System sets the baseline as the current comparison baseline.
11. System raises audit events and notifies the project team.

**Alternate flows**

- **6a. Rejected at review.** Baseline returns to the planner with comments; a new submission is required.
- **10a. Not set as current.** A recovery or as-built baseline may be retained without becoming the comparison baseline.

**Exception flows**

- **E1.** Blocking health finding present at step 4 → submission rejected, findings listed (FR-PLN-233).
- **E2.** Approval workflow times out → escalation per the Notification Engine matrix.

**Postconditions** — Immutable baseline exists; IDs and methods locked; subsequent changes require a schedule revision.

---

### UC-PLN-08 — Perform a monthly progress update

| Field | Detail |
|---|---|
| **Primary actor** | Planning Engineer |
| **Goal** | Bring the schedule to the current data date and produce the forecast |
| **Preconditions** | Baseline approved; data date agreed; field tasks closed for the period |
| **Requirements** | FR-PLN-140 to 151 |

**Main flow**

1. Planner confirms the data date with the Project Manager and opens an update session.
2. System locks the data date for the session.
3. System pre-populates activity progress from linked field task roll-up, showing the source of each value.
4. Planner reviews and adjusts, confirming remaining durations with discipline managers.
5. System flags out-of-sequence progress; planner resolves each (UC-PLN-10).
6. Planner requests a preview.
7. System runs CPM on the session data without committing and returns the forecast completion date and float change.
8. Planner reviews the impact with the Project Manager.
9. Planner commits the session.
10. System writes progress, appends progress history, runs the CPM and refreshes roll-ups — as one transaction.
11. System dispatches negative float and critical path change notifications.
12. Planner produces the variance, critical path, S-curve and look-ahead reports.
13. Planner issues the programme revision through the transmittal gate (UC-PLN-19).

**Alternate flows**

- **4a. Discipline manager disputes a value.** Planner records the agreed value and the dispute in the session comment.
- **9a. Planner discards the session.** No data is written; the session is recorded as abandoned in the audit trail.

**Exception flows**

- **E1.** Actual start later than data date → rejected, BR-AM-007.
- **E2.** Percent complete 100 without actual finish → rejected, BR-AM-011.
- **E3.** Validation failure on any row at commit → whole session rolled back, failing rows identified (BR-AM-033).

**Postconditions** — Schedule current to the data date; progress history appended; forecast recalculated.

---

### UC-PLN-09 — Capture progress from site on mobile

| Field | Detail |
|---|---|
| **Primary actor** | Site Supervisor |
| **Goal** | Report work done at the workface without returning to the site office |
| **Preconditions** | User holds `schedule.progress`; activities assigned within user's WBS scope; app installed |
| **Requirements** | FR-PLN-150, NFR-PLN-16 |

**Main flow**

1. Supervisor opens the app; system displays activities within the user's WBS branch and the current look-ahead window.
2. Supervisor selects an activity.
3. Supervisor enters installed quantity or percent complete, plus a comment.
4. Supervisor attaches photographs.
5. System writes the record to local device storage with the device timestamp.
6. System displays the sync status indicator as pending.
7. On connection, system uploads the queued records.
8. Server validates and applies the records against the current data date.
9. System confirms synchronisation and updates the indicator.

**Alternate flows**

- **4a. Cellular connection.** Photographs compressed for upload; full resolution deferred to unmetered connection.
- **7a. Extended offline period.** Records remain queued; the indicator shows the queue depth and the age of the oldest record.

**Exception flows**

- **E1.** Conflict with a server-side value → field data resolved by device timestamp; the conflict is logged and surfaced to the planner.
- **E2.** Activity no longer in the user's scope at sync time → record accepted but flagged `REQUIRES_REVIEW` for the Project Manager, never discarded.

**Postconditions** — Progress recorded with provenance; available for the next update session.

---

### UC-PLN-10 — Resolve out-of-sequence progress

| Field | Detail |
|---|---|
| **Primary actor** | Planning Engineer |
| **Goal** | Decide how the network should treat work progressed ahead of its predecessors |
| **Preconditions** | Update session open; at least one activity flagged out of sequence |
| **Requirements** | FR-PLN-067, FR-PLN-144 |

**Main flow**

1. System lists activities with progress recorded while a predecessor is incomplete.
2. For each, system shows the incomplete predecessor and the relationship type.
3. Planner selects a resolution: accept under the project setting, correct the logic, or correct the progress.
4. Where logic is corrected, planner amends the relationship and records the reason.
5. System records the decision against the activity and the session.
6. System applies the project retained-logic or progress-override setting to the remaining accepted cases.

**Exception flows**

- **E1.** Out-of-sequence arises from an erroneous actual date → planner corrects the date; the correction is audited.

**Postconditions** — Every flagged activity carries a recorded decision; the network calculates deterministically.

---

### UC-PLN-15 — Perform a time impact analysis

| Field | Detail |
|---|---|
| **Primary actor** | Planning Engineer |
| **Secondary actor** | Contract Administrator |
| **Goal** | Quantify the completion impact of a delay event for an extension of time claim |
| **Preconditions** | Delay event recorded; a progressed schedule exists at or immediately before the event date |
| **Requirements** | FR-PLN-210 to 219 |

**Main flow**

1. Contract Administrator records the delay event with date, cause, category and evidence.
2. Planner creates a schedule scenario from the last update immediately preceding the event.
3. Planner constructs a fragnet representing the delay: activities, durations and logic.
4. Planner inserts the fragnet into the scenario at the correct network position.
5. System runs CPM on the scenario.
6. System reports the scenario completion date against the source schedule completion date.
7. System produces the TIA output: event, fragnet, affected activities, critical path before and after, net impact in working days.
8. Contract Administrator attaches the output to the claim and issues the contractual notice.
9. Scenario is retained permanently as claim evidence.

**Alternate flows**

- **3a. Concurrent delay.** A second fragnet representing a contractor-culpable event is inserted; the analysis distinguishes the two.
- **6a. No impact.** The fragnet is absorbed by float; the scenario records float consumption rather than delay.

**Exception flows**

- **E1.** No progressed schedule at the event date → analysis proceeds from the nearest available update, and the limitation is stated in the output.

**Postconditions** — TIA output produced; scenario retained; live schedule untouched.

---

### UC-PLN-17 — Change the schedule after baseline

| Field | Detail |
|---|---|
| **Primary actor** | Planning Engineer |
| **Goal** | Apply an approved change to the live programme under control |
| **Preconditions** | Baseline approved; a change trigger exists |
| **Requirements** | FR-PLN-096, FR-PLN-120, BR-AM-018 |

**Main flow**

1. Change trigger recorded: variation, employer's instruction, delay event, acceleration or design change.
2. Planner creates a schedule scenario from the live schedule.
3. Planner applies the change within the scenario only.
4. System runs CPM on the scenario and quantifies the completion impact.
5. Planner produces the impact assessment.
6. Project Manager reviews; Project Director approves.
7. Planner merges the approved scenario into the live schedule.
8. System creates schedule revision records for every changed activity with reason and approval reference.
9. Where the contract requires it, a new baseline is taken (UC-PLN-07).
10. Revised programme issued with the supporting notice.

**Exception flows**

- **E1.** Merge conflict where the live schedule has progressed since the scenario was created → conflicts listed for planner resolution before merge.
- **E2.** Change rejected at review → scenario retained for the record; live schedule unchanged.

**Postconditions** — Live schedule reflects the approved change; revision register updated; pre-change state retained in audit.

---

### UC-PLN-13 — Load resources and produce a manpower histogram

| Field | Detail |
|---|---|
| **Primary actor** | Planning Engineer |
| **Goal** | Establish the labour profile the programme demands |
| **Preconditions** | Activities have durations and dates; norms library populated |
| **Requirements** | FR-PLN-190 to 197 |

**Main flow**

1. Planner assigns a norm code and quantity to each labour-bearing activity.
2. System looks up man-hours per unit from the norms library.
3. System calculates base man-hours as quantity × norm.
4. Planner sets site factor and efficiency factor.
5. System calculates adjusted man-hours as base × site factor ÷ efficiency.
6. System calculates required crew as adjusted man-hours ÷ (working days × hours per day), rounded up.
7. System calculates the duration the rounded crew delivers and flags under-resourced activities.
8. System spreads crew across periods using the activity calendar and aggregates to average manpower per period.
9. System applies the peak factor to produce the peak sizing figure.
10. System produces the histogram in total and by trade, and the labour S-curve.

**Alternate flows**

- **6a. Crew-driven duration.** Planner fixes crew size; system calculates the duration required and reports the variance against the programme duration.

**Exception flows**

- **E1.** Norm code not found in the library → activity flagged; man-hours cannot be calculated.
- **E2.** Zero duration on a loaded activity → crew calculation rejected.

**Postconditions** — Manpower histogram available; under-resourced activities flagged; levelling check populated.

---

### UC-PLN-24 — Respond to a negative float alert

| Field | Detail |
|---|---|
| **Primary actor** | Project Manager |
| **Goal** | Restore the programme to a positive-float position, or record the true position |
| **Preconditions** | CPM run has produced negative float on one or more activities |
| **Requirements** | FR-PLN-075, BR-AM-027 |

**Main flow**

1. System dispatches a Critical notification to Planner, Project Manager and Project Director.
2. Planner identifies the constraint, imposed date or actual date producing the negative float.
3. Planner produces the negative float report listing the affected path.
4. Project Manager reviews mitigation options with the Construction Manager.
5. Planner models the options as schedule scenarios.
6. Project Manager selects an option; the scenario is approved and merged (UC-PLN-17).
7. Where no mitigation exists, the position is recorded and the Contract Administrator issues a delay notice.

**Postconditions** — Either float restored, or the delay position formally recorded and notified.

---

## 4. Use case to requirement traceability

| Use case | Requirements |
|---|---|
| UC-PLN-01 | FR-PLN-001 to 012 |
| UC-PLN-02 | FR-PLN-020 to 027 |
| UC-PLN-03 | FR-PLN-040 to 050 |
| UC-PLN-04 | FR-PLN-060 to 076 |
| UC-PLN-05 | FR-PLN-090 to 097 |
| UC-PLN-06 | FR-PLN-230 to 236 |
| UC-PLN-07 | FR-PLN-110 to 120 |
| UC-PLN-08 | FR-PLN-140 to 151 |
| UC-PLN-09 | FR-PLN-150, NFR-PLN-16 |
| UC-PLN-10 | FR-PLN-067, 144 |
| UC-PLN-11 | FR-PLN-170 to 172 |
| UC-PLN-12 | FR-PLN-175 to 178 |
| UC-PLN-13 | FR-PLN-190 to 197 |
| UC-PLN-14 | FR-PLN-196, 200 |
| UC-PLN-15 | FR-PLN-210 to 219 |
| UC-PLN-16 | FR-PLN-217 |
| UC-PLN-17 | FR-PLN-096, 120, 216 |
| UC-PLN-18 | FR-PLN-114, 115 |
| UC-PLN-19 | FR-PLN-265, Document Control |
| UC-PLN-20 | FR-PLN-281, 283, 284 |
| UC-PLN-21 | FR-PLN-258, 259 |
| UC-PLN-22 | FR-PLN-286 |
| UC-PLN-23 | FR-PLN-148, BOQ Engine |
| UC-PLN-24 | FR-PLN-075 |

---

*DCOS — Planning & Scheduling — Use Cases — Internal Controlled Document*
