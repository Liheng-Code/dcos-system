# 04 — Database Schema

**Module:** Planning & Scheduling

| Field | Value |
|---|---|
| Document code | DCOS-PLN-DB-004 |
| Version | R0 |
| Database | PostgreSQL 15+ / Supabase |
| Related | DCOS-PLN-AM-001 §24; Gap Analysis R1 §8 (ERD Groups) |
| Status | For development |

---

## 1. Design principles

| Principle | Application |
|---|---|
| Tenant isolation at row level | Every table carries `tenant_id` with an RLS policy. No exceptions. |
| Calculated results separated from source data | `activity_schedule_results` is written only by the CPM engine; recalculation never touches planner-owned rows or invalidates concurrency tokens. |
| Append-only history | `activity_progress_history` and `schedule_revisions` are never updated or deleted. |
| Immutable snapshots | Baseline tables have no UPDATE or DELETE path. |
| Soft delete only | `deleted_at` on user-editable tables; hard delete requires admin plus audit. |
| Scenario isolation | Scenario rows are physically separate, keyed by `scenario_id`, never mixed with live rows. |
| Referential integrity enforced in the database | Not only in application code. |

---

## 2. ERD grouping

```
Group PLN-A : Calendar
  calendars, calendar_workweek, calendar_exceptions

Group PLN-B : Activity core
  activities, activity_schedule_results, activity_progress_history,
  activity_steps

Group PLN-C : Coding
  activity_code_types, activity_code_values, activity_code_assignments

Group PLN-D : Logic
  activity_relationships

Group PLN-E : Baseline & revision
  baselines, baseline_activities, baseline_relationships, schedule_revisions

Group PLN-F : Progress
  progress_sessions, progress_session_lines

Group PLN-G : Loading
  productivity_norms, activity_resource_assignments, activity_boq_links,
  resource_availability

Group PLN-H : Look-ahead & Last Planner
  lookahead_windows, weekly_work_plans, wwp_commitments,
  constraint_log, variance_reasons

Group PLN-I : Scenarios & delay
  schedule_scenarios, scenario_activities, scenario_relationships,
  scenario_results, delay_events, delay_event_activities

Group PLN-J : Calculation & health
  calculation_runs, health_check_runs, health_check_findings
```

---

## 3. Group PLN-A — Calendar

### 3.1 `calendars`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK NOT NULL | RLS key |
| project_id | uuid FK NULL | NULL = global/tenant calendar |
| calendar_code | varchar(20) NOT NULL | e.g. `SITE-6D`, `OFFICE-5D`, `CONT-7D` |
| calendar_name | varchar(100) NOT NULL | |
| calendar_type | enum NOT NULL | `global`, `project`, `resource` |
| is_default | boolean NOT NULL DEFAULT false | Project default calendar |
| hours_per_day | numeric(4,2) NOT NULL DEFAULT 8 | |
| created_by / created_at / updated_at | | |

### 3.2 `calendar_workweek`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| calendar_id | uuid FK NOT NULL | |
| day_of_week | smallint NOT NULL | 1 = Monday … 7 = Sunday |
| is_working | boolean NOT NULL | |
| hours | numeric(4,2) | Overrides calendar default for this day |

### 3.3 `calendar_exceptions`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| calendar_id | uuid FK NOT NULL | |
| exception_date | date NOT NULL | |
| is_working | boolean NOT NULL | false = holiday; true = working on a normally non-working day |
| hours | numeric(4,2) | Partial working day |
| description | varchar(120) | e.g. "Khmer New Year" |
| is_confirmed | boolean DEFAULT false | Gazette-confirmed vs indicative (lunar dates) |

```sql
UNIQUE (calendar_id, exception_date);
UNIQUE (calendar_id, day_of_week) ON calendar_workweek;
CREATE UNIQUE INDEX ON calendars (project_id) WHERE is_default AND project_id IS NOT NULL;
```

---

## 4. Group PLN-B — Activity core

### 4.1 `activities`

Full field list in **DCOS-PLN-AM-001 §24.1** (44 fields). Key structure:

| Field | Type | Notes |
|---|---|---|
| id | uuid PK | |
| tenant_id / project_id / wbs_node_id | uuid FK NOT NULL | |
| activity_id | varchar(20) NOT NULL | Unique per project, immutable post-baseline |
| activity_name | varchar(255) NOT NULL | |
| activity_type | enum NOT NULL | `TD`,`RD`,`LOE`,`HAM`,`MS`,`MF` |
| duration_type | enum | `FDU`,`FDUT`,`FU`,`FUT` |
| calendar_id | uuid FK NOT NULL | |
| original_duration | numeric(8,2) NOT NULL | Working days |
| remaining_duration | numeric(8,2) NOT NULL | |
| actual_duration | numeric(8,2) | Calculated |
| at_completion_duration | numeric(8,2) | Calculated |
| planned_start / planned_finish | date | Copied at baseline approval |
| actual_start / actual_finish | date | |
| suspend_date / resume_date | date | |
| constraint_type | enum | See §4.2 enumerations |
| constraint_date | date | |
| constraint_reason | text | Mandatory for hard constraints |
| constraint_approved_by | uuid FK | |
| progress_method | enum NOT NULL | `PHYS`,`DUR`,`UNIT`,`STEP`,`0/100`,`50/50`,`LOE`,`MSTN` |
| percent_complete | numeric(5,2) NOT NULL DEFAULT 0 | |
| total_quantity / installed_quantity | numeric(14,3) | |
| unit_of_measure | varchar(16) | |
| lifecycle_status | enum NOT NULL | See §12 |
| responsible_user_id / responsible_party_id | uuid FK | |
| discipline_code | varchar(8) | |
| cost_account_id | uuid FK | |
| notes | text | Basis of estimate |
| created_by / created_at / updated_by / updated_at / deleted_at | | |

### 4.2 `activity_schedule_results`

**Written only by the CPM engine.** Read-only to the activity write API (BR-AM-015).

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| activity_id | uuid FK NOT NULL | |
| calculation_run_id | uuid FK NOT NULL | |
| data_date | date NOT NULL | |
| early_start / early_finish | date | |
| late_start / late_finish | date | |
| total_float / free_float | numeric(8,2) | Working days |
| is_critical | boolean | |
| is_longest_path | boolean | |
| is_out_of_sequence | boolean | |
| is_open_ended | boolean | |
| driving_predecessor_id | uuid FK | Relationship driving early start |
| calculated_at | timestamptz | |

### 4.3 `activity_progress_history`

Append-only. No UPDATE, no DELETE.

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| activity_id | uuid FK NOT NULL | |
| session_id | uuid FK NULL | Progress session, if part of one |
| data_date | date NOT NULL | |
| percent_complete | numeric(5,2) | |
| remaining_duration | numeric(8,2) | |
| installed_quantity | numeric(14,3) | |
| actual_start / actual_finish | date | |
| comment | text | |
| source_channel | enum | `WEB`,`MOBILE`,`TASK_ROLLUP`,`IMPORT`,`API` |
| device_timestamp | timestamptz | Mobile capture time |
| reported_by | uuid FK | |
| reported_at | timestamptz NOT NULL | |

### 4.4 `activity_steps`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| activity_id | uuid FK NOT NULL | |
| step_no | smallint NOT NULL | |
| description | varchar(255) | |
| weight_percent | numeric(5,2) NOT NULL | Weights must sum to 100 per activity |
| is_complete | boolean DEFAULT false | |
| completed_at | timestamptz | |

---

## 5. Group PLN-C — Coding

### 5.1 `activity_code_types`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK NOT NULL | |
| project_id | uuid FK NULL | NULL = global code type |
| code_type_name | varchar(50) NOT NULL | e.g. "Trade package" |
| code_type_key | varchar(20) NOT NULL | e.g. `TRADE` |
| is_mandatory | boolean DEFAULT false | Enforced at activity creation |
| sort_order | smallint | |
| is_active | boolean DEFAULT true | |

### 5.2 `activity_code_values`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| code_type_id | uuid FK NOT NULL | |
| code_value | varchar(30) NOT NULL | |
| description | varchar(120) | |
| colour | varchar(7) | Hex, for Gantt colour coding |
| sort_order | smallint | |

### 5.3 `activity_code_assignments`

| Field | Type | Description |
|---|---|---|
| activity_id | uuid FK NOT NULL | |
| code_type_id | uuid FK NOT NULL | |
| code_value_id | uuid FK NOT NULL | |

```sql
PRIMARY KEY (activity_id, code_type_id);   -- one value per type per activity
```

---

## 6. Group PLN-D — Logic

### 6.1 `activity_relationships`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id / project_id | uuid FK NOT NULL | |
| predecessor_id | uuid FK NOT NULL | → activities |
| successor_id | uuid FK NOT NULL | → activities |
| relationship_type | enum NOT NULL | `FS`,`SS`,`FF`,`SF` |
| lag | numeric(8,2) NOT NULL DEFAULT 0 | Working days; may be negative |
| lag_calendar_id | uuid FK NULL | NULL = use project setting |
| is_driving | boolean | Set by CPM engine |
| comment | text | |
| created_by / created_at / deleted_at | | |

```sql
UNIQUE (predecessor_id, successor_id, relationship_type) WHERE deleted_at IS NULL;
CHECK  (predecessor_id <> successor_id);
INDEX  (successor_id);
INDEX  (project_id, predecessor_id);
```

Cycle detection is enforced in the application layer (recursive CTE check before commit), since PostgreSQL cannot express it as a constraint.

---

## 7. Group PLN-E — Baseline & revision

### 7.1 `baselines`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id / project_id | uuid FK NOT NULL | |
| baseline_code | varchar(20) NOT NULL | `B0`, `B1`, `REC-01` |
| baseline_name | varchar(120) NOT NULL | |
| baseline_type | enum NOT NULL | `contract`,`revised`,`recovery`,`as_built`,`internal` |
| data_date | date NOT NULL | |
| is_current_comparison | boolean DEFAULT false | One per project |
| health_check_run_id | uuid FK | Result stored with the submission |
| submitted_by / submitted_at | | |
| approved_by / approved_at | | |
| approval_reference | varchar(60) | Workflow instance reference |
| status | enum | `draft`,`submitted`,`approved`,`superseded`,`rejected` |

### 7.2 `baseline_activities`

Immutable snapshot. One row per activity per baseline.

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| baseline_id | uuid FK NOT NULL | |
| activity_id | uuid FK NOT NULL | Stable reference for comparison |
| activity_code | varchar(20) | Snapshot of the human-readable ID |
| activity_name | varchar(255) | |
| wbs_node_id | uuid | |
| calendar_id | uuid | |
| original_duration | numeric(8,2) | |
| early_start / early_finish | date | |
| late_start / late_finish | date | |
| total_float | numeric(8,2) | |
| is_critical | boolean | |
| progress_method | enum | Locked value |
| budget_value | numeric(16,2) | |
| budgeted_units | numeric(14,3) | |

### 7.3 `baseline_relationships`

| Field | Type |
|---|---|
| id | uuid PK |
| baseline_id | uuid FK NOT NULL |
| predecessor_id / successor_id | uuid |
| relationship_type | enum |
| lag | numeric(8,2) |

### 7.4 `schedule_revisions`

Append-only change control record.

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id / project_id | uuid FK NOT NULL | |
| activity_id | uuid FK NULL | NULL for project-level changes |
| revision_no | integer NOT NULL | Sequential per project |
| change_type | enum | `duration`,`logic`,`calendar`,`constraint`,`scope_add`,`scope_delete`,`resequence` |
| before_values | jsonb | |
| after_values | jsonb | |
| reason | text NOT NULL | |
| trigger_type | enum | `variation`,`instruction`,`delay_event`,`acceleration`,`design_change`,`correction` |
| trigger_reference | varchar(60) | VO number, EI number, delay event ID |
| scenario_id | uuid FK NULL | Source scenario if merged |
| approved_by / approved_at | | |
| created_by / created_at | | |

---

## 8. Group PLN-F — Progress sessions

### 8.1 `progress_sessions`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id / project_id | uuid FK NOT NULL | |
| data_date | date NOT NULL | Locked for the session |
| status | enum | `open`,`previewed`,`committed`,`abandoned` |
| preview_completion_date | date | Result of preview CPM run |
| preview_run_id | uuid FK | |
| committed_run_id | uuid FK | |
| opened_by / opened_at | | |
| committed_by / committed_at | | |

### 8.2 `progress_session_lines`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| session_id | uuid FK NOT NULL | |
| activity_id | uuid FK NOT NULL | |
| prepopulated_percent | numeric(5,2) | From task roll-up |
| prepopulated_source | enum | `task_rollup`,`mobile`,`none` |
| entered_percent | numeric(5,2) | |
| entered_remaining_duration | numeric(8,2) | |
| entered_installed_quantity | numeric(14,3) | |
| entered_actual_start / entered_actual_finish | date | |
| out_of_sequence_flag | boolean | |
| out_of_sequence_decision | enum | `accept`,`fix_logic`,`fix_progress` |
| comment | text | |

---

## 9. Group PLN-G — Loading

### 9.1 `productivity_norms`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK NOT NULL | |
| norm_code | varchar(20) NOT NULL | e.g. `RC-SLAB` |
| description | varchar(200) | |
| trade | varchar(30) | |
| unit_of_measure | varchar(16) | |
| man_hours_per_unit | numeric(10,4) NOT NULL | |
| source_note | varchar(200) | Basis of the norm |
| is_active | boolean DEFAULT true | |

### 9.2 `activity_resource_assignments`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| activity_id | uuid FK NOT NULL | |
| resource_id | uuid FK NULL | → resource master (HR/Plant) |
| norm_code | varchar(20) | → productivity_norms |
| quantity | numeric(14,3) | Work quantity |
| site_factor | numeric(5,3) DEFAULT 1.000 | Condition adjustment |
| efficiency_factor | numeric(5,3) DEFAULT 0.850 | Utilisation |
| hours_per_day | numeric(4,2) DEFAULT 8 | |
| base_man_hours | numeric(12,2) | Calculated: quantity × norm |
| adjusted_man_hours | numeric(12,2) | Calculated: base × site ÷ efficiency |
| calculated_crew | numeric(8,2) | Calculated |
| assigned_crew | integer | Rounded up, or planner-set |
| budgeted_units / remaining_units / actual_units | numeric(14,3) | |

### 9.3 `activity_boq_links`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| activity_id | uuid FK NOT NULL | |
| boq_item_id | uuid FK NOT NULL | → BOQ Engine |
| allocated_quantity | numeric(14,3) NOT NULL | |
| unit_rate | numeric(14,4) | Snapshot at link time |
| budget_value | numeric(16,2) | Calculated |

Constraint enforced in application layer: `SUM(allocated_quantity) per boq_item_id <= boq_item.quantity` (BR-AM-025).

### 9.4 `resource_availability`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| project_id | uuid FK NOT NULL | |
| period_start | date NOT NULL | Month start |
| trade | varchar(30) NULL | NULL = total |
| available_headcount | integer NOT NULL | |
| notes | text | |

---

## 10. Group PLN-H — Look-ahead & Last Planner

### 10.1 `lookahead_windows`

| id | uuid PK |
|---|---|
| project_id | uuid FK NOT NULL |
| window_start / window_end | date |
| weeks | smallint DEFAULT 6 |
| generated_at | timestamptz |
| generated_by | uuid FK |

### 10.2 `constraint_log`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| project_id | uuid FK NOT NULL | |
| activity_id | uuid FK NOT NULL | |
| constraint_category | enum | `design`,`material`,`labour`,`plant`,`permit`,`access`,`predecessor`,`information` |
| description | text NOT NULL | |
| raised_by / raised_at | | |
| owner_user_id | uuid FK | Responsible for clearing |
| required_by_date | date | |
| status | enum | `open`,`in_progress`,`cleared`,`escalated` |
| cleared_at | timestamptz | |

### 10.3 `weekly_work_plans` / `wwp_commitments`

| Field (wwp_commitments) | Type | Description |
|---|---|---|
| id | uuid PK | |
| wwp_id | uuid FK NOT NULL | |
| activity_id | uuid FK NOT NULL | |
| task_id | uuid FK NULL | Construction module field task |
| committed_by | uuid FK | Last planner making the commitment |
| planned_quantity | numeric(14,3) | |
| achieved_quantity | numeric(14,3) | |
| is_met | boolean | |
| variance_reason_code | varchar(20) FK | → variance_reasons |

`weekly_work_plans` carries `project_id`, `week_start`, `week_end`, `ppc_percent` (calculated), `status`.

### 10.4 `variance_reasons`

| code | varchar(20) PK |
|---|---|
| description | varchar(120) |
| category | enum `design`,`material`,`labour`,`plant`,`permit`,`access`,`weather`,`predecessor`,`rework`,`other` |

---

## 11. Group PLN-I — Scenarios & delay

### 11.1 `schedule_scenarios`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| tenant_id / project_id | uuid FK NOT NULL | |
| scenario_name | varchar(120) NOT NULL | |
| purpose | enum | `tia`,`recovery`,`acceleration`,`what_if`,`change_impact` |
| source_data_date | date NOT NULL | |
| source_baseline_id | uuid FK NULL | |
| delay_event_id | uuid FK NULL | |
| completion_date_source | date | Source schedule completion |
| completion_date_scenario | date | Scenario completion |
| net_impact_days | numeric(8,2) | Calculated |
| status | enum | `draft`,`calculated`,`submitted`,`approved`,`merged`,`rejected`,`archived` |
| created_by / created_at / merged_at | | |

`scenario_activities`, `scenario_relationships` and `scenario_results` mirror the live tables with `scenario_id` as an additional NOT NULL key. Scenarios are retained permanently (FR-PLN-219).

### 11.2 `delay_events`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| project_id | uuid FK NOT NULL | |
| event_reference | varchar(40) NOT NULL | |
| event_date | date NOT NULL | |
| notification_date | date | Contractual notice date |
| category | enum | `employer_risk`,`contractor_risk`,`neutral`,`concurrent` |
| cause_description | text NOT NULL | |
| entitlement_claimed | enum | `time_only`,`time_and_cost`,`cost_only`,`none` |
| scenario_id | uuid FK NULL | TIA scenario |
| net_impact_days | numeric(8,2) | |
| status | enum | `identified`,`notified`,`under_assessment`,`agreed`,`rejected`,`disputed` |

`delay_event_activities` links events to affected activities with `impact_days` and `evidence_document_id`.

---

## 12. Group PLN-J — Calculation & health

### 12.1 `calculation_runs`

| Field | Type | Description |
|---|---|---|
| id | uuid PK | |
| project_id | uuid FK NOT NULL | |
| scenario_id | uuid FK NULL | NULL = live schedule |
| data_date | date NOT NULL | |
| trigger_type | enum | `manual`,`activity_change`,`logic_change`,`progress_commit`,`calendar_change`,`import` |
| trigger_reference | uuid | |
| status | enum | `queued`,`running`,`complete`,`failed` |
| activity_count / relationship_count | integer | |
| project_finish_date | date | Result |
| critical_count | integer | |
| negative_float_count | integer | |
| duration_ms | integer | |
| error_message | text | |
| started_at / completed_at | timestamptz | |

### 12.2 `health_check_runs` / `health_check_findings`

| Field (findings) | Type | Description |
|---|---|---|
| id | uuid PK | |
| run_id | uuid FK NOT NULL | |
| check_code | varchar(10) | `VC-01` … `VC-30` |
| severity | enum | `blocking`,`warning`,`information` |
| result | enum | `pass`,`fail` |
| measured_value | numeric(8,2) | |
| threshold_value | numeric(8,2) | |
| affected_activity_ids | uuid[] | |

---

## 13. Enumerations

```sql
CREATE TYPE activity_type      AS ENUM ('TD','RD','LOE','HAM','MS','MF');
CREATE TYPE duration_type      AS ENUM ('FDU','FDUT','FU','FUT');
CREATE TYPE progress_method    AS ENUM ('PHYS','DUR','UNIT','STEP','ZERO_HUNDRED','FIFTY_FIFTY','LOE','MSTN');
CREATE TYPE constraint_type    AS ENUM ('SNET','SNLT','FNET','FNLT','MSO','MFO','MANS','MANF','ALAP','EXP');
CREATE TYPE relationship_type  AS ENUM ('FS','SS','FF','SF');
CREATE TYPE activity_status    AS ENUM ('draft','planned','baselined','in_progress','suspended',
                                        'complete','closed','cancelled');
CREATE TYPE baseline_type      AS ENUM ('contract','revised','recovery','as_built','internal');
CREATE TYPE scenario_purpose   AS ENUM ('tia','recovery','acceleration','what_if','change_impact');
CREATE TYPE source_channel     AS ENUM ('WEB','MOBILE','TASK_ROLLUP','IMPORT','API');
CREATE TYPE finding_severity   AS ENUM ('blocking','warning','information');
```

---

## 14. Indexes and constraints

```sql
-- activities
CREATE UNIQUE INDEX ux_act_project_code ON activities (project_id, activity_id)
  WHERE deleted_at IS NULL;
CREATE INDEX ix_act_tenant_proj_wbs ON activities (tenant_id, project_id, wbs_node_id);
CREATE INDEX ix_act_status          ON activities (project_id, lifecycle_status);
CREATE INDEX ix_act_responsible     ON activities (project_id, responsible_user_id);
CREATE INDEX ix_act_calendar        ON activities (calendar_id);

CHECK (original_duration >= 0);
CHECK (remaining_duration >= 0);
CHECK (percent_complete BETWEEN 0 AND 100);
CHECK (actual_finish IS NULL OR actual_start IS NOT NULL);
CHECK (actual_finish IS NULL OR actual_finish >= actual_start);
CHECK (activity_type NOT IN ('MS','MF') OR original_duration = 0);
CHECK (activity_type IN ('MS','MF') OR original_duration > 0);
CHECK (suspend_date IS NULL OR resume_date IS NULL OR resume_date >= suspend_date);

-- results
CREATE UNIQUE INDEX ux_res_act_run ON activity_schedule_results (activity_id, calculation_run_id);
CREATE INDEX ix_res_critical ON activity_schedule_results (calculation_run_id) WHERE is_critical;

-- progress history
CREATE INDEX ix_prog_act_date ON activity_progress_history (activity_id, data_date DESC);

-- relationships
CREATE INDEX ix_rel_pred ON activity_relationships (predecessor_id) WHERE deleted_at IS NULL;
CREATE INDEX ix_rel_succ ON activity_relationships (successor_id)  WHERE deleted_at IS NULL;

-- baseline
CREATE UNIQUE INDEX ux_baseline_current ON baselines (project_id)
  WHERE is_current_comparison;
CREATE INDEX ix_bl_act ON baseline_activities (baseline_id, activity_id);
```

---

## 15. Row-level security

Applied to **every** table in this module without exception.

```sql
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON activities
  USING (tenant_id = (auth.jwt() ->> 'tid')::uuid);

CREATE POLICY project_scope ON activities
  USING (project_id::text = ANY (
    SELECT jsonb_array_elements_text(auth.jwt() -> 'prj')
  ));

-- Scale path (NestJS sets transaction-local context)
-- SET LOCAL app.current_tenant = '...';
-- USING (tenant_id = current_setting('app.current_tenant')::uuid);
```

**CI requirement (NFR-PLN-10):** an automated test must fail the build if any table in this module lacks an enabled RLS policy, and cross-tenant read attempts must be proven to return zero rows.

---

## 16. Write-path rules

| Table | INSERT | UPDATE | DELETE |
|---|---|---|---|
| activities | Yes | Yes | Soft only |
| activity_schedule_results | CPM engine only | Never | By retention job only |
| activity_progress_history | Yes | **Never** | **Never** |
| baselines | Yes | Status only | **Never** |
| baseline_activities | Snapshot only | **Never** | **Never** |
| schedule_revisions | Yes | **Never** | **Never** |
| calculation_runs | Yes | Status/result only | Retention job |
| schedule_scenarios | Yes | Yes | Archive only, never purge |
| delay_events | Yes | Yes | **Never** |

---

## 17. Retention

| Data | Active | Archive |
|---|---|---|
| Activities and relationships | Project duration + 2 years | 10 years |
| Progress history | Project duration + DLP + 5 years | 10 years |
| Baselines and baseline snapshots | Permanent | Permanent |
| Schedule revisions | Permanent | Permanent |
| Scenarios and delay events | Permanent | Permanent |
| Calculation runs | 90 days detail | Summary retained 2 years |
| Health check runs | Latest 20 per project + all baseline submissions | 5 years |

---

*DCOS — Planning & Scheduling — Database Schema — Internal Controlled Document*
