# 12 — Training Guide
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-12-TRN |
| Version | R1 |
| Standard | ISO/IEC/IEEE 26514 (user documentation) |
| Audience | QS, estimating, procurement, site, and finance staff |

---

## 1. Training Paths

| Path | Audience | Duration | Modules |
|---|---|---|---|
| A — Estimator | Estimators, junior QS | 1 day | T1, T2, T3 |
| B — Project QS | QS Engineers | 2 days | T1, T4, T5, T6, T7 |
| C — QS Manager | QS Managers | 2.5 days | All + T10 (approvals, overrides, certification) |
| D — Procurement | Procurement, store | 0.5 day | T1, T8 |
| E — Management | PM, Directors, Finance | 0.5 day | T1, T9 |
| F — Site requester | Site engineers | 2 hours | T1 (short), T8 (PR only) |

Delivery: instructor-led on the staging environment with seeded data, one exercise per module, competency check at the end of each path.

## 2. Module T1 — Foundations (all paths, 45 min)

**Concepts:** the commercial chain (price list → unit rate → BOQ → budget → cost → claim → retention → final account); why the BOQ is locked; the difference between cost rate and sell rate; what "committed" means; the WBS as the spine.

**Navigation:** project selector, QS menu structure, status badges and their meanings, variance colour bands, the lock banner.

**The three habits:**
1. Check the status badge before you try to edit.
2. Read the computed field, don't recompute it yourself.
3. If a control blocks you, the override path exists — use it with a reason, never a workaround.

**Exercise:** locate a project's contract sum, certified to date, and retention outstanding within two minutes.

## 3. Module T2 — Price List & Unit Rates (Estimator, 90 min)

**Learn:** entering resource prices with supplier, quote reference, and validity; building a rate in build-up mode (composition lines, quantity per unit, wastage on material lines, productivity on labor/plant); reading the summary panel; flat mode and when it is acceptable.

**Exercise:** build UR-CON-001 from seed data and confirm the net rate is **71.87**. Then change cement from 4.20 to 4.60 and confirm the rate becomes **74.81** and that concrete, blockwork, and plaster all recalculate while MEP rates do not.

**Common mistakes:** typing a rate instead of composing it (loses recalculation); wastage entered on labor lines; deleting a price-list item instead of deactivating it.

## 4. Module T3 — Tender Pricing & Bid Summary (Estimator, 2 h)

**Learn:** measuring the tender BOQ and linking rates (unit must match); prelims as time-related × programme duration; risk items versus contingency (never both for the same risk); sub-quote normalization and preferred selection; the bid summary chain and what each percentage applies to; revision control — draft is working space, finalize freezes everything, a new revision needs a reason.

**Exercise:** price a 10-item tender, finalize Revision 1, then handle an addendum by creating Revision 2 with a reason and confirm Revision 1 is unchanged.

## 5. Module T4 — Baseline & Margin (Project QS, 60 min)

**Learn:** approving and locking the BOQ; what locking prevents; markup settings and how sell rates are produced; expected margin per item; the firewall — who can see cost and margin, and why client exports never contain them.

**Exercise:** lock a BOQ, attempt an edit (observe the block), then process a legitimate change through a VO.

## 6. Module T5 — Cost Recording & Budget Control (Project QS, 90 min)

**Learn:** recording invoices, POs, timesheets, deliveries; allocating to BOQ items and WBS nodes; the pending → approved → paid lifecycle; correcting mistakes by contra entry; reading budget vs committed vs actual vs forecast; investigating a red variance.

**Exercise:** record five transactions, approve them, produce a variance report, and explain one red item in writing.

**Common mistakes:** leaving transactions unallocated to a BOQ item (invisible in variance); trying to delete an approved transaction.

## 7. Module T6 — Variations (Project QS, 60 min)

**Learn:** when a change is a VO; raising with type, description, line items, and schedule impact; the threshold routing chain and why it cannot be shortened; rejection reasons; marking implemented; the effect on contract sum to date and the next IPC.

**Exercise:** raise VOs of $3,200, $25,000, and $80,000 and confirm the three different approval chains. Reject one and resubmit.

## 8. Module T7 — IPC & Retention (Project QS, 2 h — the most important module)

**Learn:** initializing claim items from the locked BOQ; entering this-period and materials-stored; why over-claim is blocked; reading the G702 summary; submitting; how client adjustments are recorded; what certification does (records certifier, creates the retention deduction); retention releases at PC and DLP.

**Exercise:** produce IPC #3 with the seed data and confirm: contract sum to date **292,972.00**, retention **7,324.30**, current payment due **40,661.70**. Then certify and confirm the retention ledger entry appears automatically.

**Common mistakes:** claiming beyond scheduled value; forgetting approved VOs before submission; attempting to enter retention manually; leaving a claim in draft past the contractual submission date.

## 9. Module T8 — Procurement Controls (Procurement, Site, 60 min)

**Learn:** what the procurement baseline is; the three checks on a PR line (budget, quantity, price) and their colours; why a budget link is mandatory; requesting an override with a reason; the baseline column in the RFQ comparison; what happens at PO approval (commitment); the buy-out report.

**Exercise:** raise a PR line for 400 bags of cement and interpret the results — check 2 at **97.4%** of allowable, check 3 **amber at +3.6%**. Then raise a line that exceeds budget and process the override correctly.

## 10. Module T9 — Management Reporting (Management, 45 min)

**Learn:** reading the EVM dashboard (CPI, SPI, EAC, VAC and the health bands); the S-curve and what divergence means; cash flow forecast; the portfolio view; cost per m² and its basis footnote (includes prelims and OH&P; excludes VAT, land, fees, FF&E, external works); split versus blended basement reporting.

**Exercise:** review a project showing CPI 0.92 and explain what it means, what to ask the QS Manager, and what action to require.

## 11. Module T10 — Approvals & Authority (QS Manager, 60 min)

**Learn:** every approval you hold and its threshold; segregation of duties (you cannot approve what you raised); recording reasons that will make sense in three years; the override register and how it is reviewed; certification responsibility; final account and the two-version cost report.

**Exercise:** process one of each: VO approval, cost transaction approval, PR override, retention release, and a claim certification — then read your own audit trail.

## 12. Competency Checklist

| Competency | Path |
|---|---|
| Builds a unit rate and explains its recalculation behaviour | A, B, C |
| Prices and finalizes a tender revision correctly | A, C |
| Locks a baseline and explains what changes require a VO | B, C |
| Records and corrects cost transactions properly | B, C, D |
| Raises a VO and predicts its approval chain | B, C |
| Produces a correct IPC and explains every G702 line | B, C |
| Interprets three baseline check results on a PR | C, D, F |
| Explains CPI/SPI and the action each value requires | C, E |
| States the cost/m² basis without prompting | C, E |
| Knows which figures never leave the company | All |

## 13. Quick Reference Card (print for desks)

```
Status badges   draft grey · submitted blue · approved green · locked navy
                certified teal · paid dark green · rejected red
Variance bands  green ≤0%  ·  amber 0–5%  ·  red >5%
VO routing      <5k PM  ·  5k–50k PM+QSM  ·  ≥50k PM+QSM+Director
Retention       5% deducted at certification · 50% at PC · 50% at DLP
Never do        edit a locked BOQ · enter retention by hand · delete an approved cost
                · send cost or margin figures to a client
Always do       link every cost and PR line to a BOQ item · give a reason on every
                rejection and override · submit the IPC on the contract date
```

## 14. Support & Refreshers

First-week floor support during go-live; a named super-user per project team; quarterly 30-minute refreshers focused on the month-end sequence; new-joiner induction within the first two weeks; the SOP set (doc 11) is the authority whenever training material and procedure disagree.
