# 01 — Business Requirement Document (BRD)
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-01-BRD |
| Version | R1 |
| Standard | BABOK-aligned |
| Status | For Approval |
| Owner | Commercial Director |
| Related | DCOS Architecture R0, Gap Analysis R1 (§4.1 BOQ, §4.7 Retention, §4.8 IPC) |

---

## 1. Executive Summary

The Quantity Surveying module is the commercial engine of DCOS. It carries a project from tender pricing through contract baseline, cost control, payment certification, and final account — replacing the spreadsheets that currently hold the company's most financially significant data.

The Gap Analysis R1 scored the financial/commercial layer **3/10 — the most critical gap in the platform**, with five risks rated *Certain × Critical*: no BOQ engine, no IPC workflow, no retention module, no subcontract module, no multi-currency. This module closes them.

## 2. Business Problem

| Problem | Current state | Business consequence |
|---|---|---|
| Tender pricing in Excel | Rates retyped per tender; no rate history | Slow bids; inconsistent pricing; no learning between projects |
| No cost baseline in system | Budget lives in a spreadsheet on one person's laptop | Nobody knows real-time budget position; over-spend discovered at month end |
| Manual IPC preparation | Excel + manual retention arithmetic | Billing errors, late claims, cash flow damage, audit exposure |
| Variations tracked informally | Email and memory | Lost entitlement; disputes at final account |
| Procurement uncontrolled by budget | POs raised without budget check | Silent over-commitment; margin erosion invisible until too late |
| No margin visibility | Cost and sell mixed in one rate | Cannot tell whether a project is making money until it ends |

## 3. Business Objectives

| # | Objective | Measure of success |
|---|---|---|
| BO-1 | Price a tender end-to-end in the system | Zero Excel in the bid submission chain |
| BO-2 | Establish one locked cost baseline per project | 100% of active projects have a locked BOQ |
| BO-3 | Produce every IPC from the system | First month-end billing issued from DCOS; retention auto-calculated |
| BO-4 | Control commitment before spend | ≥85% of PR value carries a budget link |
| BO-5 | Real-time commercial position | Budget vs committed vs actual vs forecast on one screen, same day |
| BO-6 | Protect entitlement | 100% of variations and employer instructions registered with dates |
| BO-7 | Learn between projects | Won-tender rates and final margins feed the rate library |

## 4. Scope

**In scope:** Tender & Estimate (price list, unit rates, tender BOQ, prelims, risk, sub-quotes, bid summary, cover); Cost Control (BOQ baseline, budget & variance, cost transactions, VO, EVM, S-curve, time-phased baseline & cash flow, IPC, retention, final account); Subcontractor commercial (sub-IPC, back charges); Contract Administration (EI, notices, entitlements); company Resource & Rate Libraries; procurement integration controls.

**Out of scope:** general ledger and statutory accounting (Finance module); procurement transaction processing (Procurement module — QS supplies the controls); WBS engine, document control, approval/notification/audit engines, RBAC (platform).

## 5. Stakeholders

| Stakeholder | Primary need |
|---|---|
| Commercial Director | Portfolio margin position; approval of variations and baselines |
| QS Manager | Baseline integrity, IPC certification, retention, buy-out control |
| QS Engineer / Estimator | Fast, accurate pricing and measurement; less rekeying |
| Project Manager | Budget position per WBS; variation status |
| Procurement Manager | Budget availability and baseline price at PR/PO |
| Finance | Certified values, payment triggers, retention balances |
| Client / Consultant QS | Clear, certifiable claims with supporting measurement |
| Subcontractors | Timely, transparent assessment and payment |

## 6. Business Requirements

| ID | Requirement | Priority |
|---|---|---|
| BR-01 | Maintain a company resource price database and reusable unit-rate compositions | Must |
| BR-02 | Price a tender: BOQ, prelims, risk, sub-quotes, bid summary with revision control | Must |
| BR-03 | Convert the awarded tender into a locked contract BOQ baseline | Must |
| BR-04 | Apply margin to produce client-facing sell rates while keeping cost rates internal | Must |
| BR-05 | Record cost transactions and show budget vs committed vs actual per BOQ item and WBS | Must |
| BR-06 | Manage variations with value-threshold approval routing | Must |
| BR-07 | Produce monthly IPCs in G702 format with automatic retention deduction | Must |
| BR-08 | Maintain a retention ledger with PC and DLP release control | Must |
| BR-09 | Distribute the budget across months and forecast cash flow | Should |
| BR-10 | Report EVM metrics and health status per project and portfolio | Should |
| BR-11 | Control procurement commitment against the baseline (budget, quantity, price) | Must |
| BR-12 | Assess subcontractor payments and back charges against subcontract BOQs | Must |
| BR-13 | Register employer instructions with contractual time-bar alerts | Should |
| BR-14 | Produce a final account and a two-version final cost report (internal / client) | Must |
| BR-15 | Benchmark cost per m² using WBS-entered GFA and site area | Should |
| BR-16 | Multi-currency contract and cost handling | Could (Phase 4) |

## 7. Business Rules (governing)

1. The locked BOQ is the single contract baseline; only an approved Variation Order changes it.
2. Contract Sum to Date = Original Contract Sum + Net Approved Variations.
3. Certified IPCs create retention deductions automatically; retention is never entered by hand.
4. Cost rates, markup, and margin are never exposed in client-facing output.
5. Approved and paid cost records are immutable; corrections are made by contra entry.
6. Every approval, rejection, and override records identity, timestamp, and (on rejection) reason.
7. Planned Value and the planned S-curve derive only from the approved time-phased baseline.

## 8. Assumptions & Constraints

Contracts are USD-denominated with local-currency costs (Cambodia); prices are quoted ex-VAT with VAT applied at bid summary; retention is typically 5% with 50% released at Practical Completion; monthly IPC cycles; labour is largely engaged through labour-only subcontract at day rates; the platform is multi-tenant with row-level security; Supabase/PostgreSQL for MVP, NestJS at scale.

## 9. Benefits

Faster tenders through rate reuse; no billing errors or missed retention; commitment controlled before money is spent; margin erosion visible in-month rather than at completion; defensible audit trail for claims and disputes; institutional pricing knowledge retained when staff leave.

## 10. Risks of Not Proceeding

Manual Excel billing (certain, critical); incorrect retention and legal exposure (certain, critical); uncontrolled subcontract leakage (certain, critical); loss of contractual entitlement through unregistered instructions (likely, high); inability to demonstrate cost control to clients and lenders (likely, high).

## 11. Acceptance

| Role | Name | Signature | Date |
|---|---|---|---|
| Commercial Director | | | |
| QS Manager | | | |
| Project Director | | | |
