# 10 — Deployment Notes
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-10-DEP |
| Version | R1 |
| Environments | local → dev → staging → production |
| Stack | Next.js (Vercel) · Supabase PostgreSQL + Storage · NestJS services at scale · GitHub Actions |

---

## 1. Environments

| Env | Purpose | Data | Access |
|---|---|---|---|
| Local | Development | Seed data only | Developer |
| Dev | Integration | Seeded + synthetic | Dev team |
| Staging | UAT and rehearsal | Anonymised copy of production | QS staff, QA |
| Production | Live projects | Real commercial data | Role-based |

Rule: production commercial data is never copied to dev. Staging refreshes use an anonymisation script (supplier names, contract values scaled, client identities masked).

## 2. Release Sequence

Deploy in dependency order — the module will not function if a later group lands before an earlier one:

1. **Migrations G1–G3** (libraries, tender, baseline + WBS quantities) + RLS policies
2. **Migrations G4–G5** (cost, commercial)
3. **Migrations G6–G8** (procurement link, subcontract, contract admin)
4. Backend services and API routes
5. Report renderers and templates (RPT-QS-01…08)
6. Frontend
7. Seed/reference data (see §4)
8. Feature flags enabled per tenant

## 3. Database Migration Rules

- Every migration idempotent and reversible; RLS policy created in the same migration as its table.
- Additive first: add columns nullable, backfill, then enforce `NOT NULL` in a later migration — never block a deploy on a long backfill.
- No destructive migration on commercial tables without a pre-migration export retained for 90 days.
- Backfill scripts run in batches with progress logging; long-running ones execute out of hours.
- Post-migration verification: row counts, `SELECT` under a test tenant to confirm RLS, and the RLS coverage check (`every tenant-scoped table has a policy`) must pass or the release is rolled back.

## 4. Reference & Seed Data

| Data | Environment | Source |
|---|---|---|
| Cambodia price lists (STR 72 / ARC 77 / MEP 100 items) | dev, staging, and as a per-tenant starter | `seed_price_list_{STR,ARC,MEP}_cambodia.sql` |
| FS-QS-001 mock templates (ARC/STR/MEP rates, BOQ) | dev, staging only | Feature-spec seed |
| Status lists, VO thresholds, retention defaults, variance bands | all | Configuration seed |
| Report templates | all | Versioned in repo (`templates/qs/*`) |

Never load the FS-QS-001 mock template and the Cambodia price list into the same tender — shared codes with different prices will silently dedupe.

## 5. Configuration Parameters

Set per tenant/project at deployment, never hard-coded:

| Parameter | Default |
|---|---|
| VO approval thresholds | $5,000 / $50,000 |
| Retention percentage; PC release share | 5%; 50% |
| Price variance bands | green ≤0%, amber 0–5%, red >5% |
| Quantity tolerance | 105% of allowable |
| Direct-purchase limit; PR routing threshold | $500; $5,000 |
| Invoice price tolerance; stale commitment age | 1%; 60 days |
| EVM health thresholds | CPI/SPI 0.95 |
| Base currency; VAT rate | USD; 10% |

Changing a threshold does not re-route in-flight records; the chain fixed at submission governs (doc 02, FR-405).

## 6. Feature Flags

`qs.tender_estimation` · `qs.margin_engine` · `qs.monthly_baseline` · `qs.procurement_baseline` · `qs.subcontract` · `qs.contract_admin` · `qs.reports_pdf`. Enable per tenant after that tenant's UAT; disabling a flag hides the UI but never deletes data.

## 7. Go-Live Checklist

**Before:** migrations applied and verified; RLS coverage test green; configuration set per tenant; report templates rendering correctly on staging; opening balances prepared (§8); user roles assigned per doc 07; training completed (doc 12); rollback plan rehearsed.

**Cutover:** freeze the legacy spreadsheet at an agreed date/time; load opening balances; reconcile totals to the spreadsheet **to the cent** and obtain QS Manager sign-off; enable flags; announce the freeze to all users.

**After:** daily reconciliation for the first week; first IPC produced in parallel (system + spreadsheet) and compared before issuing to the client; defect triage twice daily for two weeks.

## 8. Opening Balances (mid-contract onboarding)

Most first deployments are on projects already running. Load in this order:

1. Contract BOQ (as awarded) → approve → lock.
2. Approved variations to date → mark implemented (contract sum to date must equal the current agreed figure).
3. Certified claims to date as a single opening claim record per prior claim, at certified values, marked `paid` where paid.
4. Retention ledger opening balance derived from those claims — verify against the client's certificates.
5. Committed POs still open → commitments; incurred costs to date → cost transactions at status `approved`/`paid`.
6. Reconcile: contract sum to date, certified to date, retention outstanding, and cost to date each match the manual records exactly before go-live.

Do not begin live claiming until step 6 is signed off — an incorrect "previous certificates" figure propagates into every future claim.

## 9. Rollback

Frontend and API: redeploy the previous build (minutes). Database: prefer forward fixes; a reverse migration is used only if no commercial record has been created since deploy. If commercial records exist, roll forward with a corrective migration and reconcile. Point-in-time recovery available for 30 days; restore is a last resort and requires Commercial Director authorisation because it discards subsequent commercial entries.

## 10. Monitoring & Support

Application errors to Sentry; slow-query and API latency dashboards against NFR-01 targets; alerts on: failed commitment writes, failed retention creation, RLS policy errors, report generation failures, and integration retry exhaustion. Financial-event audit volume monitored — a sudden drop means logging has broken, which is itself an incident.

## 11. Backup & Retention

Hourly incremental, daily full, stored in a separate region; monthly restoration test with time recorded. Commercial and audit data retained 7–10 years per the platform retention policy; archived tenders after 5 years to cold storage with metadata retained for search.
