# 02 — Functional Specification
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-02-FS |
| Version | R1 |
| Standard | IEEE 29148 / IEEE 1016 |
| Status | For Development |
| Traces to | 01-Business-Requirement (BR-01…BR-16) |

---

## 1. Module Structure

```
Quantity Surveying
├── Tender & Estimate    price list · unit rates · tender BOQ · prelims ·
│                        risk items · sub quotes · bid summary · cover
├── Cost Control         BOQ baseline · budget & variance · cost transactions ·
│                        VO · EVM · S-curve · monthly baseline & cash flow ·
│                        IPC · retention · final account
├── Subcon Mgmt          sub-IPC · back charges · performance notices
├── Contract Admin       employer instructions · notices · entitlements
└── Libraries            resource library · rate library
```

## 2. Functional Requirements

### FR-100 Resource & Rate Libraries (BR-01)

| ID | Requirement |
|---|---|
| FR-101 | Maintain company resource records: code, description, category (material/labor/plant/subcon), unit, price, supplier, quote reference, validity, active flag |
| FR-102 | Category is a filter, not a separate module — one resource table serves material, labor, plant, and subcontract |
| FR-103 | Maintain reusable unit-rate compositions (recipes) independent of price |
| FR-104 | Copy a library composition into a tender and re-link its lines to that tender's price list by resource code; unmatched lines flag for pricing |
| FR-105 | A resource referenced by any rate line cannot be deleted; deactivation only |

### FR-200 Tender Estimation (BR-02)

| ID | Requirement |
|---|---|
| FR-201 | Per-tender price list with the fields of FR-101; prices are per-tender snapshots of market quotes |
| FR-202 | Unit rates in two modes: **flat** (base rate + wastage + productivity) and **build-up** (composition lines referencing price list items) |
| FR-203 | Build-up computation: material line = qty × price × (1+wastage%); labor/plant line = qty × price; net rate = material subtotal + (labor+plant subtotal ÷ productivity) |
| FR-204 | Flat computation: net rate = base × (1+wastage%) ÷ productivity |
| FR-205 | Tender BOQ items link to a unit rate by reference; unit of rate must equal unit of item; amount = qty × rate |
| FR-206 | Manual rate override per BOQ item with visible flag; excluded from recalculation |
| FR-207 | Preliminaries: time-related items (monthly rate × programme duration) and fixed items |
| FR-208 | Risk items: description, likelihood, impact, priced allowance |
| FR-209 | Sub-quotes: multiple quotes per trade package, scope normalization notes, one preferred quote per package |
| FR-210 | Bid summary: Direct + Subcon + Prelims → overhead % → profit % → contingency → risk → VAT → total bid price; calculation bases fixed and displayed |
| FR-211 | Bid summary revision control: draft editable; finalize freezes and snapshots all input tabs; new revision requires a reason and clones the previous |
| FR-212 | Cover / tender summary renders from the final revision only; section totals only, no OH/profit breakdown |
| FR-213 | Price change while draft recalculates all dependent rates, BOQ items, and bid totals in one transaction |

### FR-300 Contract Baseline & Margin (BR-03, BR-04)

| ID | Requirement |
|---|---|
| FR-301 | BOQ baseline statuses: draft → approved → locked → revised; lock is one-way |
| FR-302 | Post-lock edits blocked at API and UI; changes only via approved VO or budget revision (audit record) |
| FR-303 | Project markup settings per cost component (labor/material/equipment/subcon), approved by Commercial Director, locked with the BOQ |
| FR-304 | BOQ items carry cost_rate (internal) and sell_rate (client-facing); sell = Σ component cost × (1+markup); item-level override with reason |
| FR-305 | Expected margin per item = (sell − cost) × qty, rolled up by section and project |
| FR-306 | Cost/margin fields visible to QS Manager+ only; client-facing renderers contain no such fields |

### FR-400 Cost Control (BR-05, BR-06, BR-09, BR-10)

| ID | Requirement |
|---|---|
| FR-401 | Cost transactions: type (invoice/PO/timesheet/delivery/other), category, vendor, dates, qty × unit cost, reference, optional BOQ and WBS links, payment status pending → approved → paid |
| FR-402 | Deletion permitted only at pending; approved/paid reversed by contra entry |
| FR-403 | Budget & variance view: budget, committed, actual, forecast, variance, variance % per item and section, with colour bands (green <5% under, amber at 0, red negative) |
| FR-404 | Variation orders: auto number VO-YYYY-XXXX, type, schedule impact, line items, status draft → submitted → approved/rejected → implemented |
| FR-405 | VO approval routing by value: <$5,000 PM; $5,000–$50,000 PM→QS Manager; ≥$50,000 PM→QS Manager→Commercial Director; chain fixed at submission; rejection requires reason |
| FR-406 | Approved VOs accumulate as net_vo_amount; they never rewrite locked BOQ lines |
| FR-407 | EVM: BAC, PV, EV, AC, CV, SV, CPI, SPI, EAC, VAC, TCPI, EAC%; health green/amber/red at CPI and SPI 0.95 thresholds |
| FR-408 | Time-phased baseline: auto-distribute each BOQ item across months by linked task dates (working days), manual override totalling exactly 100%, approval and lock as Revision 0 |
| FR-409 | Cash flow forecast: cash in from forecast IPC certifications net of retention shifted by client payment terms plus retention releases; cash out by supplier/subcontract payment terms; net monthly position |
| FR-410 | S-curve: planned curve from the approved baseline; actual curve from recorded costs; snapshots timestamped and immutable |

### FR-500 Payment & Retention (BR-07, BR-08)

| ID | Requirement |
|---|---|
| FR-501 | IPC creation initializes claim items from the locked BOQ: scheduled value and previous completed |
| FR-502 | Per item: this period + materials stored; over-claim blocked (cumulative ≤ scheduled value) |
| FR-503 | G702 summary: original contract sum, net VO, contract sum to date, total completed & stored, retention, previous certificates, current payment due |
| FR-504 | Statuses draft → submitted → client_reviewed → certified → paid; only one open claim per project |
| FR-505 | Client adjustments recorded per item with reason; claimed and certified values both retained |
| FR-506 | Certification atomically records certifier and timestamp and creates the retention deduction |
| FR-507 | Retention ledger: deductions (system-created only), release requests with trigger (PC / DLP / other), approval, running balance |
| FR-508 | Release amount cannot exceed outstanding balance; PC release capped at contractual percentage |

### FR-600 Procurement Integration (BR-11)

| ID | Requirement |
|---|---|
| FR-601 | Procurement baseline activation at award: snapshot of budgets, baseline prices, allowable quantities (BOQ qty × composition × (1+wastage%)) |
| FR-602 | PR lines require a budget/BOQ link; optional price-list link enabling checks 2–3 |
| FR-603 | Check 1 budget: line value ≤ remaining (budget − committed − actual − pending); exceed blocks with override path |
| FR-604 | Check 2 quantity: ordered-to-date + requested ≤ allowable; amber ≤105%, red above |
| FR-605 | Check 3 price: variance vs baseline; ≤0% green, 0–5% amber, >5% red requiring QS Manager step and reason |
| FR-606 | RFQ comparison shows a non-removable baseline column; non-lowest selection requires a reason |
| FR-607 | PO approval writes a commitment against the BOQ item, releases the PR pending reservation, and records buy-out gain/(loss) |
| FR-608 | Buy-out report per resource/trade/project with coverage % and unbenchmarked spend |

### FR-700 Subcontract & Contract Admin (BR-12, BR-13)

| ID | Requirement |
|---|---|
| FR-701 | Sub-IPC assessed against the subcontract BOQ; certified value governs; retention mirrored per subcontract terms; back charges deducted before certification |
| FR-702 | Certified sub-IPC creates a subcontract-category cost transaction against project budget |
| FR-703 | Back charges require evidence and formal notice before deduction |
| FR-704 | Employer instructions registered with date, clause reference, cost/time impact, linked VO, status open → responded → closed; time-bar alerts before notice deadlines |

### FR-800 Close-out & Benchmarking (BR-14, BR-15)

| ID | Requirement |
|---|---|
| FR-801 | Final account: pre-checks (no open VOs, provisional items measured, subcontracts final), reconciliation to certified IPCs, client agreement, final certificate |
| FR-802 | Final cost report in two versions: internal (budget, actual cost, sell, final margin vs tender margin) and client (sell side only) |
| FR-803 | WBS node quantities: GFA entered per level with roll-up to building and project; SITE_AREA at project; revision requires reason |
| FR-804 | Benchmarks: building $/m² (incl. prelims and OH&P, excl. VAT/land/fees/FF&E/external works), elemental $/m², basement split and blended, external works ÷ site area |

## 3. Non-Functional Requirements

| ID | Requirement |
|---|---|
| NFR-01 | Budget/EVM screens load < 2s; BOQ of 1,000 items < 1.5s; recalculation of 100 rates / 1,000 BOQ items < 1s |
| NFR-02 | All tables tenant-scoped with row-level security; no cross-tenant read possible |
| NFR-03 | Monetary values stored at 4 decimals, displayed at 2; no rounding of intermediates |
| NFR-04 | Every mutation writes an audit event (module_code QS / QSP) |
| NFR-05 | Client-facing documents generated server-side; automated test proves absence of cost/margin fields |
| NFR-06 | Concurrent editing: last-write-wins with optimistic version check on BOQ and claim items |

## 4. Traceability Summary

BR-01→FR-100; BR-02→FR-200; BR-03/04→FR-300; BR-05/06/09/10→FR-400; BR-07/08→FR-500; BR-11→FR-600; BR-12/13→FR-700; BR-14/15→FR-800; BR-16 deferred to Phase 4.
