# 04 — Database Schema
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-04-DB |
| Version | R1 |
| Platform | PostgreSQL / Supabase |
| Conventions | `uuid` PKs (`gen_random_uuid()`); every table has `tenant_id`, `created_at`, `updated_at`, `created_by`; money `numeric(14,4)`; quantities `numeric(14,6)`; RLS enabled on all tables |

---

## 1. Global Rules

1. **RLS on every table**: `USING (tenant_id = (auth.jwt() ->> 'tid')::uuid)`; project-scoped tables add a project-access predicate. A CI check fails the build if any table lacks RLS.
2. **No hard deletes** on approved commercial records — status transitions and contra entries only.
3. **Snapshot columns** (`baseline_price`, `cost_rate`, `scheduled_value`) are copies, never foreign-key lookups at read time.
4. **Money**: store 4 dp, display 2 dp. Computed totals stored, not derived at query time, for reporting performance.
5. Codes unique within their parent scope (`unique (tender_id, code)`, `unique (project_id, wbs_code)` …).

## 2. Entity Groups

```
G1 Libraries        resource_library_items · rate_library_rates · rate_library_lines
G2 Tender           tenders · price_list_items · unit_rates · unit_rate_lines ·
                    tender_boq_sections · tender_boq_items · prelim_items ·
                    risk_items · sub_quotes · sub_quote_lines ·
                    bid_revisions · bid_summary · snap_* (5 tables)
G3 Baseline         qs_boq_sections · qs_boq_items · qs_project_markups ·
                    qs_budget_revisions · wbs_node_quantities
G4 Cost             qs_cost_transactions · cost_commitments · qs_monthly_budget_baseline ·
                    qs_cashflow_forecasts · evm_snapshots · scurve_snapshots
G5 Commercial       qs_variation_orders · qs_vo_items · qs_vo_approvals ·
                    qs_progress_claims · qs_claim_items · qs_retention_ledger
G6 Procurement link procurement_baselines · baseline_prices · baseline_allowables ·
                    (pr_items / rfq_lines / po_items extended in Procurement module)
G7 Subcontract      subcontracts · subcontract_items · sub_ipcs · sub_ipc_items · back_charges
G8 Contract admin   employer_instructions · contractual_notices · entitlements
```

## 3. Core Tables

### 3.1 `price_list_items` (per tender)

| Column | Type | Notes |
|---|---|---|
| id | uuid PK | |
| tenant_id / tender_id | uuid FK | |
| code | text | unique per tender |
| description | text | |
| category | text | enum material \| labor \| plant \| subcon |
| unit | text | |
| unit_price | numeric(14,4) | check > 0 |
| currency | text | default from tender |
| supplier_name / quote_ref | text | provenance |
| quote_date / valid_until | date | expiry badge when past |
| is_active | boolean | default true |

### 3.2 `unit_rates`

| Column | Type | Notes |
|---|---|---|
| id | uuid PK | |
| tenant_id / tender_id | uuid FK | |
| code / description / trade / unit | text | code unique per tender |
| mode | text | enum flat \| buildup |
| base_rate | numeric(14,4) | flat mode only |
| wastage_pct | numeric(6,3) | flat mode only |
| productivity_factor | numeric(6,3) | > 0, default 1 |
| net_rate | numeric(14,4) | computed, stored |
| library_rate_id | uuid FK null | provenance to rate library |
| is_active | boolean | |

### 3.3 `unit_rate_lines`

| Column | Type | Notes |
|---|---|---|
| id | uuid PK | |
| unit_rate_id | uuid FK | on delete cascade |
| category | text | material \| labor \| plant \| subcon |
| price_list_item_id | uuid FK | **on delete restrict** |
| qty_per_unit | numeric(14,6) | > 0 |
| wastage_pct | numeric(6,3) | material lines only, else 0 |
| line_total | numeric(14,4) | computed, stored |
| sort_order | int | |

### 3.4 `qs_boq_items` (contract baseline)

| Column | Type | Notes |
|---|---|---|
| id | uuid PK | |
| tenant_id / project_id / section_id | uuid FK | |
| item_code / description / unit | text | |
| quantity | numeric(14,6) | |
| cost_rate | numeric(14,4) | internal, snapshot at creation |
| sell_rate | numeric(14,4) | client-facing, frozen at lock |
| markup_pct_override | numeric(6,3) null | with reason |
| expected_margin | numeric(14,4) | (sell − cost) × qty |
| total_amount | numeric(14,4) | qty × sell_rate |
| wbs_node_id | uuid FK null | cost roll-up |
| budget_code | text | inherited from tender |
| is_provisional | boolean | re-measure flag |
| unit_rate_id | uuid FK null | composition provenance |

`qs_boq_sections` carries `status` (draft/approved/locked/revised), `locked_at`, `locked_by`.

### 3.5 `qs_cost_transactions`

`id · tenant_id · project_id · txn_type (invoice|po|timesheet|delivery|other) · cost_category · description · vendor_name · cost_date · invoice_date · quantity · unit_cost · total_cost · reference_no · boq_item_id null · wbs_node_id null · po_id null · grn_ref null · payment_status (pending|approved|paid) · approved_by/at · contra_of_id null`

### 3.6 `qs_variation_orders` / `qs_vo_items` / `qs_vo_approvals`

VO header: `vo_number (VO-YYYY-XXXX, unique per project) · title · vo_type · description · schedule_impact_days · total_amount · status (draft|submitted|approved|rejected|implemented) · submitted_at · approved_at · rejection_reason`.
Items: `description · unit · quantity · rate · amount`.
Approvals: `vo_id · step_no · approver_role · approver_id · decision (pending|approved|rejected) · comment · decided_at` — one row per routed step.

### 3.7 `qs_progress_claims` / `qs_claim_items`

Claim: `claim_no · period_start/end · original_contract_sum · net_vo_amount · contract_sum_to_date · total_completed_stored · retention_pct · retention_amount · previous_certificates · current_payment_due · status (draft|submitted|client_reviewed|certified|paid) · certified_amount · certified_by/at · paid_at`.
Items: `claim_id · boq_item_id · scheduled_value · previous_completed · this_period · materials_stored · total_to_date · pct_complete · client_adjustment · adjustment_reason · certified_amount`.

Constraint: `previous_completed + this_period + materials_stored <= scheduled_value` (over-claim block).

### 3.8 `qs_retention_ledger`

`id · project_id · entry_type (deduction|release) · amount · source_claim_id null · release_trigger (pc|dlp|other) null · expected_release_date · approval_status (pending|approved|rejected) · approved_by/at · notes · running_balance`.
Deductions are inserted only by claim certification (no user insert path).

### 3.9 `qs_monthly_budget_baseline` / `qs_cashflow_forecasts`

Baseline: `project_id · revision_no · boq_item_id · month (date, first of month) · amount · source (auto|manual) · status (draft|approved|locked)`; constraint per item: Σ months = item value.
Cash flow: `project_id · revision_no · month · cash_in_ipc · cash_in_retention · cash_out_supplier · cash_out_subcon · net_position · cumulative`.

### 3.10 `procurement_baselines` (+ children)

Header: `project_id · reference (BL-…) · status (draft|approved|active|superseded) · approved_by/at`.
`baseline_prices`: `baseline_id · price_list_item_id · resource_code · baseline_price`.
`baseline_allowables`: `baseline_id · resource_code · allowable_qty · ordered_to_date` (maintained by PO issue).

Procurement-module extensions: `pr_items` gains `boq_item_id`, `price_list_item_id`, `baseline_price`, `expected_price`, `variance_pct`, `check1/2/3_result`, `override_ref`; `po_items` gains `pr_item_id`, `commitment_id`, `buyout_amount`; `cost_commitments`: `boq_item_id · po_id · amount · status (open|partial|closed) · released_at`.

### 3.11 `wbs_node_quantities`

`id · tenant_id · wbs_node_id FK · metric_code (GFA|GFA_BASEMENT|SITE_AREA|FACADE_AREA) · value numeric · unit · source · is_rollup boolean · revised_reason` — entered at level/project nodes, roll-ups read-only.

## 4. Key Relationships (ERD summary)

```
price_list_items 1─n unit_rate_lines n─1 unit_rates 1─n tender_boq_items
tenders 1─n bid_revisions 1─n snap_* (frozen copies of all tender tables)
projects 1─n qs_boq_sections 1─n qs_boq_items
qs_boq_items 1─n qs_cost_transactions · 1─n cost_commitments · 1─n qs_claim_items
             1─n qs_monthly_budget_baseline
qs_progress_claims 1─n qs_claim_items ; certification 1─1 qs_retention_ledger(deduction)
qs_variation_orders 1─n qs_vo_items · 1─n qs_vo_approvals
procurement_baselines 1─n baseline_prices · 1─n baseline_allowables
subcontracts 1─n subcontract_items · 1─n sub_ipcs 1─n sub_ipc_items
wbs_nodes 1─n wbs_node_quantities
```

## 5. Indexes

`(tenant_id, project_id)` on all project-scoped tables; `(tender_id, code)` unique on price list and unit rates; `(project_id, status)` on claims and VOs; `(boq_item_id)` on cost transactions, commitments, claim items, monthly baseline; `(project_id, month)` on baseline and cash flow; GIN on `changed_fields`-style jsonb where used.

## 6. Migration Sequence

1. Libraries (G1) → 2. Tender (G2) → 3. Baseline + WBS quantities (G3) → 4. Cost (G4) → 5. Commercial (G5) → 6. Procurement link (G6) → 7. Subcontract (G7) → 8. Contract admin (G8). Each migration idempotent and reversible; RLS policies created in the same migration as the table.
