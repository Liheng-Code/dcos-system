# 06 — UI / UX Design
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-06-UI |
| Version | R1 |
| Stack | Next.js 14 + React + Tailwind; enterprise dashboard patterns |

---

## 1. Design Principles

1. **Numbers before decoration.** Commercial users scan for figures — computed values (net rate, variance, payment due) are always visible, never hidden behind a click.
2. **Show the check, then the action.** Every control (budget, over-claim, unit mismatch, variance band) is displayed at the point of entry, not discovered on submit.
3. **Status is always on screen.** Draft / approved / locked / certified drives what is editable; the UI disables rather than fails.
4. **One row, one truth.** Tables show source values and computed values side by side; no hidden arithmetic.
5. **Firewall by construction.** Cost and margin columns are absent — not merely hidden — from client-facing views and exports.
6. **Dense but readable.** Data-heavy tables with sticky headers, right-aligned numerics, thousands separators, 2 dp display.

## 2. Navigation

```
Quantity Surveying
├── Dashboard                 KPI cards, alerts, pending approvals
├── Tender & Estimate
│   ├── Tender Register
│   ├── Cost Estimation       8 tabs (see §4.1)
│   ├── Budget Codes
│   ├── Tender Management · Submissions · Bid Evaluation
├── Cost Control
│   ├── BOQ & Budget          BOQ · Budget & Variance · Cost Transactions ·
│   │                         EVM · S-Curve · Budget Baseline · Portfolio
│   ├── Variation Orders
│   ├── Progress Claims (IPC)
│   ├── Retention
│   └── Final Account
├── Subcon Mgmt               Sub-IPCs · Back Charges · Performance
├── Contract Admin            Instructions · Notices · Entitlements
└── Libraries                 Resource Library · Rate Library
```

Global elements: project selector (persistent, top-left), search, notification bell, breadcrumb with WBS path where applicable.

## 3. Common Components

| Component | Behaviour |
|---|---|
| Status badge | Colour by lifecycle: draft grey, submitted blue, approved green, rejected red, locked navy, certified teal, paid dark green |
| Variance chip | Green ≤0%, amber 0–5%, red >5%; same bands everywhere (budget, price, margin) |
| Computed field | Grey background, read-only, with a tooltip showing the formula |
| Snapshot indicator | Small link icon meaning "value copied at creation — source may have changed" |
| Approval trail | Vertical step list: role, name, decision, timestamp, comment |
| Money input | Right-aligned, currency prefix, 2 dp mask, no spinner |
| Lock banner | Full-width bar on locked/certified records: "Locked — changes require a Variation Order" with the relevant action button |

## 4. Key Screens

### 4.1 Cost Estimation (8 tabs)

| Tab | Layout |
|---|---|
| Bid Summary | Revision cards (one per revision, latest expanded); eight summary tiles (direct, prelims, overhead %, profit %, contingency, risk, VAT, subcon) with the total right-aligned large; "+ New Revision" requires a reason modal |
| Tender BOQ | Section accordion; item rows with rate picker (searchable, shows code/description/unit/net rate); unit mismatch blocked inline; manual-rate rows carry an amber `manual` badge |
| Price List | Table with category filter chips; inline add/edit; expired validity shows an amber date; delete disabled with "in use by N rates — deactivate instead" |
| Preliminaries | Two groups (time-related with monthly rate × duration; fixed) with group subtotals |
| Cover / Tender Summary | Read-only preview of the submission document, generated from the final revision only |
| Unit Rates | List with mode badge and net rate; editor with header fields and, in build-up mode, the composition grid + live summary panel (material / labor ÷ prod / plant ÷ prod / net rate) |
| Sub Quotes | Package accordion; suppliers as columns; normalization notes; one preferred quote radio per package |
| Risk Items | Register with likelihood, impact, priced allowance and a total feeding the bid summary |

### 4.2 BOQ & Budget

Sticky KPI row: Total Budget · Committed · Actual · Forecast bar. Section accordion; columns Budget / Committed / Actual / Forecast / Variance / Var %, colour-coded. Lock action with confirmation modal listing consequences.

### 4.3 Variation Orders

List with number, title, type, value, status, schedule impact. Detail: header, line-item grid, contract sum recap (original + previous VOs + this VO = revised), and the approval trail with the routing chain shown *before* submission so the raiser knows who will approve.

### 4.4 Progress Claims (IPC)

Two-pane: left, the item schedule (scheduled value, previous, this period, materials stored, total, %, balance) with over-claim blocked inline and a progress bar per row; right, the G702 summary as a fixed panel with Current Payment Due emphasised. Certification panel appears only at `client_reviewed`; certified values render alongside claimed with the difference highlighted.

### 4.5 Retention

Three KPI cards (deducted / released / outstanding), ledger table with running balance, "Request Release" modal (trigger, amount capped at outstanding, expected date, certificate reference).

### 4.6 EVM & S-Curve

Health banner (green/amber/red) with CPI and SPI large; twelve metric tiles grouped cost / schedule / forecast; S-curve chart with planned (dashed, from approved baseline) and actual (solid) plus snapshot markers.

### 4.7 PR line baseline panel (procurement-side, QS-owned controls)

Three tiles per line: budget code + remaining budget; quantity vs allowable with %; price vs baseline with variance chip. Red states show the override button with a mandatory reason field.

## 5. Dashboard

| Card | Content |
|---|---|
| Contract position | Original sum, net VOs, contract sum to date |
| Certified to date | Cumulative certified, % of contract, last claim status |
| Budget health | Committed + actual vs budget, forecast variance |
| EVM health | CPI, SPI, EAC with health colour |
| Retention | Outstanding, next release trigger and date |
| Buy-out | Net gain/(loss), coverage % |
| Cost per m² | Building $/m² (basis footnote link) |
| Action inbox | Pending approvals assigned to the user, oldest first |

## 6. Interaction Rules

- Editing a locked record is prevented by disabled inputs plus the lock banner — never by an error toast after typing.
- Bulk actions (approve, export) require selection and show an affected-count confirmation.
- Long tables paginate at 100 rows with server-side sort; BOQ sections lazy-load.
- All destructive or irreversible actions (lock, certify, finalize revision) use a typed-confirmation modal listing what becomes immutable.
- Recalculation feedback: toast "N rates and M items recalculated" plus a transient dot on affected rows.

## 7. Responsive & Accessibility

Desktop-first (commercial work is desk work); tablet supported for dashboards and approvals; mobile limited to approval actions and dashboard read. WCAG AA contrast; colour never the sole signal (variance chips carry sign and value); full keyboard navigation on data grids; numeric columns announced with units.

## 8. Wireframe References

Detailed mockups: Unit Rates list and build-up editor; PR baseline panel; IPC two-pane; bid summary revision cards. Reference `FS-QS-001` §5 and the module mockup set.
