# 11 — Standard Operating Procedures (SOP)
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-11-SOP |
| Version | R1 |
| Controlled issues | SOP-QS-001 R3 (QS module, 41 pp) · SOP-QSP-001 R1 (Cost Control → Procurement, 16 pp) · DCOS-QS-GDL-001 V1.1 (GFA & cost/m²) |
| Purpose | Operating index: what each procedure controls, its status flow, gates, and where the signed issue lives |

---

## 1. Procedure Register

| SOP | Procedure | Owner | Status flow |
|---|---|---|---|
| QS-01 | Cost library management | QS Manager | active ⇄ deactivated (no delete once referenced) |
| QS-02 | Tender BOQ creation | Estimator | draft → final → submitted |
| QS-03 | Tender management | Commercial Manager | draft → published → evaluation → awarded/cancelled |
| QS-04 | Bid evaluation | Commercial Manager | submission → responsiveness → scoring → shortlist → award |
| QS-05 | BOQ creation & baseline | QS Manager | draft → approved → locked → revised |
| QS-05A | Rate build-up & margin | QS Manager / Director | draft → approved → locked with BOQ |
| QS-06 | Budget & variance monitoring | QS Manager | continuous control loop |
| QS-07 | Cost transaction recording | QS Engineer / Finance | pending → approved → paid |
| QS-08 | Variation orders | QS Engineer → approvers | draft → submitted → approved/rejected → implemented |
| QS-09 | EVM monitoring | Commercial Manager | monthly cycle |
| QS-10 | Cost S-curve | QS Manager | snapshot cycle |
| QS-10A | Time-phased baseline & cash flow | QS Manager / Finance | generated → adjusted → approved → locked (Rev 0) |
| QS-11 | Interim payment certificate | QS Engineer / Client QS | draft → submitted → client_reviewed → certified → paid |
| QS-12 | Retention management | QS Manager / Director | deduction (auto) · release: pending → approved/rejected |
| QS-13 | Portfolio dashboard | Commercial Director | executive cycle |
| QS-14 | Final account | QS Manager | pre-checks → draft → agreed → final certificate |
| QS-14A | Final QS cost report | QS Manager / Director | draft → approved → client version issued → signed |
| QS-15 | Subcontractor IPC | QS Engineer | draft → submitted → certified → paid |
| QS-16 | Back charges | QS Engineer / Site | raised → notified → agreed → deducted → closed |
| QS-17 | Employer instructions | Contract Administrator | open → responded → closed |
| QSP-01 | Procurement baseline activation | QS Manager / Commercial Manager | draft → approved → active |
| QSP-02 | PR with baseline checks | Requester → approvers | draft → submitted → checks → approved/rejected |
| QSP-03 | RFQ & quotation comparison | Procurement Officer | draft → issued → quotes → comparison → selection |
| QSP-04 | Purchase order & commitment | Procurement Manager | draft → approved → issued → delivered → invoiced → closed |
| QSP-05 | Delivery, matching, committed→actual | Store / Finance | GRN → three-way match → actual |
| QSP-06 | Buy-out reporting | QS Manager / Commercial Manager | monthly cycle |

## 2. Golden Rules (apply to every procedure)

1. The locked BOQ is the contract baseline; only an approved VO changes it.
2. Approved VOs accumulate on top of the baseline; they never rewrite locked lines.
3. Certified IPCs create retention deductions automatically — never manually.
4. Cost records may be deleted only at `pending`; approved/paid are reversed by contra entry.
5. Every approval and rejection records identity, timestamp, and (on rejection) a reason.
6. Dual-rate firewall: client-facing output shows sell rates only.
7. Planned Value and the planned S-curve come only from the approved time-phased baseline.
8. The procurement baseline is read-only to procurement; blocks always have a controlled override that leaves evidence.

## 3. Daily Operating Rhythm

| Frequency | Activity | Procedure |
|---|---|---|
| Daily | Record invoices, deliveries, timesheets as cost transactions | QS-07 |
| Daily | Review PR queue and check flags | QSP-02 |
| Weekly | Budget & variance review; investigate red items | QS-06 |
| Weekly | VO register review — nothing sitting unsubmitted | QS-08 |
| Weekly | EI register — time-bar watch | QS-17 |
| Monthly | Prepare, submit, and certify the IPC | QS-11 |
| Monthly | S-curve snapshot; EVM refresh and review | QS-09, QS-10 |
| Monthly | Buy-out and override register review | QSP-06 |
| Monthly | Baseline vs actual; re-baseline only by revision | QS-10A |
| Quarterly | Rate library refresh from won tenders and actual costs | QS-01 |
| At milestones | Retention release at PC and DLP | QS-12 |
| At close | Final account and two-version cost report | QS-14, QS-14A |

## 4. Month-End Sequence (the critical path)

```
Day 1-2   cut off cost transactions; confirm deliveries and timesheets posted
Day 2-3   measure completed work; update task progress for EV
Day 3-4   prepare IPC items; check over-claim; add approved VOs
Day 4     internal review (QS Manager) → submit IPC to client
Day 5     capture S-curve snapshot; refresh EVM; run buy-out report
Day 5-7   client review and certification → retention entry auto-created
Day 7     management review: variance, EVM health, cash flow, overrides
```

Rule: the IPC is submitted on the contractual date regardless of internal delays — a late claim is a cash-flow loss that no later correction recovers.

## 5. Escalation Matrix

| Trigger | Escalate to | Timing |
|---|---|---|
| Item variance red (over budget) | QS Manager | Same review cycle |
| Section over-run > 5% | Commercial Manager | Immediately |
| Forecast EAC > BAC | Commercial Director + recovery plan | Immediately |
| CPI or SPI < 0.85 | Commercial Director | Monthly review |
| IPC not certified within contract period | PM → Commercial Manager | On expiry of the period |
| Retention release overdue | Contract Administrator (notice) | 14 days after expected date |
| PR red-route pattern (repeat overrides) | Commercial Manager | Monthly buy-out review |
| EI time bar within 5 days | PM + Contract Administrator | Immediately |

## 6. Records & Retention

| Record | Retain |
|---|---|
| Tender submissions (won and lost) | 5 years |
| Contract BOQ, variations, IPCs, certificates | Contract + DLP + 7 years |
| Retention ledger and releases | Contract + 10 years |
| Cost transactions and commitments | 7 years |
| Audit events (financial) | 7–10 years, append-only |

## 7. Controlled Document References

Full procedural detail — including workflow control blocks (status flow, control gates, entry/exit criteria, exception handling) for every procedure above — is issued in:

- **SOP-QS-001 R3** — QS module procedures QS-01 … QS-17
- **SOP-QSP-001 R1** — procurement integration procedures QSP-01 … QSP-06
- **DCOS-QS-GDL-001 V1.1** — GFA, site area, cost/m² conventions and the mandatory basis footnote
- **DCOS-QS-RPT-001** — report and certificate templates (RPT-QS-01 … 08)

This index is updated whenever a controlled SOP is revised; the signed issue always governs over this summary.
