# 09 — Test Plan
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-09-TEST |
| Version | R1 |
| Standard | ISO/IEC/IEEE 29119 |
| Scope | Functional, integration, security, performance, and UAT for the QS module |

---

## 1. Objectives & Approach

Prove that every commercial calculation is exact, every control gate is enforceable, and no client-facing output leaks internal cost. Financial correctness is tested with **fixed expected values** — not tolerances — so a failure is unambiguous.

Levels: unit (formulas), integration (module-to-module), system (end-to-end lifecycle), security (RBAC/RLS/firewall), performance (NFR-01), UAT (QS staff on real project data).

## 2. Test Data Baseline

Seeded from FS-QS-001 mock templates (ARC/STR/MEP) plus the Cambodia price lists:

```
Price list  : PL-CEM-01 4.20/bag · PL-SND-01 12.00/m3 · PL-AGG-01 14.00/m3
              PL-LAB-03 22.00/h · PL-PLT-02 15.00/h
Unit rate   : UR-CON-001 (m3) = 7.0 cem@5% + 0.45 sand@5% + 0.90 agg@5%
                                + 0.80 labor + 0.30 plant, productivity 1.0
BOQ         : 10 items across STR/ARC/MEP, Direct 262,072.00 / Subcon 18,500.00
Contract    : original sum 280,572.00 · net VOs 12,400.00 · retention 5%
```

## 3. Functional Test Cases

### 3.1 Rate engine

| ID | Test | Expected |
|---|---|---|
| TC-101 | Build-up computation UR-CON-001 | material 49.77, labor 17.60, plant 4.50, **net 71.87** |
| TC-102 | Flat mode: base 14.50, wastage 7%, productivity 0.85 | **18.25** |
| TC-103 | Productivity applies to labor+plant only, wastage to material lines only | Material subtotal unchanged when productivity varies |
| TC-104 | Rounding: store 4 dp, display 2 dp, no intermediate rounding | Totals match manual calculation to the cent |
| TC-105 | Referenced price-list item delete | Blocked; deactivate succeeds; existing lines still compute |

### 3.2 BOQ linking & recalculation

| ID | Test | Expected |
|---|---|---|
| TC-201 | Link UR-CON-001 to 500 m³ item | rate 71.87, **amount 35,935.00** |
| TC-202 | Unit mismatch (m³ rate → m² item) | Rejected, `UNIT_MISMATCH` |
| TC-203 | Cement 4.20 → 4.60 (draft revision) | UR-CON-001 **74.81**, UR-BLK-001 **14.10**, UR-PLA-001 **4.83**; concrete amount **37,405.00**; MEP rates unchanged |
| TC-204 | Manual-rate row excluded from recalculation | Value unchanged, `manual` flag present |
| TC-205 | Recalculation transactional | Forced failure mid-cascade leaves no partial update |

### 3.3 Revision & freeze

| ID | Test | Expected |
|---|---|---|
| TC-301 | Edit inputs while revision draft | Allowed, no new revision created |
| TC-302 | Edit after finalize | Blocked `REVISION_FINAL` |
| TC-303 | New revision without reason | Rejected |
| TC-304 | Finalize snapshot completeness | snap_* tables hold price list, rates, lines, BOQ, prelims, risk at that instant |
| TC-305 | Later edits do not alter a snapshot | Revision 1 values unchanged after Revision 2 edits |

### 3.4 Baseline & margin

| ID | Test | Expected |
|---|---|---|
| TC-401 | Lock BOQ then edit an item | Blocked at API and UI |
| TC-402 | Sell rate from markups (labor 18%, material 8%, equipment 12% on 85.00 cost, 30/60/10 split) | **94.69**, expected margin (94.69−85.00)×qty |
| TC-403 | Negative margin item | Requires Commercial Director approval + reason |
| TC-404 | Post-lock change without VO | Rejected; with approved VO/budget revision, accepted and logged |

### 3.5 Variations

| ID | Test | Expected |
|---|---|---|
| TC-501 | VO 3,200 submitted | Chain = PM only |
| TC-502 | VO 25,000 | PM → QS Manager, sequential |
| TC-503 | VO 80,000 | PM → QS Manager → Commercial Director |
| TC-504 | Reject without reason | Blocked; with reason → status rejected, returns to draft |
| TC-505 | Line items edited after submission | VO returns to draft; chain recomputed at resubmission |
| TC-506 | Raiser attempts approval | `SEGREGATION_VIOLATION` |

### 3.6 IPC & retention

| ID | Test | Expected |
|---|---|---|
| TC-601 | Initialize claim 3 from locked BOQ | Scheduled values = BOQ totals; previous = sum of certified claims 1–2 |
| TC-602 | Over-claim (cumulative > scheduled) | Blocked `OVER_CLAIM` |
| TC-603 | G702 chain with test data (work to date 146,486.00, previous 98,500.00) | contract sum to date **292,972.00**, retention **7,324.30**, **current payment due 40,661.70**, balance to finish **153,810.30** |
| TC-604 | Certify | certified_by/at recorded; retention deduction 7,324.30 auto-created; status certified |
| TC-605 | Two open claims | Second creation blocked |
| TC-606 | Client adjustment | Claimed and certified both retained with reason |
| TC-607 | Manual retention deduction attempt | No API path; rejected |
| TC-608 | Release > outstanding | Blocked; PC release capped at contractual % |

### 3.7 Time-phased baseline & EVM

| ID | Test | Expected |
|---|---|---|
| TC-701 | Auto-distribute a 12-month item | Months sum exactly to item value; working-day weighting applied |
| TC-702 | Manual override summing to 95% | Rejected |
| TC-703 | Approved baseline locked | Rev 0 immutable; changes create Rev 1 with reason, comparison retained |
| TC-704 | EVM metrics | CPI = EV/AC, SPI = EV/PV, EAC = BAC/CPI computed to 4 dp; health colour matches 0.95 thresholds |
| TC-705 | PV source | PV reads only the approved baseline, never manual snapshots |

### 3.8 Procurement integration

| ID | Test | Expected |
|---|---|---|
| TC-801 | Allowable quantity for cement (500 m³ × 7.0 × 1.05) | **3,675 bags** |
| TC-802 | PR line 400 bags @ 4.35, ordered 3,180, remaining budget 6,120 | check1 pass, check2 pass (**97.4%**), check3 **amber +3.6%** |
| TC-803 | PR exceeding remaining budget | Blocked with override path; override requires reason and QS Manager |
| TC-804 | Price variance +8% | Red; QS Manager step inserted; approval impossible without it |
| TC-805 | PO approval | Commitment written, pending released, buy-out recorded — one transaction; rollback on failure leaves no PO |
| TC-806 | PO qty > approved PR | Blocked |
| TC-807 | Buy-out report | Cement (551.25) loss, rebar 1,800.00 gain, **net +1,248.75** |
| TC-808 | Invoice match → committed becomes actual | Budget & variance columns move correctly, no double count |

### 3.9 Benchmarks & reports

| ID | Test | Expected |
|---|---|---|
| TC-901 | GFA roll-up: 10×850 + 60 roof rooms, deck excluded | above ground **8,560 m²** |
| TC-902 | With 850 m² basement | total **9,410**, above-ground $/m² **420.00**, basement **850.00**, blended **458.84** |
| TC-903 | Prelims apportionment | above **416.52**, basement **885.09**, blended unchanged |
| TC-904 | External works ÷ site area | **40.00**; excluded from building benchmark |
| TC-905 | RPT-QS-01 generation | Nine G702 lines match TC-603; amount in words correct |
| TC-906 | Continuation sheet totals | Equal certificate lines 4–5 exactly |

## 4. Security Test Cases

| ID | Test | Expected |
|---|---|---|
| TC-RBAC-01 | Cross-tenant read of any QS table | Zero rows (RLS) |
| TC-RBAC-02 | QS Engineer requests `cost_rate` | `FORBIDDEN_FIELD` |
| TC-RBAC-03 | Client user fetches untransmitted claim | 404/forbidden |
| TC-RBAC-04 | Client-facing export field scan | No cost_rate, markup, margin, buy-out fields present |
| TC-RBAC-05 | PR requester approves own override | Blocked |
| TC-RBAC-06 | Tenant id supplied in body | Ignored; JWT tenant used |
| TC-RBAC-07 | New table without RLS policy | CI build fails |

## 5. Performance Test Cases

| ID | Test | Target |
|---|---|---|
| TC-PERF-01 | BOQ 1,000 items load | < 1.5 s |
| TC-PERF-02 | Budget & variance with 5,000 transactions | < 2 s |
| TC-PERF-03 | Recalculation 100 rates / 1,000 items | < 1 s |
| TC-PERF-04 | Claim initialization 1,000 items | < 3 s |
| TC-PERF-05 | 50 concurrent users on one project | No deadlock; version conflicts surfaced cleanly |

## 6. UAT Scenarios (QS staff, real data)

1. Price a small tender end-to-end and produce a submission pack.
2. Award it, lock the baseline, and activate the procurement baseline.
3. Run one month: raise PRs, issue POs, record costs, raise and approve a VO.
4. Produce, submit, and certify IPC #1; verify retention.
5. Review EVM, S-curve, cash flow, and buy-out at month end.
6. Produce the client BOQ export and confirm no internal figures appear.

Acceptance: each scenario completed by the intended role without developer assistance, with figures matching a parallel manual calculation.

## 7. Entry & Exit Criteria

**Entry:** feature deployed to test with seed data loaded; migrations applied; RLS active.
**Exit:** 100% of functional and security cases pass; performance targets met; zero open critical/high defects; UAT signed by QS Manager and Commercial Director.

## 8. Defect Severity

| Severity | Definition | Example |
|---|---|---|
| Critical | Wrong money, data leak, or lost record | Retention miscalculated; cross-tenant read |
| High | Control bypassable or workflow blocked | Locked BOQ editable; VO chain skippable |
| Medium | Incorrect display or usability blocker | Variance colour wrong band |
| Low | Cosmetic | Column alignment |

## 9. Traceability

TC-1xx→FR-200; TC-2xx→FR-205/213; TC-3xx→FR-211; TC-4xx→FR-300; TC-5xx→FR-404/405; TC-6xx→FR-500; TC-7xx→FR-407/408; TC-8xx→FR-600; TC-9xx→FR-800/804; TC-RBAC→doc 07; TC-PERF→NFR-01.
