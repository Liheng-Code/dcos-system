# 08 — API Reference
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-08-API |
| Version | R1 |
| Standard | OpenAPI 3.1 conventions |
| Base | `/api/v1` — all endpoints require `Authorization: Bearer <DCOS access token>` |

---

## 1. Conventions

- Tenant is taken from the JWT (`tid`) — **never** from the request body; a body-supplied tenant is rejected.
- Money in responses: string-safe `numeric` at 4 dp; clients format to 2 dp.
- Pagination: `?page=1&page_size=100`; responses carry `meta.total`, `meta.page`.
- Filtering: `?project_id=&status=&from=&to=`; sorting `?sort=-created_at`.
- Idempotency: state-changing POSTs accept `Idempotency-Key`.
- Errors: `{ "error": { "code": "BOQ_LOCKED", "message": "...", "details": {...} } }`.
- Every mutation writes an audit event; responses include `audit_id` where material.

**Standard error codes:** `VALIDATION_FAILED` · `BOQ_LOCKED` · `REVISION_FINAL` · `OVER_CLAIM` · `UNIT_MISMATCH` · `BUDGET_EXCEEDED` · `ALLOWABLE_EXCEEDED` · `PRICE_VARIANCE_RED` · `APPROVAL_REQUIRED` · `SEGREGATION_VIOLATION` · `FORBIDDEN_FIELD` · `NOT_FOUND` · `CONFLICT_VERSION`.

## 2. Libraries

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/libraries/resources` | List / create company resources |
| PATCH/DELETE | `/libraries/resources/{id}` | Update / deactivate (delete blocked when referenced) |
| GET/POST | `/libraries/rates` | Rate compositions (recipes, no prices) |
| POST | `/libraries/rates/{id}/copy-to-tender` | Copy composition into a tender and re-link by resource code → returns unmatched lines |

## 3. Tender & Estimation

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/tenders/{tenderId}/price-list` | Price list items |
| PATCH/DELETE | `/tenders/{tenderId}/price-list/{id}` | Update / deactivate |
| POST | `/tenders/{tenderId}/price-list/{id}/recalc` | Cascade recalculation → `{ rates_affected, boq_items_affected }` |
| GET/POST | `/tenders/{tenderId}/unit-rates` | Unit rates (flat or build-up) |
| PATCH | `/tenders/{tenderId}/unit-rates/{id}` | Update header |
| PUT | `/tenders/{tenderId}/unit-rates/{id}/lines` | Batch upsert composition lines → recomputes `net_rate` |
| GET/POST | `/tenders/{tenderId}/boq-items` | Tender BOQ |
| PATCH | `/tenders/{tenderId}/boq-items/{id}/link-rate` | `{ unit_rate_id }` or `{ manual_rate }` — validates unit match |
| GET/POST | `/tenders/{tenderId}/prelims` · `/risk-items` · `/sub-quotes` | Estimation inputs |
| GET/POST | `/tenders/{tenderId}/bid-revisions` | List / create revision (`{ reason }` required) |
| POST | `/tenders/{tenderId}/bid-revisions/{id}/finalize` | Freeze inputs + snapshot all tender tables |
| GET | `/tenders/{tenderId}/bid-revisions/{id}/summary` | Bid summary chain and total |

**Example — build-up rate response**

```json
{ "id": "…", "code": "UR-CON-001", "unit": "m3", "mode": "buildup",
  "productivity_factor": 1.0,
  "lines": [
    { "category": "material", "price_list_item_id": "…", "qty_per_unit": 7.0,
      "wastage_pct": 5, "line_total": "30.8700" }
  ],
  "subtotals": { "material": "49.7700", "labor": "17.6000", "plant": "4.5000" },
  "net_rate": "71.8700" }
```

## 4. Contract Baseline

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/projects/{id}/boq/sections` · `/boq/items` | Contract BOQ |
| POST | `/projects/{id}/boq/approve` | draft → approved |
| POST | `/projects/{id}/boq/lock` | approved → locked (one-way) |
| POST | `/projects/{id}/boq/revisions` | Post-lock budget revision `{ reason }` (Director) |
| GET/PUT | `/projects/{id}/markups` | Markup settings |
| POST | `/projects/{id}/markups/approve` | Commercial Director approval |
| GET | `/projects/{id}/boq/export?audience=client` | Sell-side export (no cost/margin fields) |

## 5. Cost Control

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/projects/{id}/cost-transactions` | Record costs |
| PATCH | `/cost-transactions/{id}/status` | pending → approved → paid |
| POST | `/cost-transactions/{id}/contra` | Reversal entry `{ reason }` |
| GET | `/projects/{id}/budget-variance` | Budget/committed/actual/forecast per item and section |
| GET/POST | `/projects/{id}/variation-orders` | VO register |
| POST | `/variation-orders/{id}/submit` | Computes and fixes the approval chain |
| POST | `/variation-orders/{id}/approve` · `/reject` | Step decision (`reason` mandatory on reject) |
| POST | `/variation-orders/{id}/implement` | approved → implemented |
| GET | `/projects/{id}/evm?as_of=` | Twelve metrics + health |
| GET/POST | `/projects/{id}/scurve-snapshots` | Capture / list snapshots |
| GET/POST | `/projects/{id}/budget-baseline` | Monthly distribution |
| POST | `/projects/{id}/budget-baseline/generate` | Auto-distribute from schedule |
| POST | `/projects/{id}/budget-baseline/approve` | Lock Revision n |
| GET | `/projects/{id}/cashflow-forecast` | Monthly cash in/out/net |

## 6. Payment & Retention

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/projects/{id}/claims` | IPC list / create |
| POST | `/claims/{id}/initialize-items` | Populate from locked BOQ |
| PUT | `/claims/{id}/items` | Batch update this-period / materials-stored (over-claim validated) |
| POST | `/claims/{id}/submit` · `/review` · `/certify` · `/pay` | Lifecycle transitions |
| GET | `/claims/{id}/g702` | Summary payload for RPT-QS-01 |
| GET | `/projects/{id}/retention` | Ledger + balances |
| POST | `/projects/{id}/retention/release-request` | `{ trigger, amount, expected_date, notes }` |
| POST | `/retention/{id}/approve` · `/reject` | Release decision |

**Example — certify response**

```json
{ "claim_id": "…", "status": "certified", "certified_amount": "40661.7000",
  "certified_by": "usr_…", "certified_at": "2026-07-31T09:12:00Z",
  "retention_entry_id": "…", "retention_deducted": "7324.3000" }
```

## 7. Procurement Integration

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/projects/{id}/procurement-baseline/activate` | Snapshot budgets, prices, allowables |
| GET | `/projects/{id}/procurement-baseline` | Baseline reference + registers |
| POST | `/pr-items/{id}/check` | Run checks 1–3 → `{ check1, check2, check3, routing }` |
| POST | `/pr-items/{id}/override` | Red-route request `{ reason }` |
| POST | `/po/{id}/commit` | Called at PO approval — writes commitment, releases pending, records buy-out (atomic) |
| POST | `/commitments/{id}/release` | On cancellation or closure |
| GET | `/projects/{id}/buyout-report` | Gain/loss, coverage, unbenchmarked spend |

**Example — check response**

```json
{ "check1_budget": { "result": "pass", "remaining": "6120.0000" },
  "check2_quantity": { "result": "pass", "ordered_to_date": 3180,
                       "requested": 400, "allowable": 3675, "pct": 97.4 },
  "check3_price": { "result": "amber", "baseline": "4.2000",
                    "expected": "4.3500", "variance_pct": 3.6 },
  "routing": ["PROCUREMENT_MANAGER"] }
```

## 8. Subcontract & Contract Admin

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/projects/{id}/subcontracts` · `/sub-ipcs` | Subcontract commercial |
| POST | `/sub-ipcs/{id}/certify` | Assessed value + retention + back charges |
| GET/POST | `/projects/{id}/back-charges` | Raise, notify, agree |
| GET/POST | `/projects/{id}/instructions` | Employer instructions |
| POST | `/instructions/{id}/respond` · `/close` | Lifecycle |
| GET | `/projects/{id}/entitlements` | Entitlement register with time-bar status |

## 9. Close-out, Benchmarks & Reports

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/projects/{id}/final-account` | Draft, reconcile, agree |
| GET | `/projects/{id}/final-cost-report?audience=internal\|client` | Two-version report (client audience omits cost/margin fields entirely) |
| GET/PUT | `/wbs-nodes/{id}/quantities` | GFA / SITE_AREA metrics |
| GET | `/projects/{id}/benchmarks` | Building $/m², elemental, basement split, external ÷ site |
| POST | `/reports/{templateId}/generate` | Server-side PDF (RPT-QS-01…08) → returns file id + audit id |
| GET | `/portfolio/commercial` | Cross-project KPIs (CD/CFO scope) |

## 10. Webhooks (outbound)

`qs.boq.locked` · `qs.vo.approved` · `qs.claim.certified` · `qs.retention.released` · `qsp.commitment.created` · `qs.budget.threshold_breached`. Signed payloads, at-least-once delivery, consumer idempotency required.

## 11. Rate Limits & Versioning

200 requests/min/tenant default (configurable per tier); recalculation endpoints 20/min/project. Version in path (`/v1`); breaking changes ship as `/v2` with a minimum six-month overlap.
