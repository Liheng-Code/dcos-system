# 05 — Integration Specification
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-05-INT |
| Version | R1 |
| Related | SOP-QSP-001 (Cost Control → Procurement), DCOS Architecture R0 §24 (platform engines) |

---

## 1. Integration Map

```
                    ┌──────────────┐
  Project Setup ───▶│              │◀─── WBS Engine (nodes, GFA metrics)
  Planning ────────▶│      QS      │◀─── HR (labour cost, timesheets)
  Procurement ◀────▶│    Module    │───▶ Finance (payment triggers)
  Subcontract ◀────▶│              │───▶ Reporting / Executive dashboard
                    └──────┬───────┘
                           │ consumes platform engines
        Approval · Notification · Audit · RBAC · Document Control
```

## 2. Internal Module Interfaces

### INT-01 QS ↔ WBS Engine

| Direction | Data | Rule |
|---|---|---|
| WBS → QS | Node ids, hierarchy, node type | BOQ items and cost transactions link to nodes for roll-up |
| QS → WBS | Cost and budget per node | Roll-up upward only; parents read-only |
| WBS → QS | `wbs_node_quantities` (GFA, SITE_AREA) | Denominators for $/m² benchmarks; entered at level/project nodes |

Rule: a WBS node with linked BOQ items or costs cannot be deleted (restrict); archive only.

### INT-02 QS ↔ Planning & Scheduling

| Direction | Data | Rule |
|---|---|---|
| Planning → QS | Task planned start/finish, % complete | Drives time-phased baseline distribution and EVM Earned Value |
| QS → Planning | BOQ item value per task | Enables resource/cost-loaded programme |

Rule: schedule re-baseline creates a **new** monthly baseline revision; Revision 0 is never edited.

### INT-03 QS ↔ Procurement (fully specified in SOP-QSP-001)

| Direction | Data | Trigger |
|---|---|---|
| QS → Procurement | Baseline: budget per BOQ item, baseline price per resource, allowable quantity | Baseline activation at award |
| Procurement → QS | PR pending value | PR submission (soft budget reservation) |
| Procurement → QS | Commitment (PO value per BOQ item) | PO approval — atomic with pending release and buy-out record |
| Procurement → QS | GRN + invoice match → actual cost | Invoice recording (committed → actual) |
| QS → Procurement | Check results 1–3 per PR line, override outcomes | Live at PR entry and re-run at PO price |

Failure rule: if the commitment write fails, PO approval rolls back — no PO exists without its commitment.

### INT-04 QS ↔ Subcontract Management

| Direction | Data |
|---|---|
| Subcontract → QS | Subcontract BOQ/schedule of rates, retention %, payment terms |
| QS → Subcontract | Assessed sub-IPC values, back-charge deductions |
| Subcontract → QS | Certified sub-IPC → subcontract-category cost transaction against project budget |
| Subcontract → Auth | Contract end date drives external user access expiry (Auth module D8) |

### INT-05 QS ↔ HR

| Direction | Data | Rule |
|---|---|---|
| HR → QS | Approved timesheets: hours × rate per project/WBS/task | Creates labour cost transactions (category labor) |
| QS → HR | Labour cost per WBS for productivity reporting | Read-only |

Rule: only approved-and-locked timesheets post to cost; corrections come as new periods, not edits.

### INT-06 QS ↔ Finance

| Direction | Data | Rule |
|---|---|---|
| QS → Finance | Certified IPC → receivable; approved payment request → payable | Certification and payment approval are the only triggers |
| Finance → QS | Payment received/made dates and amounts | Moves claim to `paid`, transaction to `paid` |
| QS → Finance | Retention balances (receivable and payable) | Monthly reconciliation |

Boundary: QS never writes journal entries; Finance never edits certified values.

### INT-07 QS ↔ Reporting / Executive Dashboard

QS publishes: contract sum to date, certified to date, budget vs committed vs actual, CPI/SPI/EAC, net buy-out, retention outstanding, cost per m². All read-only aggregates; the executive dashboard performs no QS calculations of its own.

## 3. Platform Engine Interfaces

| Engine | QS usage |
|---|---|
| Approval Workflow | VO routing by threshold; IPC certification; retention release; PR override (red route); baseline and markup approval. QS supplies step definitions; the engine executes and records. |
| Notification | Events listed in §4; QS supplies template codes and recipient strategies; anti-spam and digest rules belong to the engine. |
| Audit Trail | Every QS mutation writes `module_code` = `QS` or `QSP` with action, entity, old/new values. Append-only; 7-year retention for financial events. |
| RBAC | Permission matrix in doc 07; QS enforces field-level visibility for cost/margin (QS Manager+) on top of record-level permissions. |
| Document Control | All client-facing QS documents (IPC, BOQ export, VO, final statement) leave the system only via transmittal, with revision link recorded. |

## 4. Event Catalogue (QS → Notification Engine)

| Event code | Recipients | Priority |
|---|---|---|
| `QS.BOQ_LOCKED` | PM, Commercial Manager, Procurement Manager | Normal |
| `QS.VO_SUBMITTED` | Current approver | High |
| `QS.VO_APPROVED` / `QS.VO_REJECTED` | Originator, PM, (Procurement if scope) | High |
| `QS.IPC_SUBMITTED` | Client QS, PM | High |
| `QS.IPC_CERTIFIED` | QS Manager, Finance, PM | High |
| `QS.IPC_OVERDUE_CERTIFICATION` | PM, Commercial Manager | Critical |
| `QS.RETENTION_RELEASE_DUE` | QS Manager, Finance | Normal |
| `QS.BUDGET_THRESHOLD_BREACH` | PM, QS Manager, Commercial Director | Critical |
| `QSP.PR_CHECK_RED` | QS Manager, Procurement Manager | High |
| `QSP.COMMITMENT_STALE` (>60 days) | Procurement Manager, QS Manager | Normal |
| `QS.EI_TIME_BAR_APPROACHING` | Contract Administrator, PM | Critical |

## 5. External Integrations (Phase 4+)

| Target | Scope | Priority |
|---|---|---|
| Accounting/ERP (QuickBooks, Xero, SAP) | Push certified receivables, approved payables, cost actuals | High |
| Excel | BOQ import/export, claim schedules, rate library exchange | High (FS-QS-005) |
| BIM / IFC | Quantity take-off import into tender and contract BOQ | Medium |
| Client e-billing portals | IPC submission where the client mandates a portal | Low, project-specific |
| Bank / FX feed | Exchange rates for multi-currency (BR-16) | Deferred |

Integration principles: all external calls through the platform Integration Layer with service accounts (scoped, expiring); idempotency keys on every push; failures logged as integration events and retried; no direct database access from external systems.

## 6. Data Ownership Rules

| Data | Owner | Others |
|---|---|---|
| BOQ baseline, rates, margins | QS | read-only |
| Cost transactions | QS (record) / Finance (payment status) | — |
| PR/RFQ/PO documents | Procurement | QS supplies checks, reads commitments |
| Timesheets | HR | QS reads approved values |
| WBS structure | Project/WBS module | QS links only |
| Client and supplier master | Stakeholder module | QS references |

## 7. Failure & Consistency Rules

Commitment, buy-out, and pending-release writes are one transaction with PO approval. Retention deduction is one transaction with IPC certification. If a downstream engine (notification, integration) fails, the commercial transaction still commits and the failure is logged and retried — commercial integrity never depends on message delivery.
