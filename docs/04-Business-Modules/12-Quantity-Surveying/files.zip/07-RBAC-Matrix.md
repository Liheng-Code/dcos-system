# 07 — RBAC Matrix
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-07-RBAC |
| Version | R1 |
| Depends on | Module 03-02 RBAC (platform); Auth module supplies verified identity, tenant, project scope |
| Closes | GAP-01 (RBAC not enforced on QS components), GAP-02 (VO approval not role-wired) |

---

## 1. Principles

1. **Permission = role permission ∩ project access ∩ discipline/WBS scope ∩ workflow responsibility.** A QS Manager on Project A has no rights on Project B.
2. **Field-level firewall.** Cost rate, markup %, expected margin, and internal cost reports are restricted to QS Manager and above regardless of record-level access. Enforced server-side; client-facing renderers omit the fields entirely.
3. **Approval rights are never inherited from edit rights.** Being able to raise a VO does not confer approval.
4. **External parties see only what a transmittal issued to them.**
5. Every permission decision on a sensitive action is audit-logged.

## 2. Roles

| Code | Role | Scope |
|---|---|---|
| SA | Super Admin | Platform |
| CA | Company Admin | Tenant |
| CD | Commercial Director | Tenant, all projects |
| QSM | QS Manager | Assigned projects |
| QSE | QS Engineer | Assigned projects |
| EST | Estimator | Assigned tenders |
| PM | Project Manager | Assigned projects |
| PROC | Procurement Officer / Manager | Assigned projects |
| FIN | Finance Officer | Tenant financial data |
| SITE | Site Engineer / Storekeeper (requester) | Assigned project/WBS |
| SUB | Subcontractor (external) | Own subcontract only |
| CLI | Client / Consultant QS (external) | Own project, transmitted items |
| VIEW | Viewer | Read-only, assigned projects |

## 3. Permission Matrix

Legend: **C** create · **R** read · **U** update · **D** delete · **A** approve · **X** export · **—** none

| Object | SA/CA | CD | QSM | QSE | EST | PM | PROC | FIN | SITE | SUB | CLI | VIEW |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Resource / Rate Library | CRUDX | RX | CRUDX | R | R | R | R | — | — | — | — | R |
| Tender price list | CRUDX | RX | CRUDX | RU | CRUD | R | R | — | — | — | — | — |
| Unit rates | CRUDX | RX | CRUDX | RU | CRUD | R | R | — | — | — | — | — |
| Tender BOQ | CRUDX | RX | CRUDX | RU | CRUD | R | R | — | — | — | — | — |
| Bid summary / revision | CRUDX | RA X | CRU A | R | CRU | R | — | — | — | — | — | — |
| Contract BOQ (draft) | CRUDX | RX | CRUD | CRU | — | R | R | — | — | — | — | R |
| BOQ approve / lock | A | A | A | — | — | — | — | — | — | — | — | — |
| Markup settings | CRUDX | **A** | CRU | — | — | — | — | — | — | — | — | — |
| Cost rate / margin fields | R | R | R | — | — | — | — | R | — | — | — | — |
| Sell rate / contract value | R | R | R | R | R | R | R | R | — | — | R | R |
| Cost transactions | CRUDX | RX | CRU **A** | CRU | — | R | R | R **A**(paid) | — | — | — | R |
| Variation orders | CRUDX | R **A**(≥50k) | CRU **A**(5–50k) | CRU | — | R **A**(<5k) | R | R | — | — | R* | R |
| Progress claims (IPC) | CRUDX | RX | CRU **A** | CRU | — | R | — | R **A**(paid) | — | — | R* | R |
| Retention ledger | CRUDX | **A**(release) | CRU **A** | R | — | R | — | R | — | — | R* | R |
| Monthly baseline / cash flow | CRUDX | R | CRU **A** | CRU | — | R | — | R | — | — | — | R |
| EVM / S-curve | RX | RX | RX | R | — | R | — | R | — | — | — | R |
| Procurement baseline | CRUDX | **A** | CRU | R | — | R | R | — | — | — | — | — |
| PR baseline checks / override | R | R | **A** | R | — | R | R | — | R(own) | — | — | — |
| Buy-out report | RX | RX | RX | R | R | R | R | — | — | — | — | — |
| Sub-IPC | CRUDX | R | CRU **A** | CRU | — | R | R | R | — | CR(own) | — | R |
| Back charges | CRUDX | R | CRU **A** | CRU | — | R | — | R | R(raise) | R(own) | — | R |
| Employer instructions | CRUDX | R | CRU | CRU | — | CRU | — | — | — | — | R* | R |
| Final account / client report | CRUDX | **A** X | CRU X | R | — | R | — | R | — | — | R* | — |
| Internal final cost report | RX | RX | RX | — | — | — | — | R | — | — | **—** | — |
| Portfolio dashboard | RX | RX | R | — | — | — | — | R | — | — | — | — |

`R*` = external read limited to items formally transmitted to that party.

## 4. Approval Authority

| Action | Authority | Threshold / condition |
|---|---|---|
| Markup settings | Commercial Director | Before BOQ approval |
| BOQ approve | QS Manager | — |
| BOQ lock | QS Manager | After contract execution |
| Budget revision (post-lock) | Commercial Director | With reason |
| VO | PM / QS Manager / Commercial Director | <$5k / $5k–$50k / ≥$50k (chain fixed at submission) |
| Cost transaction approve | QS Manager | Against supporting documents |
| Payment (mark paid) | Finance Officer | Payment confirmed |
| IPC certify | Client QS / Superintendent (external), recorded by QS Manager | Per contract |
| Retention release | QS Manager request → Commercial Director approve | Trigger evidence cited |
| Monthly baseline lock | QS Manager | Rev 0; revisions with reason |
| Procurement baseline | Commercial Manager/Director | At award |
| PR red-route override | QS Manager | Mandatory reason |
| Final account / client statement | Commercial Director | After reconciliation |

## 5. Field-Level Restrictions

| Field group | Visible to |
|---|---|
| `cost_rate`, `markup_pct`, `expected_margin`, unit-rate build-up composition | SA/CA, CD, QSM, FIN |
| Internal final cost report (all columns) | SA/CA, CD, QSM, FIN |
| Supplier quotation comparison detail | SA/CA, CD, QSM, PROC |
| Baseline price on PR lines | SA/CA, CD, QSM, PROC (requester sees the variance chip, not the baseline value) |
| Payroll-derived labour costs | SA/CA, CD, QSM, FIN (HR module governs the source) |

## 6. Segregation of Duties

| Rule | Reason |
|---|---|
| The raiser of a VO cannot approve it at any step | Self-approval risk |
| The preparer of an IPC cannot record its certification | Certification integrity |
| The requester of a PR cannot approve its override | Budget control |
| The recorder of a cost transaction cannot mark it paid | Payment fraud control |
| Retention release requester ≠ approver | Cash control |

Where a small team makes this impossible, the platform requires an explicit, logged exemption approved by the Commercial Director and reviewed monthly.

## 7. External Access Rules

Client/consultant and subcontractor users are contract-scoped and time-bounded (access expiry from contract end date, per the Auth module). They see only transmitted documents and their own submissions; they never see internal cost, margin, buy-out, or other projects. Their actions are audit-logged with the same fidelity as internal users.

## 8. Enforcement & Testing

Server-side enforcement on every endpoint (never client-side hiding alone); RLS policies scope rows by tenant and project; automated tests must prove: cross-tenant read fails; a QSE cannot read `cost_rate`; a client user cannot fetch an untransmitted claim; a VO raiser cannot approve; a client-facing export contains no restricted fields (see doc 09, TC-RBAC series).
