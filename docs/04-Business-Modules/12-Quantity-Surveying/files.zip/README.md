# DCOS — Quantity Surveying Module Documentation Set

Twelve standalone documents following the DCOS module documentation standard (same structure as the Authentication module set).

| # | Document | Code | Covers |
|---|---|---|---|
| 01 | Business Requirement | DCOS-QS-01-BRD | Objectives, scope, 16 business requirements, business rules, benefits, risks |
| 02 | Functional Specification | DCOS-QS-02-FS | FR-100…FR-800 functional requirements, NFRs, traceability to BRD |
| 03 | Use Cases | DCOS-QS-03-UC | 16 use cases with actors, flows, alternatives, exceptions |
| 04 | Database Schema | DCOS-QS-04-DB | 8 entity groups, core table definitions, relationships, indexes, migration order |
| 05 | Integration Specification | DCOS-QS-05-INT | 7 internal interfaces, platform engines, event catalogue, external systems |
| 06 | UI / UX Design | DCOS-QS-06-UI | Navigation, components, key screens, dashboard, interaction and accessibility rules |
| 07 | RBAC Matrix | DCOS-QS-07-RBAC | 13 roles, object permission matrix, approval authority, field-level firewall, segregation of duties |
| 08 | API Reference | DCOS-QS-08-API | Endpoints by domain, examples, error codes, webhooks, rate limits |
| 09 | Test Plan | DCOS-QS-09-TEST | Functional/security/performance cases with exact expected values, UAT scenarios |
| 10 | Deployment Notes | DCOS-QS-10-DEP | Environments, release sequence, migrations, config, go-live, opening balances, rollback |
| 11 | SOP | DCOS-QS-11-SOP | Procedure register (27 procedures), golden rules, operating rhythm, month-end sequence, escalation |
| 12 | Training Guide | DCOS-QS-12-TRN | 6 training paths, 10 modules with exercises, competency checklist, quick reference card |

## Related controlled documents

These sit outside this set and govern where they overlap:

- **SOP-QS-001 R3** — full QS SOP with workflow control for every procedure (41 pp, Word)
- **SOP-QSP-001 R1** — Cost Control → Procurement integration SOP (16 pp, Word)
- **DCOS-QS-GDL-001 V1.1** — GFA, site area and cost/m² guideline (12 pp, Word)
- **DCOS-QS-RPT-001** — report and certificate template specification
- **DCOS-QS-DDS-001 V2.0** — documentation master index
- **FS-QS-001** — Price List / Unit Rate build-up / Tender BOQ build prompt
- **Cambodia seed data** — `seed_price_list_{STR,ARC,MEP}_cambodia.sql` (249 items)

## Consistency anchors

The same worked figures run through documents 02, 03, 04, 08, 09 and 12 so any inconsistency is visible:

```
UR-CON-001 net rate ............ 71.87   (74.81 after cement 4.20 → 4.60)
500 m3 concrete item ........... 35,935.00
Direct / Subcon ................ 262,072.00 / 18,500.00
Contract sum to date ........... 292,972.00
Retention 5% ................... 7,324.30
Current payment due ............ 40,661.70
Allowable cement ............... 3,675 bags
Net buy-out .................... +1,248.75
Building $/m2 .................. 420.00 above ground · 458.84 blended
```
