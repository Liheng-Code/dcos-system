# 03 — Use Cases
## DCOS — Quantity Surveying Module

| Field | Value |
|---|---|
| Document Code | DCOS-QS-03-UC |
| Version | R1 |
| Standard | IEEE 29148 (use-case model) |
| Traces to | 02-Functional-Specification |

---

## Actors

| Actor | Description |
|---|---|
| Estimator | Prices tenders |
| QS Engineer | Day-to-day measurement, cost recording, claim preparation |
| QS Manager | Baseline authority, certification, overrides, buy-out |
| Project Manager | Budget oversight, VO approval at first threshold |
| Commercial Director | Markup, high-value VOs, final reports, portfolio |
| Procurement Officer / Manager | PR validation, RFQ, PO |
| Requester (site/store) | Raises PRs |
| Finance Officer | Payments, three-way match |
| Client / Consultant QS | Reviews and certifies claims (external) |
| Subcontractor | Submits claims (external) |
| System | Scheduled and automatic actions |

---

## UC-01 Build a unit rate from the price list

**Actor:** Estimator · **Trigger:** Tender pricing begins · **Pre:** Tender price list populated

**Main flow:** Estimator opens Unit Rates → adds a rate (code, description, trade, unit) → selects build-up mode → adds composition lines choosing resources from the price list, entering quantity per unit and wastage on material lines → sets productivity factor → system computes material, labor, plant subtotals and the net rate → estimator saves.

**Alternatives:** (a) Flat mode — enters base rate, wastage, productivity; system shows the effective rate. (b) Loads a composition from the company rate library; unmatched resource codes flag amber for pricing.

**Post:** Rate available for BOQ linking. **Exceptions:** duplicate code rejected; qty ≤ 0 rejected.

## UC-02 Price a tender BOQ

**Actor:** Estimator · **Pre:** Unit rates exist

**Main flow:** Adds BOQ sections → adds items with description, unit, measured quantity → selects a unit rate (system validates unit match) → rate and amount auto-fill → sets sourcing self/subcon → reviews section totals.

**Alternatives:** Manual rate for one-off items (flagged); subcontracted items take the preferred sub-quote price.

**Post:** Direct and Subcon totals feed the bid summary. **Exceptions:** unit mismatch blocked with guidance.

## UC-03 Update a market price mid-tender

**Actor:** Estimator · **Pre:** Bid revision in draft

**Main flow:** Edits a price-list unit price → system recalculates every dependent rate line, unit rate, linked BOQ item, and bid total in one transaction → reports the number of rates and items affected.

**Post:** Bid price current. **Exceptions:** revision is final → edit blocked; user must create a new revision with a reason.

## UC-04 Finalize and submit a bid

**Actor:** QS Manager · **Pre:** BOQ, prelims, risk, sub-quotes complete

**Main flow:** Reviews the bid summary chain (Direct + Subcon + Prelims → OH% → profit% → contingency → risk → VAT) → finalizes the revision → system snapshots all input tabs and freezes editing → generates the cover/tender summary from the final revision → issues via document control.

**Post:** Bid submitted; revision immutable. **Exceptions:** addendum received → new revision with reason, re-price, re-finalize.

## UC-05 Establish the contract baseline

**Actor:** QS Manager · **Pre:** Contract awarded

**Main flow:** Creates/carries the contract BOQ → Commercial Director approves markup settings → QS Manager approves the BOQ → locks it → system freezes cost and sell rates and disables editing → baseline feeds budget, EVM, IPC, and procurement.

**Post:** Locked baseline. **Exceptions:** post-lock error → budget revision (Director approval) or VO, per cause.

## UC-06 Record a cost transaction

**Actor:** QS Engineer / Finance · **Trigger:** Invoice, PO, timesheet, or delivery docket

**Main flow:** Records type, category, vendor, dates, quantity and unit cost, reference, BOQ/WBS links → saves as pending → QS Manager verifies against documents and approves → Finance marks paid when settled.

**Post:** Budget & variance and EVM actual cost updated. **Exceptions:** wrong amount after approval → contra entry referencing the original.

## UC-07 Raise and approve a variation order

**Actor:** QS Engineer (raise); PM / QS Manager / Director (approve)

**Main flow:** Creates VO with title, type, schedule impact, description, line items → submits → system computes the approval chain from the total and routes sequentially → each approver approves (advances) or rejects with mandatory reason → on full approval the VO is approved → when executed on site, marked implemented.

**Post:** Net VO amount updates contract sum to date; feeds the next IPC. **Exceptions:** urgent site instruction — proceed on PM written instruction, raise the VO within 48 hours referencing it; client disputes value — VO held at submitted.

## UC-08 Prepare and certify an IPC

**Actors:** QS Engineer (prepare), Client QS (review), Superintendent (certify), Finance (pay)

**Main flow:** Creates a claim for the period → initializes items from the locked BOQ (scheduled value, previous completed) → enters this period and materials stored per item (over-claim blocked) → reviews the G702 summary → submits → client reviews, may enter adjustments with reasons → marks reviewed → superintendent certifies → system records certifier and timestamp and creates the retention deduction → Finance marks paid on receipt.

**Post:** Cumulative certified carried to the next claim; retention ledger updated. **Exceptions:** certified less than claimed — certified governs, difference retained for final account; materials stored disputed — removed and re-claimed next period.

## UC-09 Release retention

**Actor:** QS Manager (request), Director (approve) · **Trigger:** Practical Completion or DLP completion

**Main flow:** Opens the retention register → requests release with trigger, amount, expected date, and certificate reference → approver approves or rejects with reason → outstanding balance updates.

**Exceptions:** release exceeds outstanding → blocked; client delays release → escalate via contractual notice.

## UC-10 Raise a PR against the baseline

**Actor:** Requester · **Pre:** Procurement baseline active

**Main flow:** Creates PR → per line selects budget/BOQ item (mandatory) and price-list resource (where applicable) → system fills baseline price, allowable quantity, ordered-to-date, remaining budget → enters quantity and expected price → three checks compute live → submits → routing per value and check colours → approvers see check results per line.

**Alternatives:** red check → override requested with reason → QS Manager approves or denies.

**Post:** Approved PR available to RFQ; pending budget reserved. **Exceptions:** material out of scope → VO or budget transfer, never an unrelated code.

## UC-11 Compare quotations and issue a PO

**Actors:** Procurement Officer, Procurement Manager

**Main flow:** Creates RFQ from approved PRs → issues to suppliers → records quotes → normalizes scope → comparison sheet shows suppliers plus the baseline column → selects supplier per line (reason required if not lowest) → manager approves → PO drafted, checks re-run at PO prices → PO approved and issued → system writes the commitment, releases the PR reservation, records buy-out gain/(loss).

**Post:** Committed cost visible in budget & variance. **Exceptions:** supplier withdraws → cancel PO, commitment released, next-ranked quote used.

## UC-12 Monitor project commercial health

**Actor:** PM / Commercial Director · **Trigger:** Monthly review

**Main flow:** Opens EVM dashboard → refreshes metrics → reads health banner and the twelve metrics → reviews S-curve divergence → reviews budget & variance red items → reviews buy-out position and override register → assigns actions.

**Exceptions:** CPI/SPI above 1.10 → treat as data-quality flag and verify before reporting.

## UC-13 Assess a subcontractor claim

**Actor:** QS Engineer · **Main flow:** Creates sub-IPC against the subcontract BOQ → assesses progress → deducts agreed back charges and retention per subcontract terms → certifies at assessed value with reasons for differences → certification creates a subcontract cost transaction.

**Exceptions:** subcontractor disputes → record dispute, pay undisputed certified amount on time.

## UC-14 Register an employer instruction

**Actor:** Contract Administrator · **Main flow:** Registers the EI on the day of receipt with clause reference → assesses cost and time impact → raises a VO or entitlement record where impact exists → responds within the contractual notice period → closes when the response is issued and any VO resolved.

**Exceptions:** verbal instruction → confirm in writing within 24 hours and register the confirmation.

## UC-15 Close the project commercially

**Actor:** QS Manager / Commercial Director · **Main flow:** Confirms pre-checks → agrees final measured quantities → prepares the final account statement → reconciles to cumulative certified IPCs → obtains client agreement → issues the final certificate → generates the internal final cost report (margin vs tender) and the client final statement (sell side only) → archives both.

**Post:** Project closed; final margins feed the rate library. **Exceptions:** disputed items → split agreed and disputed; route disputes to claims.

## UC-16 (System) Automatic actions

Retention deduction on certification; escalation of overdue approvals; access/notice time-bar alerts; monthly baseline vs actual comparison; stale commitment flagging (>60 days); expiry warnings on price validity.
